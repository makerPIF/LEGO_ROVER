"""탐사 영상 분석 — QR / 색상 선택 / 도형 / 움직임 / 윤곽선(장애물)

OpenCV(opencv-python-headless)와 numpy가 있으면 동작합니다.
없으면 HAVE_CV=False 이며, GCS는 원본 영상만 표시합니다.

분석은 AnalysisWorker(QThread 안에서 실행)가 맡습니다.
GUI 스레드는 JPEG 바이트만 넘기고, 결과 이미지(QImage)와 결과 dict를 받습니다.
"""
import math
import time

from PySide6.QtCore import QObject, Signal, Slot, Qt, QRectF, QPointF
from PySide6.QtGui import QImage, QPainter, QColor, QFont, QPen, QBrush, QFontMetrics

try:
    import numpy as np
    import cv2
    HAVE_CV = True
    CV_ERROR = ""
except Exception as _exc:                        # pragma: no cover
    np = cv2 = None
    HAVE_CV = False
    CV_ERROR = str(_exc)

# ---------------------------------------------------------------------------
# 분석 방식
# ---------------------------------------------------------------------------
MODES = [
    ("raw",    "원본",            "분석 없이 원본 영상만 표시합니다."),
    ("qr",     "① QR 코드",       "QR 코드를 찾아 내용을 읽습니다. 여러 개 동시 인식."),
    ("color",  "② 색상 선택",     "선택한 색만 골라 위치·크기를 표시합니다."),
    ("shape",  "③ 도형 인식",     "삼각형·사각형·오각형·육각형·원을 구분합니다."),
    ("motion", "④ 움직임 감지",   "이전 프레임과 비교해 움직이는 물체를 찾습니다."),
    ("edge",   "⑤ 윤곽·장애물",   "윤곽선 밀도로 좌/중/우 중 트인 방향을 추정합니다."),
]
MODE_NAMES = {k: n for k, n, _ in MODES}

# OpenCV HSV: H 0~179, S/V 0~255.  (이름, H 구간 목록, 표시색 RGB)
COLOR_DEFS = [
    ("빨강", [(0, 8), (170, 179)], (255, 70, 70)),
    ("주황", [(9, 21)],            (255, 150, 40)),
    ("노랑", [(22, 34)],           (255, 225, 40)),
    ("초록", [(35, 85)],           (70, 220, 90)),
    ("파랑", [(90, 128)],          (60, 140, 255)),
    ("보라", [(129, 169)],         (200, 90, 230)),
]
COLOR_NAMES = [c[0] for c in COLOR_DEFS]

DEFAULT_PARAMS = dict(
    mode="raw", crop=True, mirror=False,
    colors=["빨강"], custom=None, hue_tol=10, s_min=90, v_min=60,
    min_area=0.4, isolate=True,
    shape_min=1.0, shape_color=True,
    motion_sens=25,
    edge_sens=60,
)


def hsv_color_name(h, s, v):
    """HSV 평균값을 한국어 색 이름으로."""
    if v < 50:
        return "검정"
    if s < 45:
        return "흰색" if v > 170 else "회색"
    for name, ranges, _rgb in COLOR_DEFS:
        for lo, hi in ranges:
            if lo <= h <= hi:
                return name
    return "청록"


def horizontal_word(dx):
    """dx: -1(왼쪽 끝) ~ +1(오른쪽 끝)"""
    pct = int(round(abs(dx) * 100))
    if pct < 12:
        return "정면"
    return ("◀ 왼쪽 " if dx < 0 else "오른쪽 ▶ ") + f"{pct}%"


# ---------------------------------------------------------------------------
# 공통 전처리
# ---------------------------------------------------------------------------
def prepare(jpeg, crop=True, mirror=False):
    """JPEG → BGR. crop=True면 가운데 정사각형으로 자른다(화면과 분석 영역 일치)."""
    img = cv2.imdecode(np.frombuffer(jpeg, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("JPEG 디코딩 실패")
    if crop:
        h, w = img.shape[:2]
        s = min(h, w)
        y0, x0 = (h - s) // 2, (w - s) // 2
        img = img[y0:y0 + s, x0:x0 + s]
    if mirror:
        img = cv2.flip(img, 1)
    return np.ascontiguousarray(img)


def _label(labels, x, y, text, rgb):
    labels.append((float(x), float(y), str(text), tuple(int(c) for c in rgb)))


def _bgr(rgb):
    return (int(rgb[2]), int(rgb[1]), int(rgb[0]))


# ---------------------------------------------------------------------------
# ① QR 코드
# ---------------------------------------------------------------------------
class QrReader:
    def __init__(self):
        self.detector = cv2.QRCodeDetector()
        # OpenCV 4.8+ ArUco 기반 검출기가 여러 개 동시 해독에 더 강하다.
        aruco = getattr(cv2, "QRCodeDetectorAruco", None)
        self.multi = [aruco()] if aruco else []
        self.multi.append(self.detector)

    def detect(self, img):
        found = []
        for det in self.multi:
            try:
                ok, texts, points, _ = det.detectAndDecodeMulti(img)
            except cv2.error:
                continue
            if ok and points is not None:
                cur = list(zip(texts, points))
                if any(t for t, _ in cur):
                    return cur
                found = found or cur
        # 여러 개 해독이 모두 실패하면 단일 해독을 한 번 더 시도
        try:
            text, pts, _ = self.detector.detectAndDecode(img)
            if text and pts is not None and len(pts):
                return [(text, pts.reshape(-1, 2))]
        except cv2.error:
            pass
        return found

    def run(self, img, _p):
        labels, items, codes = [], [], []
        out = img.copy()
        h, w = img.shape[:2]
        found = self.detect(img)
        target = None
        best = 0
        for text, pts in found:
            pts = np.asarray(pts, np.float32).reshape(-1, 2)
            if len(pts) < 4:
                continue
            area = abs(cv2.contourArea(pts))
            rgb = (60, 230, 120) if text else (255, 170, 40)
            cv2.polylines(out, [pts.astype(np.int32)], True, _bgr(rgb), 3, cv2.LINE_AA)
            cx, cy = pts[:, 0].mean(), pts[:, 1].mean()
            dx = (cx - w / 2) / (w / 2)
            shown = text if len(text) <= 28 else text[:27] + "…"
            _label(labels, pts[:, 0].min(), pts[:, 1].min() - 4,
                   shown if text else "QR 발견 · 해독 중", rgb)
            if text:
                codes.append(text)
                items.append(f"[QR] {text}   ({horizontal_word(dx)})")
            else:
                items.append("[QR] 발견했으나 해독 실패 — 가까이/정면으로")
            if area > best:
                best, target = area, (dx, (cy - h / 2) / (h / 2))
        if codes:
            summary = f"QR {len(codes)}개 인식"
        elif found:
            summary = "QR 발견 · 해독 실패"
        else:
            summary = "QR 없음"
        return out, labels, dict(summary=summary, items=items, codes=codes, target=target)


# ---------------------------------------------------------------------------
# ② 색상 선택
# ---------------------------------------------------------------------------
def color_masks(hsv, p):
    """선택된 색마다 (이름, 표시RGB, mask) 목록."""
    s_min, v_min = int(p["s_min"]), int(p["v_min"])
    masks = []
    for name, ranges, rgb in COLOR_DEFS:
        if name not in p["colors"]:
            continue
        m = None
        for lo, hi in ranges:
            r = cv2.inRange(hsv, (lo, s_min, v_min), (hi, 255, 255))
            m = r if m is None else cv2.bitwise_or(m, r)
        masks.append((name, rgb, m))
    custom = p.get("custom")
    if custom:
        h, s, v = custom["hsv"]
        rgb = custom["rgb"]
        if s < 45:                      # 무채색(흰/회/검)은 명도로 구분
            m = cv2.inRange(hsv, (0, 0, max(0, v - 40)), (179, 70, min(255, v + 40)))
        else:
            tol = int(p["hue_tol"])
            lo_s, lo_v = max(40, int(s * 0.5)), max(40, int(v * 0.4))
            lo, hi = h - tol, h + tol
            m = cv2.inRange(hsv, (max(0, lo), lo_s, lo_v), (min(179, hi), 255, 255))
            if lo < 0:
                m |= cv2.inRange(hsv, (180 + lo, lo_s, lo_v), (179, 255, 255))
            if hi > 179:
                m |= cv2.inRange(hsv, (0, lo_s, lo_v), (hi - 180, 255, 255))
        masks.append(("지정색", rgb, m))
    return masks


def run_color(img, p):
    h, w = img.shape[:2]
    hsv = cv2.cvtColor(cv2.GaussianBlur(img, (5, 5), 0), cv2.COLOR_BGR2HSV)
    kernel = np.ones((5, 5), np.uint8)
    min_px = p["min_area"] / 100.0 * w * h
    masks = color_masks(hsv, p)
    labels, items = [], []
    union = np.zeros((h, w), np.uint8)
    blobs = []
    for name, rgb, m in masks:
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, kernel)
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, kernel)
        union |= m
        cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        found = sorted((c for c in cnts if cv2.contourArea(c) >= min_px),
                       key=cv2.contourArea, reverse=True)[:6]
        for c in found:
            blobs.append((cv2.contourArea(c), name, rgb, c))
        if found:
            a = cv2.contourArea(found[0])
            x, y, bw, bh = cv2.boundingRect(found[0])
            dx = (x + bw / 2 - w / 2) / (w / 2)
            items.append(f"{name}: {len(found)}개 · 최대 {a / (w * h) * 100:.1f}% · {horizontal_word(dx)}")
        else:
            items.append(f"{name}: 없음")
    if p.get("isolate") and masks:
        gray = cv2.cvtColor(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), cv2.COLOR_GRAY2BGR)
        gray = (gray * 0.55).astype(np.uint8)
        out = np.where(union[:, :, None] > 0, img, gray)
    else:
        out = img.copy()
    target = None
    for i, (a, name, rgb, c) in enumerate(sorted(blobs, key=lambda b: b[0], reverse=True)):
        x, y, bw, bh = cv2.boundingRect(c)
        cv2.drawContours(out, [c], -1, _bgr(rgb), 2, cv2.LINE_AA)
        cv2.rectangle(out, (x, y), (x + bw, y + bh), _bgr(rgb), 1)
        _label(labels, x, y - 4, f"{name} {a / (w * h) * 100:.1f}%", rgb)
        if i == 0:
            target = ((x + bw / 2 - w / 2) / (w / 2), (y + bh / 2 - h / 2) / (h / 2))
    if not masks:
        summary = "검출할 색을 선택하세요"
    else:
        summary = f"색 영역 {len(blobs)}개 검출" if blobs else "선택한 색 없음"
    return out, labels, dict(summary=summary, items=items, target=target,
                             coverage=float(np.count_nonzero(union)) / (w * h) * 100)


# ---------------------------------------------------------------------------
# ③ 도형 인식
# ---------------------------------------------------------------------------
def classify_contour(c):
    area = cv2.contourArea(c)
    peri = cv2.arcLength(c, True)
    if peri <= 0 or area <= 0:
        return None
    approx = cv2.approxPolyDP(c, 0.035 * peri, True)
    n = len(approx)
    circ = 4 * math.pi * area / (peri * peri)
    if n == 3:
        return "삼각형"
    if n == 4:
        (_, _), (rw, rh), _ = cv2.minAreaRect(c)
        ratio = min(rw, rh) / max(rw, rh) if max(rw, rh) else 0
        return "정사각형" if ratio > 0.85 else "직사각형"
    if circ > 0.80 and n >= 7:
        return "원"
    if n == 5:
        return "오각형"
    if n == 6:
        return "육각형"
    return "원" if circ > 0.80 else None


def run_shape(img, p):
    h, w = img.shape[:2]
    # 밝기가 비슷한 색 도형도 잡도록 B/G/R 채널별 윤곽선을 합친다.
    blur = cv2.GaussianBlur(img, (5, 5), 0)
    edges = None
    for ch in cv2.split(blur):
        e = cv2.Canny(ch, 40, 120)
        edges = e if edges is None else cv2.bitwise_or(edges, e)
    edges = cv2.dilate(edges, np.ones((3, 3), np.uint8), iterations=1)
    cnts, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    min_px = p["shape_min"] / 100.0 * w * h
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV) if p.get("shape_color") else None
    out = img.copy()
    labels, found = [], []
    for c in sorted(cnts, key=cv2.contourArea, reverse=True)[:15]:
        a = cv2.contourArea(c)
        if a < min_px or a > 0.9 * w * h:
            continue
        kind = classify_contour(c)
        if not kind:
            continue
        x, y, bw, bh = cv2.boundingRect(c)
        name = kind
        if hsv is not None:
            m = np.zeros((h, w), np.uint8)
            cv2.drawContours(m, [c], -1, 255, -1)
            hh, ss, vv, _ = cv2.mean(hsv, mask=m)
            name = f"{hsv_color_name(hh, ss, vv)} {kind}"
        rgb = (0, 230, 255)
        cv2.drawContours(out, [c], -1, _bgr(rgb), 2, cv2.LINE_AA)
        _label(labels, x, y - 4, name, rgb)
        found.append((a, name, (x + bw / 2 - w / 2) / (w / 2), (y + bh / 2 - h / 2) / (h / 2)))
    counts = {}
    for _a, name, _dx, _dy in found:
        kind = name.split()[-1]
        counts[kind] = counts.get(kind, 0) + 1
    items = [f"{name} · {horizontal_word(dx)} · {a / (w * h) * 100:.1f}%"
             for a, name, dx, _dy in found]
    summary = (" · ".join(f"{k} {v}" for k, v in counts.items())) if counts else "도형 없음"
    target = (found[0][2], found[0][3]) if found else None
    return out, labels, dict(summary=summary, items=items, target=target, counts=counts)


# ---------------------------------------------------------------------------
# ④ 움직임 감지
# ---------------------------------------------------------------------------
class MotionDetector:
    def __init__(self):
        self.prev = None

    def reset(self):
        self.prev = None

    def run(self, img, p):
        h, w = img.shape[:2]
        gray = cv2.GaussianBlur(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), (21, 21), 0)
        if self.prev is None or self.prev.shape != gray.shape:
            self.prev = gray
            return img.copy(), [], dict(summary="기준 프레임 저장", items=[], target=None, motion=0.0)
        diff = cv2.absdiff(self.prev, gray)
        self.prev = gray
        # 민감도 1~100 → 차이 임계값 60~6
        thr = int(max(6, 60 - p["motion_sens"] * 0.54))
        _, m = cv2.threshold(diff, thr, 255, cv2.THRESH_BINARY)
        m = cv2.dilate(m, None, iterations=2)
        pct = float(np.count_nonzero(m)) / (w * h) * 100
        out = img.copy()
        red = np.zeros_like(out); red[:, :] = (40, 40, 255)
        sel = m > 0
        out[sel] = cv2.addWeighted(out, 0.45, red, 0.55, 0)[sel]
        cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        labels, items = [], []
        boxes = sorted((c for c in cnts if cv2.contourArea(c) > 0.003 * w * h),
                       key=cv2.contourArea, reverse=True)[:6]
        target = None
        for i, c in enumerate(boxes):
            x, y, bw, bh = cv2.boundingRect(c)
            cv2.rectangle(out, (x, y), (x + bw, y + bh), (60, 60, 255), 2)
            dx = (x + bw / 2 - w / 2) / (w / 2)
            items.append(f"움직임 #{i + 1} · {horizontal_word(dx)} · {bw}×{bh}px")
            if i == 0:
                _label(labels, x, y - 4, "움직임", (255, 80, 80))
                target = (dx, (y + bh / 2 - h / 2) / (h / 2))
        if pct > 40:
            summary = f"화면 전체 변화 {pct:.0f}% — 로버/카메라가 움직이는 중"
        elif boxes:
            summary = f"움직임 감지 {len(boxes)}곳 · 변화 {pct:.1f}%"
        else:
            summary = f"움직임 없음 · 변화 {pct:.1f}%"
        return out, labels, dict(summary=summary, items=items, target=target, motion=pct)


# ---------------------------------------------------------------------------
# ⑤ 윤곽선 · 장애물(트인 방향)
# ---------------------------------------------------------------------------
def run_edge(img, p):
    h, w = img.shape[:2]
    gray = cv2.GaussianBlur(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), (5, 5), 0)
    # 민감도 1~100 → Canny 하한 150~15
    low = int(max(15, 150 - p["edge_sens"] * 1.35))
    edges = cv2.Canny(gray, low, low * 2.5)
    out = (img * 0.4).astype(np.uint8)
    out[edges > 0] = (255, 230, 60)
    # 화면 아래쪽 2/3(바닥·전방)만 좌/중/우로 나눠 밀도 계산
    roi = edges[h // 3:, :]
    thirds = np.array_split(roi, 3, axis=1)
    dens = [float(np.count_nonzero(t)) / t.size * 100 for t in thirds]
    names = ["좌", "중", "우"]
    open_i = int(np.argmin(dens))
    labels = []
    for i in range(3):
        x0 = int(w * i / 3)
        x1 = int(w * (i + 1) / 3)
        busy = dens[i] > 6
        col = (60, 60, 255) if busy else (80, 220, 80)
        cv2.rectangle(out, (x0 + 2, h // 3), (x1 - 2, h - 2), col, 2 if i == open_i else 1)
        _label(labels, x0 + 6, h - 22, f"{names[i]} {dens[i]:.1f}%",
               (255, 80, 80) if busy else (90, 230, 110))
    cv2.line(out, (0, h // 3), (w, h // 3), (120, 120, 120), 1)
    items = [f"{names[i]} 영역 윤곽 밀도 {dens[i]:.1f}%" + ("  ← 가장 트임" if i == open_i else "")
             for i in range(3)]
    items.append("밀도가 높을수록 물체·요철이 많습니다 (참고용 추정).")
    summary = f"트인 방향: {names[open_i]}  (좌 {dens[0]:.1f} · 중 {dens[1]:.1f} · 우 {dens[2]:.1f}%)"
    target = ((open_i - 1) * 2 / 3, 0.3)
    return out, labels, dict(summary=summary, items=items, target=target, density=dens,
                             open=names[open_i])


# ---------------------------------------------------------------------------
# BGR + 라벨 → QImage (한글 라벨은 QPainter로 그린다: cv2.putText는 한글 불가)
# ---------------------------------------------------------------------------
def to_qimage(img, labels, mode, result):
    rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    h, w = rgb.shape[:2]
    q = QImage(rgb.data, w, h, 3 * w, QImage.Format_RGB888).copy()
    p = QPainter(q)
    p.setRenderHint(QPainter.Antialiasing)
    px = max(11, int(w / 34))
    font = QFont("Malgun Gothic", 1); font.setPixelSize(px); font.setBold(True)
    p.setFont(font)
    fm = QFontMetrics(font)
    # 중앙 조준선
    p.setPen(QPen(QColor(255, 255, 255, 120), 1))
    cx, cy = w / 2, h / 2
    p.drawLine(QPointF(cx - 12, cy), QPointF(cx + 12, cy))
    p.drawLine(QPointF(cx, cy - 12), QPointF(cx, cy + 12))
    tgt = result.get("target")
    if tgt:
        tx, ty = cx + tgt[0] * w / 2, cy + tgt[1] * h / 2
        p.setPen(QPen(QColor(255, 210, 60, 220), 2, Qt.DashLine))
        p.drawLine(QPointF(cx, cy), QPointF(tx, ty))
        p.setBrush(QBrush(QColor(255, 210, 60)))
        p.drawEllipse(QPointF(tx, ty), 4, 4)
    for x, y, text, col in labels:
        tw = fm.horizontalAdvance(text) + 8
        th = fm.height() + 2
        x = min(max(0, x), w - tw)
        y = min(max(th, y), h)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(0, 0, 0, 170))
        p.drawRoundedRect(QRectF(x, y - th, tw, th), 3, 3)
        p.setPen(QColor(*col))
        p.drawText(QRectF(x + 4, y - th, tw, th), Qt.AlignVCenter | Qt.AlignLeft, text)
    # 상단 HUD
    hud = f"{MODE_NAMES.get(mode, mode)} · {result.get('summary', '')}"
    th = fm.height() + 6
    p.setPen(Qt.NoPen); p.setBrush(QColor(4, 10, 16, 190))
    p.drawRect(QRectF(0, 0, w, th))
    p.setPen(QColor("#7fe3ff"))
    p.drawText(QRectF(6, 0, w - 12, th), Qt.AlignVCenter | Qt.AlignLeft,
               fm.elidedText(hud, Qt.ElideRight, int(w - 12)))
    p.end()
    return q


def analyze(img, params, qr=None, motion=None):
    """테스트와 워커가 함께 쓰는 순수 분석 함수. (BGR out, labels, result)"""
    mode = params["mode"]
    if mode == "qr":
        return (qr or QrReader()).run(img, params)
    if mode == "color":
        return run_color(img, params)
    if mode == "shape":
        return run_shape(img, params)
    if mode == "motion":
        return (motion or MotionDetector()).run(img, params)
    if mode == "edge":
        return run_edge(img, params)
    return img.copy(), [], dict(summary="", items=[], target=None)


# ---------------------------------------------------------------------------
# 작업 스레드용 워커
# ---------------------------------------------------------------------------
class AnalysisWorker(QObject):
    done = Signal(object, object)          # QImage, result dict
    picked = Signal(object)                # dict(hsv=(h,s,v), rgb=(r,g,b))

    def __init__(self):
        super().__init__()
        self.qr = None
        self.motion = None
        self.last_img = None
        self.last_mode = None

    @Slot(object, object)
    def process(self, jpeg, params):
        t0 = time.perf_counter()
        try:
            if self.qr is None:
                self.qr = QrReader()
                self.motion = MotionDetector()
            if params["mode"] != self.last_mode:
                self.motion.reset()
                self.last_mode = params["mode"]
            img = prepare(jpeg, params.get("crop", True), params.get("mirror", False))
            self.last_img = img
            out, labels, result = analyze(img, params, self.qr, self.motion)
            result["ms"] = (time.perf_counter() - t0) * 1000
            result["mode"] = params["mode"]
            self.done.emit(to_qimage(out, labels, params["mode"], result), result)
        except Exception as exc:
            self.done.emit(QImage(), dict(error=str(exc), mode=params.get("mode")))

    @Slot(float, float)
    def pick(self, nx, ny):
        img = self.last_img
        if img is None:
            return
        h, w = img.shape[:2]
        x = int(min(max(nx, 0.0), 0.999) * w)
        y = int(min(max(ny, 0.0), 0.999) * h)
        patch = img[max(0, y - 3):y + 4, max(0, x - 3):x + 4]
        b, g, r = [int(v) for v in patch.reshape(-1, 3).mean(axis=0)]
        hh, ss, vv = [int(v) for v in cv2.cvtColor(np.uint8([[[b, g, r]]]), cv2.COLOR_BGR2HSV)[0, 0]]
        self.picked.emit(dict(hsv=(hh, ss, vv), rgb=(r, g, b), xy=(x, y)))
