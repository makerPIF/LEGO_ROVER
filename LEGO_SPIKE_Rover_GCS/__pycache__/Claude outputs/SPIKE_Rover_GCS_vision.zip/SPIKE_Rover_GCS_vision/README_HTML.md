# SPIKE Rover GCS — HTML 판

`SPIKE_Rover_GCS.html` 파일 **하나**로 PC(PySide6) GCS와 같은 화면 구성과 기능을 씁니다. 설치할 것이 없습니다. jsQR(Apache-2.0)을 파일 안에 넣어 두었으므로 인터넷이 없어도 동작합니다. PC가 ROVER-CAM Wi-Fi에 붙어 인터넷이 끊겨도 그대로 쓸 수 있습니다.

허브 코드(hub_rover.py tunnel-v2)와 ESP32-CAM 펌웨어는 PC 버전과 같습니다. 바꿀 필요가 없습니다.

## 여는 방법

1. **Windows의 Chrome 또는 Edge**에서 `SPIKE_Rover_GCS.html`을 더블클릭하거나 브라우저 창으로 끌어다 놓습니다. 주소창이 `file:///…`로 시작해야 합니다.
2. Firefox·Safari는 Web Bluetooth와 Web Serial을 지원하지 않습니다.
3. 웹 호스팅(https)에 올리면 안 됩니다. https 페이지는 `http://192.168.4.1` 카메라 영상을 차단합니다(혼합 콘텐츠). 로컬 파일로 여세요.

## PC 버전과 대응

| PC (Python) | HTML |
|---|---|
| bleak BLE | Web Bluetooth (같은 COBS·TunnelMessage 0x32 규약, 바이트 단위로 같음) |
| pyserial USB | Web Serial |
| QtNetwork MJPEG + mjpeg_parser | fetch 스트림 + 같은 파서 (Content-Length 검사) |
| QThread + OpenCV 분석 | Web Worker + JS 영상처리 + jsQR |
| QSettings | 브라우저 localStorage |
| 파일 저장 대화상자 | 저장 대화상자 (지원 안 되면 다운로드 폴더) |

4열 한 화면 배치, 정사각 영상, 분석 5종과 옵션, 안전장치는 모두 같습니다. 안전장치에는 Q ACK 전 주행 차단, 영상 끊김 정지, 창 비활성 시 비상정지, 0.3초 넘게 밀린 명령 폐기가 포함됩니다. 열 경계를 끌어 폭을 바꿀 수 있습니다.

## 브라우저 때문에 달라지는 점

- **[스캔]**: 브라우저의 기기 선택 창이 뜹니다. 허브를 고르면 목록에 추가되고, [연결]을 누르면 됩니다. 한 번 허용한 허브는 Chrome 설정에 따라 다음 실행 때 목록에 다시 나타날 수 있습니다.
- **USB Serial**: [스캔]을 누르면 포트 선택 창이 뜹니다.
- **[서비스 캐시 무시]**: 웹 블루투스는 연결할 때마다 서비스를 새로 검색하므로 이 옵션은 효과가 없습니다. 화면을 맞추려고 남겨 두었습니다.
- **[Wi-Fi 설정]**: Windows 설정 앱 열기를 브라우저가 한 번 물어봅니다.
- **QR 인식**: OpenCV 대신 jsQR을 씁니다. 한 화면에서 최대 4개까지 차례로 찾습니다. "발견했으나 해독 실패" 상태는 표시하지 않습니다.
- **도형 인식, 윤곽 밀도**: OpenCV와 같은 방식(Canny, 외곽 윤곽, 다각형 근사)을 JS로 구현했습니다. 경계 조건에 따라 수치가 PC 버전과 조금 다를 수 있습니다.
- 파일 선택기나 기기 선택 창이 뜨면 창이 비활성화된 것으로 처리되어 비상정지(E)가 한 번 전송됩니다. PC 버전과 같은 안전 동작입니다.

## 문제 해결

| 증상 | 확인 |
|---|---|
| "Web Bluetooth를 지원하지 않습니다" | Chrome/Edge 사용, 주소가 `file://`인지 확인 |
| 영상 연결 오류 (Failed to fetch) | PC가 ROVER-CAM에 연결됐는지, 주소 `http://192.168.4.1:81/stream`. 브라우저가 "로컬 네트워크 기기 접근"을 물으면 허용 |
| 영상은 되는데 분석 화면이 안 바뀜 | 브라우저 콘솔(F12) 오류 확인. 펌웨어가 `Access-Control-Allow-Origin: *`를 보내야 함 (제공 펌웨어는 보냄) |
| 브라우저 탭에서 영상을 본 뒤 GCS가 안 됨 | ESP32 펌웨어는 시청자 1명 기준입니다. 다른 탭·창의 영상을 닫으세요 |

## 검증

```bash
python web/test_html.py      # Playwright(Chromium) + 모의 MJPEG 카메라 + 모의 BLE 허브
```

- COBS 인코딩과 TunnelMessage가 Python 버전과 바이트 단위로 같은지
- 잘게 나뉘어 들어온 알림을 제대로 조립하는지
- 텔레메트리·ACK 전 주행 차단, W 키 → T250,250 → T0,0, Space → E 순서가 맞는지
- 1280×760에서 영상이 정사각형인지, 모든 창이 한 화면 안에 들어오는지
- 5가지 분석이 모두 결과를 내는지, 영상 클릭으로 지정한 색이 맞는지, 영상이 끊기면 주행이 차단되는지

위 항목은 모두 통과했습니다. 실제 허브를 Web Bluetooth로 연결하는 것과 실제 ESP32-CAM 영상은 이 환경에서 시험할 수 없어서, 장비에서 확인이 필요합니다.
