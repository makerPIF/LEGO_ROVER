"""ESP32-CAM MJPEG viewer using asynchronous QtNetwork.

- 영상 창은 항상 정사각형(SquareHolder)으로 표시합니다.
  · 정사각 채움 : 카메라 4:3 영상의 가운데 정사각형만 잘라 꽉 채움(분석 영역도 동일)
  · 정사각 맞춤 : 전체 화각을 유지하고 위아래를 검은 띠로 채움
- 원본 표시는 OpenCV 없이 동작합니다. 영상 분석(analysis_panel)이 켜지면
  분석 결과 이미지를 대신 표시합니다.
"""
import sys
import time
from PySide6.QtCore import Qt, QTimer, QUrl, Signal, QSettings, QEvent, QRect
from PySide6.QtGui import QImage, QPixmap, QDesktopServices
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest, QNetworkProxy
from PySide6.QtWidgets import (QGroupBox, QVBoxLayout, QHBoxLayout, QLineEdit,
    QPushButton, QLabel, QCheckBox, QFileDialog, QSizePolicy, QWidget, QComboBox)
from mjpeg_parser import MjpegParser


class SquareHolder(QWidget):
    """자식 위젯을 가능한 가장 큰 정사각형으로 가운데 배치한다."""

    def __init__(self, child, parent=None):
        super().__init__(parent)
        self.child = child
        child.setParent(self)
        self.setMinimumSize(240, 240)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def side(self):
        return min(self.width(), self.height())

    def resizeEvent(self, event):
        s = self.side()
        self.child.setGeometry((self.width() - s) // 2, (self.height() - s) // 2, s, s)
        super().resizeEvent(event)


class CameraPanel(QGroupBox):
    lost = Signal()
    log = Signal(str, str)
    frame_ready = Signal(object)          # 새 JPEG 원본 (분석기로 전달)
    clicked = Signal(float, float)        # 표시 영상 기준 정규화 좌표 0~1
    view_changed = Signal()

    def __init__(self, parent=None):
        super().__init__('ESP32-CAM · 탐사 영상', parent)
        self.settings = QSettings('SPIKE-Rover', 'Camera')
        self.manager = QNetworkAccessManager(self)
        self.manager.setProxy(QNetworkProxy(QNetworkProxy.NoProxy))
        self.reply = None
        self.requested = False
        self.last_frame = 0.0
        self.attempt_at = 0.0
        self.image = QImage()
        self.jpeg = b''
        self.frames = 0
        self.rate_at = time.monotonic()
        self.warned = False
        self.parser = MjpegParser()
        self.processing = False           # True: 분석 이미지를 표시
        self.processed = QImage()
        self.processed_at = 0.0
        self.pick_mode = False
        self._shown = QRect()             # screen 안에서 실제 영상이 그려진 영역

        layout = QVBoxLayout(self)
        layout.setSpacing(5)
        row = QHBoxLayout()
        self.url = QLineEdit(self.settings.value('url', 'http://192.168.4.1:81/stream'))
        self.url.setPlaceholderText('http://192.168.4.1:81/stream')
        self.url.setToolTip('PC Wi-Fi → ROVER-CAM 연결 후 [영상 연결] · BLE 조종과 동시 사용')
        row.addWidget(self.url, 1)
        self.connect_button = QPushButton('영상 연결'); self.connect_button.setObjectName('primary')
        self.connect_button.clicked.connect(self.start)
        self.stop_button = QPushButton('영상 해제')
        self.stop_button.clicked.connect(self.stop)
        row.addWidget(self.connect_button); row.addWidget(self.stop_button)
        layout.addLayout(row)

        self.screen = QLabel('카메라 미연결')
        self.screen.setAlignment(Qt.AlignCenter)
        self.screen.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Ignored)
        self.screen.setStyleSheet('background:#05080c; color:#91a8bc; border:1px solid #294254;')
        self.screen.installEventFilter(self)
        self.square = SquareHolder(self.screen)
        layout.addWidget(self.square, 1)

        self.status = QLabel('Wi-Fi AP: ROVER-CAM  /  기본 암호: rovercam123')
        self.status.setWordWrap(True)
        self.status.setStyleSheet('color:#91a8bc;')
        layout.addWidget(self.status)

        row = QHBoxLayout()
        self.view = QComboBox()
        self.view.addItems(['채움 (가운데 자름)', '맞춤 (전체 화각)'])
        self.view.setToolTip('정사각 영상 창 표시 방식 — 채움: 4:3 영상의 가운데 정사각형(분석 영역과 동일)')
        self.view.setCurrentIndex(int(self.settings.value('view', 0)))
        self.view.currentIndexChanged.connect(self._view_changed)
        self.mirror = QCheckBox('좌우 반전')
        self.mirror.toggled.connect(self._view_changed)
        self.stop_on_loss = QCheckBox('영상 끊기면 정지 (3초)')
        self.stop_on_loss.setChecked(True)
        row.addWidget(self.view, 1); row.addWidget(self.mirror); row.addWidget(self.stop_on_loss)
        layout.addLayout(row)

        row = QHBoxLayout()
        snap = QPushButton('원본 사진 저장'); snap.clicked.connect(self.snapshot)
        snap_view = QPushButton('분석 화면 저장'); snap_view.clicked.connect(self.snapshot_view)
        wifi = QPushButton('Wi-Fi 설정'); wifi.clicked.connect(self.wifi_settings)
        row.addWidget(snap); row.addWidget(snap_view); row.addWidget(wifi)
        layout.addLayout(row)
        for b in (self.connect_button, self.stop_button, snap, snap_view, wifi,
                  self.mirror, self.stop_on_loss, self.view):
            b.setFocusPolicy(Qt.NoFocus)
        self.retry = QTimer(self); self.retry.setSingleShot(True)
        self.retry.timeout.connect(self.open_stream)
        self.timer = QTimer(self); self.timer.timeout.connect(self.tick)
        self.timer.start(250)

    # ------------------------------------------------------------ 표시 설정
    def view_params(self):
        return dict(crop=self.view.currentIndex() == 0, mirror=self.mirror.isChecked())

    def _view_changed(self, *_):
        self.settings.setValue('view', self.view.currentIndex())
        self.processed = QImage()
        self.view_changed.emit()
        self.render()

    def set_processing(self, on):
        self.processing = bool(on)
        self.processed = QImage()
        self.render()

    def set_pick_mode(self, on):
        self.pick_mode = bool(on)
        self.screen.setCursor(Qt.CrossCursor if on else Qt.ArrowCursor)

    def frame_fresh(self):
        return bool(self.last_frame) and time.monotonic() - self.last_frame < 3.0

    # ------------------------------------------------------------ 안전 게이트
    def motion_allowed(self):
        return (not self.requested or not self.stop_on_loss.isChecked()
                or (self.last_frame > 0 and time.monotonic() - self.last_frame < 3.0))

    # ------------------------------------------------------------ 스트림
    def start(self):
        url = QUrl(self.url.text().strip())
        if url.scheme() != 'http' or not url.host() or url.userName() or url.password():
            self.status.setText('카메라의 http://주소:81/stream 형식으로 입력하세요.')
            return
        self.stop()
        self.active_url = url
        self.settings.setValue('url', url.toString())
        self.requested = True
        self.warned = False
        self.last_frame = 0.0
        self.frames = 0
        self.rate_at = time.monotonic()
        self.jpeg = b''
        self.image = QImage()
        self.processed = QImage()
        self.screen.setText('카메라 연결 중…')
        self.url.setEnabled(False)
        self.connect_button.setEnabled(False)
        self.open_stream()

    def open_stream(self):
        if not self.requested or self.reply is not None:
            return
        self.attempt_at = time.monotonic()
        self.parser = MjpegParser()
        request = QNetworkRequest(self.active_url)
        request.setRawHeader(b'Accept', b'multipart/x-mixed-replace')
        request.setRawHeader(b'Cache-Control', b'no-cache')
        request.setTransferTimeout(5000)
        reply = self.manager.get(request)
        reply.setReadBufferSize(256*1024)
        self.reply = reply
        reply.readyRead.connect(lambda: self.receive(reply))
        reply.finished.connect(lambda: self.finished(reply))
        self.status.setText('영상 연결 중… PC가 ROVER-CAM Wi-Fi에 연결되어 있어야 합니다.')

    def receive(self, reply):
        if reply is not self.reply or not self.requested:
            return
        try:
            code = reply.attribute(QNetworkRequest.HttpStatusCodeAttribute)
            if code is not None and int(code) != 200:
                raise ValueError(f'HTTP {code}')
            kind = str(reply.header(QNetworkRequest.ContentTypeHeader) or '').lower()
            if 'multipart/x-mixed-replace' not in kind:
                raise ValueError('MJPEG 주소가 아닙니다. :81/stream을 확인하세요.')
            # Drain current network data, display only the newest complete frame.
            newest = None
            while reply.bytesAvailable():
                frames = self.parser.feed(bytes(reply.read(32768)))
                if frames:
                    newest = frames[-1]
                    self.frames += len(frames)
            if newest is None:
                return
            decoded = QImage.fromData(newest, 'JPEG')
            if decoded.isNull():
                raise ValueError('JPEG 디코딩 실패')
            self.image, self.jpeg = decoded, newest
            self.last_frame = time.monotonic()
            self.warned = False
            self.frame_ready.emit(newest)
            if not self.processing or self.processed.isNull():
                self.render()
        except Exception as exc:
            self.status.setText(str(exc))
            self.log.emit('카메라: ' + str(exc), 'warn')
            reply.abort()

    def finished(self, reply):
        if reply is not self.reply:
            reply.deleteLater()
            return
        self.reply = None
        reason = reply.errorString()
        reply.deleteLater()
        if self.requested:
            self.status.setText('영상 연결 종료 · 2초 후 재연결: ' + reason)
            self.retry.start(2000)

    def tick(self):
        if not self.requested:
            return
        now = time.monotonic()
        age = now - self.last_frame if self.last_frame else float('inf')
        if age >= 3:
            self.screen.clear()
            self.screen.setText('영상 수신 대기 / 끊김\nWi-Fi와 카메라 전원을 확인하세요.')
            self.processed = QImage()
            if not self.warned and self.stop_on_loss.isChecked():
                self.warned = True
                self.lost.emit()
            if self.reply is not None and now - self.attempt_at > 6:
                self.reply.abort()
        elif now - self.rate_at >= 1:
            fps = self.frames / (now - self.rate_at)
            self.status.setText(f'{self.image.width()}×{self.image.height()} · 수신 {fps:.1f} FPS · 마지막 프레임 {age:.1f}초 전')
            self.frames = 0
            self.rate_at = now

    # ------------------------------------------------------------ 그리기
    def show_processed(self, image):
        """분석 워커가 만든 이미지(이미 자르기/반전 적용됨)를 표시."""
        if not self.processing or not self.requested or image.isNull() or not self.frame_fresh():
            return
        self.processed = image
        self.processed_at = time.monotonic()
        self.render()

    def prepared_raw(self):
        """원본 QImage에 화면 설정(정사각 자르기/좌우 반전)을 적용."""
        image = self.image
        if self.view.currentIndex() == 0:
            s = min(image.width(), image.height())
            image = image.copy((image.width() - s) // 2, (image.height() - s) // 2, s, s)
        if self.mirror.isChecked():
            image = image.mirrored(True, False)
        return image

    def current_view_image(self):
        if self.processing and not self.processed.isNull():
            return self.processed
        if self.image.isNull():
            return QImage()
        return self.prepared_raw()

    def render(self, *_):
        if self.image.isNull() or not self.frame_fresh():
            return
        image = self.current_view_image()
        if image.isNull():
            return
        pix = QPixmap.fromImage(image).scaled(
            self.screen.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self._shown = QRect((self.screen.width() - pix.width()) // 2,
                            (self.screen.height() - pix.height()) // 2,
                            pix.width(), pix.height())
        self.screen.setPixmap(pix)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        QTimer.singleShot(0, self.render)

    def eventFilter(self, obj, event):
        if obj is self.screen and event.type() == QEvent.MouseButtonPress:
            r = self._shown
            pos = event.position()
            if r.width() > 0 and r.contains(int(pos.x()), int(pos.y())):
                self.clicked.emit((pos.x() - r.x()) / r.width(), (pos.y() - r.y()) / r.height())
            return True
        if obj is self.screen and event.type() == QEvent.Resize:
            QTimer.singleShot(0, self.render)
        return super().eventFilter(obj, event)

    # ------------------------------------------------------------ 저장
    def snapshot(self):
        if not self.jpeg or not self.last_frame or time.monotonic() - self.last_frame >= 3:
            self.status.setText('현재 수신 중인 영상이 없습니다.')
            return
        path, _ = QFileDialog.getSaveFileName(self, '카메라 원본 사진 저장',
            time.strftime('rover_%Y%m%d_%H%M%S.jpg'), 'JPEG (*.jpg)')
        if path:
            try:
                with open(path, 'wb') as fp:
                    fp.write(self.jpeg)
                self.log.emit('카메라 사진 저장: ' + path, 'info')
            except OSError as exc:
                self.log.emit('사진 저장 실패: ' + str(exc), 'err')

    def snapshot_view(self):
        image = self.current_view_image() if self.frame_fresh() else QImage()
        if image.isNull():
            self.status.setText('현재 표시 중인 영상이 없습니다.')
            return
        path, _ = QFileDialog.getSaveFileName(self, '분석 화면 저장',
            time.strftime('rover_view_%Y%m%d_%H%M%S.png'), 'PNG (*.png)')
        if path:
            if image.save(path, 'PNG'):
                self.log.emit('분석 화면 저장: ' + path, 'info')
            else:
                self.log.emit('분석 화면 저장 실패: ' + path, 'err')

    def wifi_settings(self):
        if sys.platform == 'win32':
            QDesktopServices.openUrl(QUrl('ms-settings:network-wifi'))
        else:
            self.status.setText('운영체제 Wi-Fi 메뉴에서 ROVER-CAM 선택 → 암호 rovercam123 입력')

    def stop(self):
        was_requested = self.requested
        self.requested = False
        self.retry.stop()
        old, self.reply = self.reply, None
        if old is not None:
            old.abort(); old.deleteLater()
        self.last_frame = 0.0
        self.jpeg = b''
        self.image = QImage()
        self.processed = QImage()
        self.screen.clear(); self.screen.setText('카메라 미연결')
        self.status.setText('영상 해제 · BLE 로버 조종은 별도 연결입니다.')
        self.url.setEnabled(True)
        self.connect_button.setEnabled(True)
        if was_requested and self.stop_on_loss.isChecked():
            self.lost.emit()
