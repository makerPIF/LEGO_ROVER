"""영상 분석 패널 — 5가지 분석 방식 선택, 방식별 옵션, 결과 표시.

CameraPanel.frame_ready(JPEG) → AnalysisWorker(별도 스레드) → CameraPanel.show_processed
분석이 느려도 GUI·조종은 멈추지 않습니다. 처리 중에 들어온 프레임은 가장 최근 것만 남깁니다.
"""
import csv
import time

from PySide6.QtCore import Qt, QThread, Signal, QSettings
from PySide6.QtGui import QColor, QGuiApplication
from PySide6.QtWidgets import (QGroupBox, QVBoxLayout, QHBoxLayout, QGridLayout, QPushButton,
    QLabel, QCheckBox, QSlider, QStackedWidget, QWidget, QListWidget, QButtonGroup,
    QFileDialog, QSizePolicy, QFrame)

import vision_analysis as va


def _slider(lo, hi, value, width=None):
    s = QSlider(Qt.Horizontal)
    s.setRange(lo, hi); s.setValue(value)
    s.setFocusPolicy(Qt.NoFocus)
    return s


class AnalysisPanel(QGroupBox):
    log = Signal(str, str)
    _request = Signal(object, object)
    _pick = Signal(float, float)

    def __init__(self, camera, parent=None):
        super().__init__("영상 분석 · 탐사", parent)
        self.camera = camera
        self.settings = QSettings('SPIKE-Rover', 'Analysis')
        self.mode = "raw"
        self.busy = False
        self.pending = None
        self.custom = None
        self.qr_history = {}          # text -> [첫 인식 시각, 마지막 시각, 횟수]
        self.proc_count = 0
        self.proc_at = time.monotonic()
        self.proc_fps = 0.0
        self.last_error = ""
        self._last_items = None

        root = QVBoxLayout(self)
        root.setSpacing(6)

        # ---- 분석 방식 선택 (배타 버튼 6개: 원본 + 5가지) ----
        grid = QGridLayout(); grid.setSpacing(4)
        self.group = QButtonGroup(self); self.group.setExclusive(True)
        self.mode_buttons = {}
        for i, (key, name, tip) in enumerate(va.MODES):
            b = QPushButton(name); b.setCheckable(True); b.setToolTip(tip)
            b.setFocusPolicy(Qt.NoFocus); b.setMinimumHeight(30)
            b.setObjectName("mode")
            self.group.addButton(b, i)
            self.mode_buttons[key] = b
            grid.addWidget(b, i // 2, i % 2)
        self.group.idClicked.connect(lambda i: self.set_mode(va.MODES[i][0]))
        root.addLayout(grid)

        self.lb_desc = QLabel(); self.lb_desc.setWordWrap(True)
        self.lb_desc.setStyleSheet("color:#7f93ab;font-size:11px;")
        root.addWidget(self.lb_desc)

        # ---- 방식별 옵션 ----
        self.stack = QStackedWidget(); self.stack.setObjectName("clear")
        self.stack.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)
        self.pages = {}
        for key, _n, _t in va.MODES:
            page = QWidget(); page.setObjectName("clear")
            self.pages[key] = page
            self.stack.addWidget(page)
            getattr(self, f"_build_{key}")(page)
        root.addWidget(self.stack)

        line = QFrame(); line.setFrameShape(QFrame.HLine); line.setStyleSheet("color:#1e2a3a;")
        root.addWidget(line)

        # ---- 결과 ----
        self.lb_summary = QLabel("분석 꺼짐 (원본)")
        self.lb_summary.setWordWrap(True)
        self.lb_summary.setStyleSheet("font-size:15px;font-weight:700;color:#7fe3ff;")
        root.addWidget(self.lb_summary)
        self.lb_target = QLabel("목표 방향: --")
        self.lb_target.setStyleSheet("font-family:'D2Coding','Consolas',monospace;"
                                     "font-size:13px;font-weight:700;color:#ffd24a;")
        root.addWidget(self.lb_target)
        self.lst = QListWidget()
        self.lst.setFocusPolicy(Qt.NoFocus)
        self.lst.setMinimumHeight(80)
        root.addWidget(self.lst, 1)
        self.lb_perf = QLabel("")
        self.lb_perf.setStyleSheet("color:#44566a;font-size:10px;")
        root.addWidget(self.lb_perf)

        # ---- 작업 스레드 ----
        self.thread = None
        if va.HAVE_CV:
            self.thread = QThread(self)
            self.worker = va.AnalysisWorker()
            self.worker.moveToThread(self.thread)
            self._request.connect(self.worker.process)
            self._pick.connect(self.worker.pick)
            self.worker.done.connect(self.on_done)
            self.worker.picked.connect(self.on_picked)
            self.thread.start()
        else:
            for key, b in self.mode_buttons.items():
                b.setEnabled(key == "raw")
            self.lb_summary.setText("영상 분석 사용 불가")
            self.lst.addItem("OpenCV가 설치되어 있지 않습니다.")
            self.lst.addItem("python -m pip install -r requirements.txt")
            self.lst.addItem("원본 영상 표시와 조종은 그대로 사용할 수 있습니다.")

        camera.frame_ready.connect(self.on_frame)
        camera.clicked.connect(self.on_camera_click)
        camera.view_changed.connect(self._reset_pipeline)

        saved = self.settings.value("mode", "raw")
        self.set_mode(saved if (va.HAVE_CV and saved in va.MODE_NAMES) else "raw")

    # ================================================================ 옵션 페이지
    def _build_raw(self, page):
        lay = QVBoxLayout(page); lay.setContentsMargins(0, 0, 0, 0)
        lb = QLabel("분석 방식을 고르면 영상 위에 결과가 표시됩니다.\n"
                    "영상 창을 클릭하면 ②색상 선택에서 색을 지정할 수 있습니다.")
        lb.setWordWrap(True); lb.setStyleSheet("color:#7f93ab;")
        lay.addWidget(lb)

    def _build_qr(self, page):
        lay = QGridLayout(page); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(4)
        self.ck_qr_log = QCheckBox("새 QR을 통신 로그에 기록"); self.ck_qr_log.setChecked(True)
        self.ck_qr_log.setFocusPolicy(Qt.NoFocus)
        lay.addWidget(self.ck_qr_log, 0, 0, 1, 3)
        b1 = QPushButton("선택 복사"); b1.clicked.connect(self.copy_qr)
        b2 = QPushButton("CSV 저장"); b2.clicked.connect(self.save_qr)
        b3 = QPushButton("목록 지우기"); b3.clicked.connect(self.clear_qr)
        for i, b in enumerate((b1, b2, b3)):
            b.setFocusPolicy(Qt.NoFocus); lay.addWidget(b, 1, i)
        hint = QLabel("아래 목록: 지금까지 인식한 QR (처음 시각 · 횟수)")
        hint.setStyleSheet("color:#7f93ab;font-size:10px;")
        lay.addWidget(hint, 2, 0, 1, 3)

    def _build_color(self, page):
        lay = QGridLayout(page); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(4)
        saved = self.settings.value("colors", "빨강")
        saved = saved if isinstance(saved, list) else [c for c in str(saved).split(",") if c]
        self.color_checks = {}
        for i, (name, _r, rgb) in enumerate(va.COLOR_DEFS):
            ck = QCheckBox(name); ck.setFocusPolicy(Qt.NoFocus)
            ck.setChecked(name in saved)
            ck.setStyleSheet(f"QCheckBox{{color:rgb{rgb};font-weight:700;}}")
            ck.toggled.connect(self._save_colors)
            self.color_checks[name] = ck
            lay.addWidget(ck, i // 3, i % 3)
        row = QHBoxLayout()
        self.ck_custom = QCheckBox("지정색"); self.ck_custom.setFocusPolicy(Qt.NoFocus)
        self.ck_custom.setEnabled(False)
        self.sw_custom = QLabel(); self.sw_custom.setFixedSize(22, 16)
        self.sw_custom.setStyleSheet("background:#0b111a;border:1px solid #294254;")
        self.btn_pick = QPushButton("🎯 영상 클릭으로 색 지정"); self.btn_pick.setCheckable(True)
        self.btn_pick.setFocusPolicy(Qt.NoFocus)
        self.btn_pick.toggled.connect(self.camera.set_pick_mode)
        row.addWidget(self.ck_custom); row.addWidget(self.sw_custom); row.addWidget(self.btn_pick, 1)
        lay.addLayout(row, 2, 0, 1, 3)

        self.sl_area = _slider(1, 100, int(self.settings.value("min_area", 4)))       # 0.1% 단위
        self.sl_smin = _slider(20, 220, int(self.settings.value("s_min", 90)))
        self.sl_vmin = _slider(20, 220, int(self.settings.value("v_min", 60)))
        self.sl_tol = _slider(3, 30, int(self.settings.value("hue_tol", 10)))
        self.lb_area = QLabel(); self.lb_smin = QLabel(); self.lb_vmin = QLabel(); self.lb_tol = QLabel()
        rows = ((self.lb_area, self.sl_area), (self.lb_smin, self.sl_smin),
                (self.lb_vmin, self.sl_vmin), (self.lb_tol, self.sl_tol))
        for i, (lb, sl) in enumerate(rows):
            lb.setMinimumWidth(92)
            lay.addWidget(lb, 3 + i, 0); lay.addWidget(sl, 3 + i, 1, 1, 2)
            sl.valueChanged.connect(self._update_labels)
        self.ck_isolate = QCheckBox("선택한 색만 컬러로 보기 (나머지 흑백)")
        self.ck_isolate.setChecked(self.settings.value("isolate", "true") in (True, "true"))
        self.ck_isolate.setFocusPolicy(Qt.NoFocus)
        lay.addWidget(self.ck_isolate, 7, 0, 1, 3)
        self._update_labels()

    def _build_shape(self, page):
        lay = QGridLayout(page); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(4)
        self.sl_shape = _slider(2, 100, int(self.settings.value("shape_min", 10)))   # 0.1% 단위
        self.lb_shape = QLabel(); self.lb_shape.setMinimumWidth(92)
        self.sl_shape.valueChanged.connect(self._update_labels)
        lay.addWidget(self.lb_shape, 0, 0); lay.addWidget(self.sl_shape, 0, 1)
        self.ck_shape_color = QCheckBox("도형의 색 이름도 표시"); self.ck_shape_color.setChecked(True)
        self.ck_shape_color.setFocusPolicy(Qt.NoFocus)
        lay.addWidget(self.ck_shape_color, 1, 0, 1, 2)
        hint = QLabel("단색 바탕 위의 또렷한 도형 카드에서 가장 잘 동작합니다.")
        hint.setWordWrap(True); hint.setStyleSheet("color:#7f93ab;font-size:10px;")
        lay.addWidget(hint, 2, 0, 1, 2)
        self._update_labels()

    def _build_motion(self, page):
        lay = QGridLayout(page); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(4)
        self.sl_motion = _slider(1, 100, int(self.settings.value("motion_sens", 50)))
        self.lb_motion = QLabel(); self.lb_motion.setMinimumWidth(92)
        self.sl_motion.valueChanged.connect(self._update_labels)
        lay.addWidget(self.lb_motion, 0, 0); lay.addWidget(self.sl_motion, 0, 1)
        hint = QLabel("로버를 멈춘 상태에서 감시용으로 사용하세요. 로버가 움직이면 화면 전체가 변화로 잡힙니다.")
        hint.setWordWrap(True); hint.setStyleSheet("color:#7f93ab;font-size:10px;")
        lay.addWidget(hint, 1, 0, 1, 2)
        self._update_labels()

    def _build_edge(self, page):
        lay = QGridLayout(page); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(4)
        self.sl_edge = _slider(1, 100, int(self.settings.value("edge_sens", 60)))
        self.lb_edge = QLabel(); self.lb_edge.setMinimumWidth(92)
        self.sl_edge.valueChanged.connect(self._update_labels)
        lay.addWidget(self.lb_edge, 0, 0); lay.addWidget(self.sl_edge, 0, 1)
        hint = QLabel("화면 아래 2/3를 좌·중·우로 나눠 윤곽선이 적은(트인) 방향을 추정합니다. "
                      "거리센서 값과 함께 참고하세요.")
        hint.setWordWrap(True); hint.setStyleSheet("color:#7f93ab;font-size:10px;")
        lay.addWidget(hint, 1, 0, 1, 2)
        self._update_labels()

    def _update_labels(self, *_):
        if hasattr(self, "sl_area"):
            self.lb_area.setText(f"최소 크기 {self.sl_area.value() / 10:.1f}%")
            self.lb_smin.setText(f"채도 하한 {self.sl_smin.value()}")
            self.lb_vmin.setText(f"밝기 하한 {self.sl_vmin.value()}")
            self.lb_tol.setText(f"지정색 폭 ±{self.sl_tol.value()}")
        if hasattr(self, "sl_shape"):
            self.lb_shape.setText(f"최소 크기 {self.sl_shape.value() / 10:.1f}%")
        if hasattr(self, "sl_motion"):
            self.lb_motion.setText(f"민감도 {self.sl_motion.value()}")
        if hasattr(self, "sl_edge"):
            self.lb_edge.setText(f"민감도 {self.sl_edge.value()}")

    def _save_colors(self, *_):
        self.settings.setValue("colors", ",".join(n for n, c in self.color_checks.items() if c.isChecked()))

    # ================================================================ 동작
    def params(self):
        p = dict(va.DEFAULT_PARAMS)
        p.update(self.camera.view_params())
        p.update(
            mode=self.mode,
            colors=[n for n, c in self.color_checks.items() if c.isChecked()],
            custom=self.custom if self.ck_custom.isChecked() else None,
            hue_tol=self.sl_tol.value(), s_min=self.sl_smin.value(), v_min=self.sl_vmin.value(),
            min_area=self.sl_area.value() / 10.0, isolate=self.ck_isolate.isChecked(),
            shape_min=self.sl_shape.value() / 10.0, shape_color=self.ck_shape_color.isChecked(),
            motion_sens=self.sl_motion.value(), edge_sens=self.sl_edge.value(),
        )
        return p

    def set_mode(self, key):
        if key != "raw" and not va.HAVE_CV:
            key = "raw"
        self.mode = key
        self.mode_buttons[key].setChecked(True)
        # 현재 옵션 페이지 높이만 차지하도록(빈 공간 없이 결과 목록을 넓게)
        for k, pg in self.pages.items():
            pg.setSizePolicy(QSizePolicy.Preferred,
                             QSizePolicy.Preferred if k == key else QSizePolicy.Ignored)
        self.stack.setCurrentWidget(self.pages[key])
        self.pages[key].adjustSize()
        self.stack.adjustSize()
        self.lb_desc.setText(dict((k, t) for k, _n, t in va.MODES)[key])
        self.settings.setValue("mode", key)
        if key != "color" and hasattr(self, "btn_pick"):
            self.btn_pick.setChecked(False)
        self._reset_pipeline()
        self.camera.set_processing(key != "raw")
        self.lst.clear()
        self._last_items = None
        if key == "raw":
            self.lb_summary.setText("분석 꺼짐 (원본)" if va.HAVE_CV else "영상 분석 사용 불가")
            self.lb_target.setText("목표 방향: --")
            self.lb_perf.setText("")
        else:
            self.lb_summary.setText("영상 대기 중…" if not self.camera.frame_fresh() else "분석 중…")
            if key == "qr":
                self._refresh_qr_list()

    def _reset_pipeline(self):
        self.pending = None

    def on_frame(self, jpeg):
        if self.mode == "raw" or self.thread is None:
            return
        if self.busy:
            self.pending = jpeg            # 가장 최근 프레임만 대기
            return
        self._submit(jpeg)

    def _submit(self, jpeg):
        self.busy = True
        self._request.emit(jpeg, self.params())

    def on_done(self, image, result):
        self.busy = False
        if "error" in result:
            if result["error"] != self.last_error:
                self.last_error = result["error"]
                self.log.emit("영상 분석 오류: " + result["error"], "warn")
        elif result.get("mode") == self.mode:
            self.camera.show_processed(image)
            self.show_result(result)
        nxt, self.pending = self.pending, None
        if nxt is not None and self.mode != "raw":
            self._submit(nxt)

    def show_result(self, r):
        self.proc_count += 1
        now = time.monotonic()
        if now - self.proc_at >= 1.0:
            self.proc_fps = self.proc_count / (now - self.proc_at)
            self.proc_count, self.proc_at = 0, now
        self.lb_perf.setText(f"처리 {r.get('ms', 0):.0f} ms · 분석 {self.proc_fps:.1f} FPS")
        self.lb_summary.setText(r.get("summary", ""))
        t = r.get("target")
        if t:
            self.lb_target.setText("목표 방향: " + va.horizontal_word(t[0]))
        else:
            self.lb_target.setText("목표 방향: --")
        if self.mode == "qr":
            self._update_qr(r.get("codes", []))
            return
        items = r.get("items", [])
        if items != self._last_items:           # 같은 내용이면 다시 그리지 않음(깜빡임 방지)
            self._last_items = items
            self.lst.clear()
            self.lst.addItems(items)

    # ---------------------------------------------------------------- QR 기록
    def _update_qr(self, codes):
        now = time.strftime("%H:%M:%S")
        changed = False
        for text in codes:
            rec = self.qr_history.get(text)
            if rec is None:
                self.qr_history[text] = [now, now, 1]
                changed = True
                if self.ck_qr_log.isChecked():
                    self.log.emit(f"📷 QR 인식: {text}", "tx")
            else:
                rec[1] = now; rec[2] += 1
        if changed or codes:
            self._refresh_qr_list()

    def _refresh_qr_list(self):
        cur = self.lst.currentRow()
        self.lst.clear()
        if not self.qr_history:
            self.lst.addItem("아직 인식한 QR이 없습니다.")
            return
        for text, (first, _last, count) in self.qr_history.items():
            self.lst.addItem(f"{first}  ×{count:<4} {text}")
        if 0 <= cur < self.lst.count():
            self.lst.setCurrentRow(cur)

    def copy_qr(self):
        row = self.lst.currentRow()
        keys = list(self.qr_history)
        if self.mode == "qr" and 0 <= row < len(keys):
            QGuiApplication.clipboard().setText(keys[row])
            self.log.emit("QR 내용 복사: " + keys[row], "info")

    def save_qr(self):
        if not self.qr_history:
            self.log.emit("저장할 QR 기록이 없습니다.", "warn")
            return
        path, _ = QFileDialog.getSaveFileName(self, "QR 기록 저장",
            time.strftime("qr_log_%Y%m%d_%H%M%S.csv"), "CSV (*.csv)")
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as fp:
            w = csv.writer(fp)
            w.writerow(["내용", "처음 인식", "마지막 인식", "횟수"])
            for text, (first, last, count) in self.qr_history.items():
                w.writerow([text, first, last, count])
        self.log.emit("QR 기록 저장: " + path, "info")

    def clear_qr(self):
        self.qr_history.clear()
        if self.mode == "qr":
            self._refresh_qr_list()

    # ---------------------------------------------------------------- 색 지정
    def on_camera_click(self, nx, ny):
        if not self.btn_pick.isChecked() or self.thread is None:
            return
        if self.mode != "color":
            self.set_mode("color")
        self._pick.emit(nx, ny)

    def on_picked(self, d):
        self.custom = d
        r, g, b = d["rgb"]
        h, s, v = d["hsv"]
        self.sw_custom.setStyleSheet(f"background:rgb({r},{g},{b});border:1px solid #dce6f2;")
        self.ck_custom.setEnabled(True)
        self.ck_custom.setChecked(True)
        self.ck_custom.setText(f"지정색 ({va.hsv_color_name(h, s, v)})")
        self.btn_pick.setChecked(False)
        self.log.emit(f"지정색 선택: RGB({r},{g},{b}) · HSV({h},{s},{v})", "info")

    # ---------------------------------------------------------------- 종료
    def shutdown(self):
        self.settings.setValue("min_area", self.sl_area.value())
        self.settings.setValue("s_min", self.sl_smin.value())
        self.settings.setValue("v_min", self.sl_vmin.value())
        self.settings.setValue("hue_tol", self.sl_tol.value())
        self.settings.setValue("isolate", "true" if self.ck_isolate.isChecked() else "false")
        self.settings.setValue("shape_min", self.sl_shape.value())
        self.settings.setValue("motion_sens", self.sl_motion.value())
        self.settings.setValue("edge_sens", self.sl_edge.value())
        if self.thread is not None:
            self.thread.quit()
            self.thread.wait(1500)
