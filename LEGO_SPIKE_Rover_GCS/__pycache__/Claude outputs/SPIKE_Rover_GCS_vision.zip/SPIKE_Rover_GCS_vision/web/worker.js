/* =============================================================================
 * 영상 분석 워커 — vision_analysis.py 의 브라우저 판
 *  QR(jsQR) / 색상 선택 / 도형 / 움직임 / 윤곽·장애물
 *  메인 스레드는 준비된 RGBA 프레임을 넘기고, 결과(수정 픽셀 + 그리기 목록)를 받는다.
 * ========================================================================== */
'use strict';

const COLOR_DEFS = [
  ['빨강', [[0, 8], [170, 179]], [255, 70, 70]],
  ['주황', [[9, 21]], [255, 150, 40]],
  ['노랑', [[22, 34]], [255, 225, 40]],
  ['초록', [[35, 85]], [70, 220, 90]],
  ['파랑', [[90, 128]], [60, 140, 255]],
  ['보라', [[129, 169]], [200, 90, 230]],
];

function hsvColorName(h, s, v) {
  if (v < 50) return '검정';
  if (s < 45) return v > 170 ? '흰색' : '회색';
  for (const [name, ranges] of COLOR_DEFS)
    for (const [lo, hi] of ranges) if (h >= lo && h <= hi) return name;
  return '청록';
}

function horizontalWord(dx) {
  const pct = Math.round(Math.abs(dx) * 100);
  if (pct < 12) return '정면';
  return (dx < 0 ? '◀ 왼쪽 ' : '오른쪽 ▶ ') + pct + '%';
}

// ---------------------------------------------------------------- 기본 연산
// OpenCV 8비트 HSV: H 0~179, S/V 0~255
function rgbToHsv(r, g, b) {
  const v = Math.max(r, g, b), mn = Math.min(r, g, b), d = v - mn;
  const s = v === 0 ? 0 : Math.round(d * 255 / v);
  let h = 0;
  if (d !== 0) {
    if (v === r) h = 60 * (g - b) / d;
    else if (v === g) h = 120 + 60 * (b - r) / d;
    else h = 240 + 60 * (r - g) / d;
    if (h < 0) h += 360;
  }
  return [Math.round(h / 2) % 180, s, v];
}

function hsvPlanes(px, n) {
  const H = new Uint8Array(n), S = new Uint8Array(n), V = new Uint8Array(n);
  for (let i = 0, j = 0; i < n; i++, j += 4) {
    const r = px[j], g = px[j + 1], b = px[j + 2];
    const v = r > g ? (r > b ? r : b) : (g > b ? g : b);
    const mn = r < g ? (r < b ? r : b) : (g < b ? g : b);
    const d = v - mn;
    V[i] = v;
    S[i] = v === 0 ? 0 : (d * 255 / v + 0.5) | 0;
    if (d === 0) { H[i] = 0; continue; }
    let h;
    if (v === r) h = 60 * (g - b) / d;
    else if (v === g) h = 120 + 60 * (b - r) / d;
    else h = 240 + 60 * (r - g) / d;
    if (h < 0) h += 360;
    H[i] = ((h / 2 + 0.5) | 0) % 180;
  }
  return [H, S, V];
}

function toGray(px, n) {
  const g = new Uint8Array(n);
  for (let i = 0, j = 0; i < n; i++, j += 4)
    g[i] = (px[j] * 299 + px[j + 1] * 587 + px[j + 2] * 114 + 500) / 1000 | 0;
  return g;
}

function channel(px, n, c) {
  const out = new Uint8Array(n);
  for (let i = 0, j = c; i < n; i++, j += 4) out[i] = px[j];
  return out;
}

// 가우시안 5×5 근사 (1 4 6 4 1)/16 분리형
function blur5(src, w, h) {
  const tmp = new Float32Array(w * h), out = new Uint8Array(w * h);
  const k = [1, 4, 6, 4, 1];
  for (let y = 0; y < h; y++) {
    const o = y * w;
    for (let x = 0; x < w; x++) {
      let s = 0;
      for (let t = -2; t <= 2; t++) {
        let xx = x + t; xx = xx < 0 ? -xx : (xx >= w ? 2 * w - xx - 2 : xx);
        s += src[o + xx] * k[t + 2];
      }
      tmp[o + x] = s / 16;
    }
  }
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let s = 0;
      for (let t = -2; t <= 2; t++) {
        let yy = y + t; yy = yy < 0 ? -yy : (yy >= h ? 2 * h - yy - 2 : yy);
        s += tmp[yy * w + x] * k[t + 2];
      }
      out[y * w + x] = (s / 16 + 0.5) | 0;
    }
  }
  return out;
}

function blurRGBA(px, w, h) {
  const n = w * h, out = new Uint8ClampedArray(px.length);
  for (let c = 0; c < 3; c++) {
    const b = blur5(channel(px, n, c), w, h);
    for (let i = 0, j = c; i < n; i++, j += 4) out[j] = b[i];
  }
  return out;
}

// 상자 블러 (반경 r) — 움직임 감지의 21×21 가우시안 대용 (2회 적용)
function boxBlur(src, w, h, r) {
  const tmp = new Float32Array(w * h), out = new Uint8Array(w * h);
  for (let y = 0; y < h; y++) {
    const o = y * w; let s = 0, cnt = 0;
    for (let x = -r; x <= r; x++) if (x >= 0 && x < w) { s += src[o + x]; cnt++; }
    for (let x = 0; x < w; x++) {
      tmp[o + x] = s / cnt;
      const a = x - r, b = x + r + 1;
      if (a >= 0) { s -= src[o + a]; cnt--; }
      if (b < w) { s += src[o + b]; cnt++; }
    }
  }
  for (let x = 0; x < w; x++) {
    let s = 0, cnt = 0;
    for (let y = -r; y <= r; y++) if (y >= 0 && y < h) { s += tmp[y * w + x]; cnt++; }
    for (let y = 0; y < h; y++) {
      out[y * w + x] = (s / cnt + 0.5) | 0;
      const a = y - r, b = y + r + 1;
      if (a >= 0) { s -= tmp[a * w + x]; cnt--; }
      if (b < h) { s += tmp[b * w + x]; cnt++; }
    }
  }
  return out;
}

// 이진 영상 팽창/침식 (정사각 창, 반경 r) — 누적합 분리형
function morph(mask, w, h, r, dilate) {
  const tmp = new Uint8Array(w * h), out = new Uint8Array(w * h);
  const rowSum = new Int32Array(w + 1), colSum = new Int32Array(h + 1);
  const full = 2 * r + 1;
  for (let y = 0; y < h; y++) {
    const o = y * w;
    for (let x = 0; x < w; x++) rowSum[x + 1] = rowSum[x] + (mask[o + x] ? 1 : 0);
    for (let x = 0; x < w; x++) {
      const a = Math.max(0, x - r), b = Math.min(w, x + r + 1);
      const s = rowSum[b] - rowSum[a];
      // 영상 밖은 침식 시 1(영향 없음)로 취급
      tmp[o + x] = dilate ? (s > 0 ? 1 : 0) : (s === b - a ? 1 : 0);
    }
  }
  for (let x = 0; x < w; x++) {
    for (let y = 0; y < h; y++) colSum[y + 1] = colSum[y] + tmp[y * w + x];
    for (let y = 0; y < h; y++) {
      const a = Math.max(0, y - r), b = Math.min(h, y + r + 1);
      const s = colSum[b] - colSum[a];
      out[y * w + x] = dilate ? (s > 0 ? 1 : 0) : (s === b - a ? 1 : 0);
    }
  }
  return out;
}
const openMask = (m, w, h, r) => morph(morph(m, w, h, r, false), w, h, r, true);
const closeMask = (m, w, h, r) => morph(morph(m, w, h, r, true), w, h, r, false);

// Canny (Sobel L1 크기, 비최대 억제, 이력 임계) — OpenCV 기본값과 같은 방식
function canny(src, w, h, lo, hi) {
  const n = w * h, mag = new Float32Array(n), dir = new Uint8Array(n);
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x;
      const a = src[i - w - 1], b = src[i - w], c = src[i - w + 1];
      const d = src[i - 1], f = src[i + 1];
      const g = src[i + w - 1], k = src[i + w], l = src[i + w + 1];
      const gx = (c + 2 * f + l) - (a + 2 * d + g);
      const gy = (g + 2 * k + l) - (a + 2 * b + c);
      mag[i] = Math.abs(gx) + Math.abs(gy);
      const ax = Math.abs(gx), ay = Math.abs(gy);
      // 0: 수평 기울기(좌우 비교) 1: 45° 2: 수직 3: 135°
      if (ay <= ax * 0.4142) dir[i] = 0;
      else if (ay >= ax * 2.4142) dir[i] = 2;
      else dir[i] = (gx > 0) === (gy > 0) ? 1 : 3;
    }
  }
  const state = new Uint8Array(n);      // 0 없음 1 약 2 강
  const stack = [];
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const i = y * w + x, m = mag[i];
      if (m <= lo) continue;
      let p, q;
      switch (dir[i]) {
        case 0: p = mag[i - 1]; q = mag[i + 1]; break;
        case 2: p = mag[i - w]; q = mag[i + w]; break;
        case 1: p = mag[i - w - 1]; q = mag[i + w + 1]; break;
        default: p = mag[i - w + 1]; q = mag[i + w - 1];
      }
      if (m > p && m >= q) {
        if (m > hi) { state[i] = 2; stack.push(i); } else state[i] = 1;
      }
    }
  }
  const out = new Uint8Array(n);
  while (stack.length) {
    const i = stack.pop();
    if (out[i]) continue;
    out[i] = 1;
    const nb = [i - w - 1, i - w, i - w + 1, i - 1, i + 1, i + w - 1, i + w, i + w + 1];
    for (const j of nb) if (j >= 0 && j < n && state[j] && !out[j]) stack.push(j);
  }
  return out;
}

// 8-연결 연결요소. minArea 이상만 반환 (라벨 영상 포함)
function components(mask, w, h, minArea) {
  const n = w * h, label = new Int32Array(n), comps = [];
  let id = 0;
  const stack = new Int32Array(n);
  for (let s = 0; s < n; s++) {
    if (!mask[s] || label[s]) continue;
    id++;
    let sp = 0; stack[sp++] = s; label[s] = id;
    let area = 0, minx = w, miny = h, maxx = 0, maxy = 0, start = s;
    while (sp) {
      const i = stack[--sp];
      area++;
      const x = i % w, y = (i / w) | 0;
      if (x < minx) minx = x; if (x > maxx) maxx = x;
      if (y < miny) miny = y; if (y > maxy) maxy = y;
      if (i < start) start = i;
      for (let dy = -1; dy <= 1; dy++) {
        const yy = y + dy; if (yy < 0 || yy >= h) continue;
        for (let dx = -1; dx <= 1; dx++) {
          const xx = x + dx; if (xx < 0 || xx >= w) continue;
          const j = yy * w + xx;
          if (mask[j] && !label[j]) { label[j] = id; stack[sp++] = j; }
        }
      }
    }
    if (area >= minArea) comps.push({ id, area, minx, miny, maxx, maxy, start });
  }
  return { label, comps };
}

// 무어 이웃 외곽선 추적 → 점 목록 [x,y]
function traceBoundary(label, w, h, id, start) {
  const dirs = [[1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1]];
  const inside = (x, y) => x >= 0 && y >= 0 && x < w && y < h && label[y * w + x] === id;
  const sx = start % w, sy = (start / w) | 0;
  const pts = [[sx, sy]];
  let x = sx, y = sy, d = 7, guard = 0;
  const maxSteps = 4 * (w + h) * 8;
  while (guard++ < maxSteps) {
    let found = false;
    for (let k = 0; k < 8; k++) {
      const nd = (d + 6 + k) % 8;          // 왼쪽 뒤부터 시계방향 탐색
      const nx = x + dirs[nd][0], ny = y + dirs[nd][1];
      if (inside(nx, ny)) { x = nx; y = ny; d = nd; found = true; break; }
    }
    if (!found) break;
    if (x === sx && y === sy) break;
    pts.push([x, y]);
  }
  return pts;
}

function perimeter(pts) {
  let p = 0;
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i], b = pts[(i + 1) % pts.length];
    p += Math.hypot(a[0] - b[0], a[1] - b[1]);
  }
  return p;
}

function polyArea(pts) {
  let s = 0;
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i], b = pts[(i + 1) % pts.length];
    s += a[0] * b[1] - b[0] * a[1];
  }
  return Math.abs(s) / 2;
}

// 닫힌 곡선 Douglas-Peucker (cv2.approxPolyDP 대용)
function approxPoly(pts, eps) {
  if (pts.length < 4) return pts.slice();
  // 가장 먼 두 점으로 둘로 나눈 뒤 각각 단순화
  let a = 0, b = 0, best = -1;
  const p0 = pts[0];
  for (let i = 1; i < pts.length; i++) {
    const d = (pts[i][0] - p0[0]) ** 2 + (pts[i][1] - p0[1]) ** 2;
    if (d > best) { best = d; a = i; }
  }
  best = -1;
  for (let i = 0; i < pts.length; i++) {
    const d = (pts[i][0] - pts[a][0]) ** 2 + (pts[i][1] - pts[a][1]) ** 2;
    if (d > best) { best = d; b = i; }
  }
  const i1 = Math.min(a, b), i2 = Math.max(a, b);
  const simplify = (arr) => {
    if (arr.length < 3) return arr;
    const s = arr[0], e = arr[arr.length - 1];
    const dx = e[0] - s[0], dy = e[1] - s[1], L = Math.hypot(dx, dy) || 1;
    let idx = 0, dmax = 0;
    for (let i = 1; i < arr.length - 1; i++) {
      const d = Math.abs(dy * arr[i][0] - dx * arr[i][1] + e[0] * s[1] - e[1] * s[0]) / L;
      if (d > dmax) { dmax = d; idx = i; }
    }
    if (dmax > eps) {
      const l = simplify(arr.slice(0, idx + 1)), r = simplify(arr.slice(idx));
      return l.slice(0, -1).concat(r);
    }
    return [s, e];
  };
  const first = simplify(pts.slice(i1, i2 + 1));
  const second = simplify(pts.slice(i2).concat(pts.slice(0, i1 + 1)));
  return first.slice(0, -1).concat(second.slice(0, -1));
}

function classifyShape(pts, area) {
  const peri = perimeter(pts);
  if (peri <= 0 || area <= 0) return null;
  const approx = approxPoly(pts, 0.035 * peri);
  const n = approx.length;
  const circ = 4 * Math.PI * area / (peri * peri);
  if (n === 3) return '삼각형';
  if (n === 4) {
    const s = [0, 1, 2, 3].map(i => Math.hypot(approx[i][0] - approx[(i + 1) % 4][0],
                                               approx[i][1] - approx[(i + 1) % 4][1]));
    const a = (s[0] + s[2]) / 2, b = (s[1] + s[3]) / 2;
    return Math.min(a, b) / Math.max(a, b) > 0.85 ? '정사각형' : '직사각형';
  }
  if (circ > 0.80 && n >= 7) return '원';
  if (n === 5) return '오각형';
  if (n === 6) return '육각형';
  return circ > 0.80 ? '원' : null;
}

// ---------------------------------------------------------------- ① QR
function runQr(px, w, h) {
  const draw = [], labels = [], items = [], codes = [];
  let target = null, best = 0;
  const jsQR = self.jsQR || (typeof globalThis.jsQR === 'function' ? globalThis.jsQR : null);
  if (typeof jsQR !== 'function')
    return { summary: 'QR 해독기 없음', items: ['jsQR 로드 실패'], draw, labels, codes, target };
  const work = new Uint8ClampedArray(px);           // 찾은 QR을 지우며 여러 개 탐색
  for (let k = 0; k < 4; k++) {
    const code = jsQR(work, w, h, { inversionAttempts: 'attemptBoth' });
    if (!code) break;
    const L = code.location;
    const pts = [L.topLeftCorner, L.topRightCorner, L.bottomRightCorner, L.bottomLeftCorner]
      .map(p => [p.x, p.y]);
    const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]);
    const text = code.data || '';
    const rgb = [60, 230, 120];
    draw.push({ t: 'poly', pts, color: rgb, lw: 3 });
    const cx = xs.reduce((a, b) => a + b) / 4, cy = ys.reduce((a, b) => a + b) / 4;
    const dx = (cx - w / 2) / (w / 2);
    const shown = text.length <= 28 ? text : text.slice(0, 27) + '…';
    labels.push([Math.min(...xs), Math.min(...ys) - 4, shown || '(빈 QR)', rgb]);
    if (!codes.includes(text)) { codes.push(text); items.push(`[QR] ${text}   (${horizontalWord(dx)})`); }
    const area = polyArea(pts);
    if (area > best) { best = area; target = [dx, (cy - h / 2) / (h / 2)]; }
    // 찾은 영역을 흰색으로 덮고 다음 QR 탐색
    const mx = Math.max(...xs) - Math.min(...xs), my = Math.max(...ys) - Math.min(...ys);
    const x0 = Math.max(0, Math.floor(Math.min(...xs) - mx * 0.2)), x1 = Math.min(w, Math.ceil(Math.max(...xs) + mx * 0.2));
    const y0 = Math.max(0, Math.floor(Math.min(...ys) - my * 0.2)), y1 = Math.min(h, Math.ceil(Math.max(...ys) + my * 0.2));
    for (let y = y0; y < y1; y++) work.fill(255, (y * w + x0) * 4, (y * w + x1) * 4);
  }
  const summary = codes.length ? `QR ${codes.length}개 인식` : 'QR 없음';
  return { summary, items, codes, target, draw, labels };
}

// ---------------------------------------------------------------- ② 색상
function colorMasks(H, S, V, n, p) {
  const sMin = p.s_min | 0, vMin = p.v_min | 0, masks = [];
  for (const [name, ranges, rgb] of COLOR_DEFS) {
    if (!p.colors.includes(name)) continue;
    const m = new Uint8Array(n);
    for (let i = 0; i < n; i++) {
      if (S[i] < sMin || V[i] < vMin) continue;
      const hh = H[i];
      for (const [lo, hi] of ranges) if (hh >= lo && hh <= hi) { m[i] = 1; break; }
    }
    masks.push([name, rgb, m]);
  }
  if (p.custom) {
    const [h, s, v] = p.custom.hsv, rgb = p.custom.rgb, m = new Uint8Array(n);
    if (s < 45) {
      const lo = Math.max(0, v - 40), hi = Math.min(255, v + 40);
      for (let i = 0; i < n; i++) if (S[i] <= 70 && V[i] >= lo && V[i] <= hi) m[i] = 1;
    } else {
      const tol = p.hue_tol | 0, loS = Math.max(40, (s * 0.5) | 0), loV = Math.max(40, (v * 0.4) | 0);
      for (let i = 0; i < n; i++) {
        if (S[i] < loS || V[i] < loV) continue;
        let d = Math.abs(H[i] - h); d = Math.min(d, 180 - d);
        if (d <= tol) m[i] = 1;
      }
    }
    masks.push(['지정색', rgb, m]);
  }
  return masks;
}

function runColor(px, w, h, p) {
  const n = w * h;
  const [H, S, V] = hsvPlanes(blurRGBA(px, w, h), n);
  const minPx = p.min_area / 100 * n;
  const masks = colorMasks(H, S, V, n, p);
  const union = new Uint8Array(n), items = [], blobs = [];
  for (const [name, rgb, m0] of masks) {
    const m = closeMask(openMask(m0, w, h, 2), w, h, 2);
    for (let i = 0; i < n; i++) if (m[i]) union[i] = 1;
    const { label, comps } = components(m, w, h, minPx);
    const found = comps.sort((a, b) => b.area - a.area).slice(0, 6);
    for (const c of found) blobs.push({ area: c.area, name, rgb, c, pts: traceBoundary(label, w, h, c.id, c.start) });
    if (found.length) {
      const c = found[0], dx = ((c.minx + c.maxx) / 2 - w / 2) / (w / 2);
      items.push(`${name}: ${found.length}개 · 최대 ${(c.area / n * 100).toFixed(1)}% · ${horizontalWord(dx)}`);
    } else items.push(`${name}: 없음`);
  }
  let modified = false;
  if (p.isolate && masks.length) {
    modified = true;
    for (let i = 0, j = 0; i < n; i++, j += 4) {
      if (union[i]) continue;
      const g = ((px[j] * 299 + px[j + 1] * 587 + px[j + 2] * 114) / 1000) * 0.55;
      px[j] = px[j + 1] = px[j + 2] = g;
    }
  }
  const draw = [], labels = [];
  let target = null;
  blobs.sort((a, b) => b.area - a.area).forEach((b, i) => {
    const { c } = b;
    draw.push({ t: 'poly', pts: b.pts, color: b.rgb, lw: 2 });
    draw.push({ t: 'rect', x: c.minx, y: c.miny, w: c.maxx - c.minx + 1, h: c.maxy - c.miny + 1, color: b.rgb, lw: 1 });
    labels.push([c.minx, c.miny - 4, `${b.name} ${(b.area / n * 100).toFixed(1)}%`, b.rgb]);
    if (i === 0) target = [((c.minx + c.maxx) / 2 - w / 2) / (w / 2), ((c.miny + c.maxy) / 2 - h / 2) / (h / 2)];
  });
  let cover = 0; for (let i = 0; i < n; i++) cover += union[i];
  const summary = !masks.length ? '검출할 색을 선택하세요' : (blobs.length ? `색 영역 ${blobs.length}개 검출` : '선택한 색 없음');
  return { summary, items, target, draw, labels, modified, coverage: cover / n * 100 };
}

// ---------------------------------------------------------------- ③ 도형
function runShape(px, w, h, p) {
  const n = w * h;
  const blurred = blurRGBA(px, w, h);
  // 밝기가 비슷한 색 도형도 잡도록 R/G/B 채널별 윤곽선을 합친다
  let edges = new Uint8Array(n);
  for (let c = 0; c < 3; c++) {
    const e = canny(channel(blurred, n, c), w, h, 40, 120);
    for (let i = 0; i < n; i++) if (e[i]) edges[i] = 1;
  }
  edges = morph(edges, w, h, 1, true);
  // 바깥 배경을 테두리에서 채워 윤곽선 안쪽(구멍)을 찾는다 → 채워진 외곽 도형
  const outside = new Uint8Array(n), stack = [];
  const push = (i) => { if (!edges[i] && !outside[i]) { outside[i] = 1; stack.push(i); } };
  for (let x = 0; x < w; x++) { push(x); push((h - 1) * w + x); }
  for (let y = 0; y < h; y++) { push(y * w); push(y * w + w - 1); }
  while (stack.length) {
    const i = stack.pop(), x = i % w, y = (i / w) | 0;
    if (x > 0) push(i - 1); if (x < w - 1) push(i + 1);
    if (y > 0) push(i - w); if (y < h - 1) push(i + w);
  }
  const filled = new Uint8Array(n);
  for (let i = 0; i < n; i++) filled[i] = outside[i] ? 0 : 1;
  const minPx = p.shape_min / 100 * n;
  const { label, comps } = components(filled, w, h, minPx);
  const [H, S, V] = p.shape_color ? hsvPlanes(px, n) : [null, null, null];
  const found = [], draw = [], labels = [];
  for (const c of comps.sort((a, b) => b.area - a.area).slice(0, 15)) {
    if (c.area > 0.9 * n) continue;
    const pts = traceBoundary(label, w, h, c.id, c.start);
    if (pts.length < 8) continue;
    const kind = classifyShape(pts, polyArea(pts));
    if (!kind) continue;
    let name = kind;
    if (H) {
      // 윤곽선 두께를 뺀 안쪽 픽셀로 평균 색 계산
      let sh = 0, ss = 0, sv = 0, cnt = 0, hx = 0, hy = 0;
      for (let y = c.miny; y <= c.maxy; y++) for (let x = c.minx; x <= c.maxx; x++) {
        const i = y * w + x;
        if (label[i] !== c.id || edges[i]) continue;
        const a = H[i] * Math.PI / 90; hx += Math.cos(a); hy += Math.sin(a);
        ss += S[i]; sv += V[i]; cnt++;
      }
      if (cnt) {
        let hm = Math.atan2(hy, hx) * 90 / Math.PI; if (hm < 0) hm += 180;
        hm = Math.round(hm) % 180;
        name = `${hsvColorName(hm, ss / cnt, sv / cnt)} ${kind}`;
      }
    }
    const rgb = [0, 230, 255];
    draw.push({ t: 'poly', pts, color: rgb, lw: 2 });
    labels.push([c.minx, c.miny - 4, name, rgb]);
    found.push([c.area, name, ((c.minx + c.maxx) / 2 - w / 2) / (w / 2), ((c.miny + c.maxy) / 2 - h / 2) / (h / 2)]);
  }
  const counts = {};
  for (const f of found) { const k = f[1].split(' ').pop(); counts[k] = (counts[k] || 0) + 1; }
  const items = found.map(f => `${f[1]} · ${horizontalWord(f[2])} · ${(f[0] / n * 100).toFixed(1)}%`);
  const summary = Object.keys(counts).length ? Object.entries(counts).map(([k, v]) => `${k} ${v}`).join(' · ') : '도형 없음';
  const target = found.length ? [found[0][2], found[0][3]] : null;
  return { summary, items, target, counts, draw, labels };
}

// ---------------------------------------------------------------- ④ 움직임
let prevGray = null, prevKey = '';
function runMotion(px, w, h, p) {
  const n = w * h;
  const gray = boxBlur(boxBlur(toGray(px, n), w, h, 5), w, h, 5);
  const key = w + 'x' + h;
  if (!prevGray || prevKey !== key) {
    prevGray = gray; prevKey = key;
    return { summary: '기준 프레임 저장', items: [], target: null, motion: 0, draw: [], labels: [] };
  }
  const thr = Math.max(6, Math.round(60 - p.motion_sens * 0.54));
  let m = new Uint8Array(n);
  for (let i = 0; i < n; i++) if (Math.abs(gray[i] - prevGray[i]) > thr) m[i] = 1;
  prevGray = gray;
  m = morph(m, w, h, 2, true);
  let cnt = 0;
  for (let i = 0, j = 0; i < n; i++, j += 4) {
    if (!m[i]) continue;
    cnt++;
    px[j] = px[j] * 0.45 + 255 * 0.55; px[j + 1] = px[j + 1] * 0.45 + 40 * 0.55; px[j + 2] = px[j + 2] * 0.45 + 40 * 0.55;
  }
  const pct = cnt / n * 100;
  const { comps } = components(m, w, h, 0.003 * n);
  const boxes = comps.sort((a, b) => b.area - a.area).slice(0, 6);
  const draw = [], labels = [], items = [];
  let target = null;
  boxes.forEach((c, i) => {
    const bw = c.maxx - c.minx + 1, bh = c.maxy - c.miny + 1;
    draw.push({ t: 'rect', x: c.minx, y: c.miny, w: bw, h: bh, color: [255, 60, 60], lw: 2 });
    const dx = ((c.minx + c.maxx) / 2 - w / 2) / (w / 2);
    items.push(`움직임 #${i + 1} · ${horizontalWord(dx)} · ${bw}×${bh}px`);
    if (i === 0) {
      labels.push([c.minx, c.miny - 4, '움직임', [255, 80, 80]]);
      target = [dx, ((c.miny + c.maxy) / 2 - h / 2) / (h / 2)];
    }
  });
  let summary;
  if (pct > 40) summary = `화면 전체 변화 ${pct.toFixed(0)}% — 로버/카메라가 움직이는 중`;
  else if (boxes.length) summary = `움직임 감지 ${boxes.length}곳 · 변화 ${pct.toFixed(1)}%`;
  else summary = `움직임 없음 · 변화 ${pct.toFixed(1)}%`;
  return { summary, items, target, motion: pct, draw, labels, modified: true };
}

// ---------------------------------------------------------------- ⑤ 윤곽·장애물
function runEdge(px, w, h, p) {
  const n = w * h;
  const gray = blur5(toGray(px, n), w, h);
  const low = Math.max(15, Math.round(150 - p.edge_sens * 1.35));
  const edges = canny(gray, w, h, low, low * 2.5);
  for (let i = 0, j = 0; i < n; i++, j += 4) {
    if (edges[i]) { px[j] = 60; px[j + 1] = 230; px[j + 2] = 255; }
    else { px[j] *= 0.4; px[j + 1] *= 0.4; px[j + 2] *= 0.4; }
  }
  const y0 = (h / 3) | 0, dens = [];
  for (let k = 0; k < 3; k++) {
    const x0 = Math.round(w * k / 3), x1 = Math.round(w * (k + 1) / 3);
    let c = 0;
    for (let y = y0; y < h; y++) for (let x = x0; x < x1; x++) c += edges[y * w + x];
    dens.push(c / ((x1 - x0) * (h - y0)) * 100);
  }
  const names = ['좌', '중', '우'];
  let openI = 0; for (let k = 1; k < 3; k++) if (dens[k] < dens[openI]) openI = k;
  const draw = [{ t: 'line', x1: 0, y1: y0, x2: w, y2: y0, color: [120, 120, 120], lw: 1 }], labels = [];
  for (let k = 0; k < 3; k++) {
    const x0 = (w * k / 3) | 0, x1 = (w * (k + 1) / 3) | 0, busy = dens[k] > 6;
    draw.push({ t: 'rect', x: x0 + 2, y: y0, w: x1 - x0 - 4, h: h - 2 - y0, color: busy ? [255, 60, 60] : [80, 220, 80], lw: k === openI ? 2 : 1 });
    labels.push([x0 + 6, h - 22, `${names[k]} ${dens[k].toFixed(1)}%`, busy ? [255, 80, 80] : [90, 230, 110]]);
  }
  const items = [0, 1, 2].map(k => `${names[k]} 영역 윤곽 밀도 ${dens[k].toFixed(1)}%` + (k === openI ? '  ← 가장 트임' : ''));
  items.push('밀도가 높을수록 물체·요철이 많습니다 (참고용 추정).');
  const summary = `트인 방향: ${names[openI]}  (좌 ${dens[0].toFixed(1)} · 중 ${dens[1].toFixed(1)} · 우 ${dens[2].toFixed(1)}%)`;
  return { summary, items, target: [(openI - 1) * 2 / 3, 0.3], density: dens, open: names[openI], draw, labels, modified: true };
}

// ---------------------------------------------------------------- 진입점
let lastOrig = null, lastW = 0, lastH = 0, lastMode = '';

function analyze(px, w, h, p) {
  switch (p.mode) {
    case 'qr': return runQr(px, w, h, p);
    case 'color': return runColor(px, w, h, p);
    case 'shape': return runShape(px, w, h, p);
    case 'motion': return runMotion(px, w, h, p);
    case 'edge': return runEdge(px, w, h, p);
  }
  return { summary: '', items: [], target: null, draw: [], labels: [] };
}

self.onmessage = (ev) => {
  const m = ev.data;
  if (m.type === 'frame') {
    const t0 = performance.now();
    const px = new Uint8ClampedArray(m.buffer);
    try {
      if (m.params.mode !== lastMode) { prevGray = null; lastMode = m.params.mode; }
      lastOrig = px.slice(); lastW = m.w; lastH = m.h;
      const r = analyze(px, m.w, m.h, m.params);
      r.ms = performance.now() - t0;
      r.mode = m.params.mode;
      r.seq = m.seq;
      self.postMessage({ type: 'done', result: r, buffer: px.buffer, w: m.w, h: m.h }, [px.buffer]);
    } catch (e) {
      self.postMessage({ type: 'done', result: { error: String(e && e.message || e), mode: m.params.mode, seq: m.seq }, buffer: px.buffer, w: m.w, h: m.h }, [px.buffer]);
    }
  } else if (m.type === 'pick') {
    if (!lastOrig) return;
    const x = Math.floor(Math.min(Math.max(m.nx, 0), 0.999) * lastW);
    const y = Math.floor(Math.min(Math.max(m.ny, 0), 0.999) * lastH);
    let r = 0, g = 0, b = 0, c = 0;
    for (let yy = Math.max(0, y - 3); yy <= Math.min(lastH - 1, y + 3); yy++)
      for (let xx = Math.max(0, x - 3); xx <= Math.min(lastW - 1, x + 3); xx++) {
        const j = (yy * lastW + xx) * 4; r += lastOrig[j]; g += lastOrig[j + 1]; b += lastOrig[j + 2]; c++;
      }
    r = Math.round(r / c); g = Math.round(g / c); b = Math.round(b / c);
    self.postMessage({ type: 'picked', d: { hsv: rgbToHsv(r, g, b), rgb: [r, g, b], xy: [x, y] } });
  }
};
