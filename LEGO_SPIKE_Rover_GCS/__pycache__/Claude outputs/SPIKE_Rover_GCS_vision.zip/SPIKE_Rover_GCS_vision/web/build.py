import pathlib
d = pathlib.Path(__file__).parent
t = (d/'template.html').read_text(encoding='utf-8')
jsqr = pathlib.Path('' + str(d/'jsQR.min.js') + '').read_text(encoding='utf-8')
worker = (d/'worker.js').read_text(encoding='utf-8')
app = (d/'app.js').read_text(encoding='utf-8')
for s in (jsqr, worker, app):
    assert '</script' not in s.lower()
out = t.replace('/*@@JSQR@@*/', jsqr).replace('/*@@WORKER@@*/', worker).replace('/*@@APP@@*/', app)
(d.parent/'SPIKE_Rover_GCS.html').write_text(out, encoding='utf-8')
print(len(out))
