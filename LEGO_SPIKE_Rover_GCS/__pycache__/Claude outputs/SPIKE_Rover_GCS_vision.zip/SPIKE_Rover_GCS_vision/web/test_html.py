"""HTML GCS 통합 테스트 (Playwright + 모의 MJPEG 카메라 + 모의 BLE 허브)
Run: python web/test_html.py     (SHOT_DIR=... 로 스크린샷 저장)
"""
import json, os, sys, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import cv2
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import test_vision as tv                      # 같은 합성 장면 재사용
import importlib.util
spec = importlib.util.spec_from_file_location('g', ROOT / 'test_regression.py')
g = importlib.util.module_from_spec(spec); spec.loader.exec_module(g)
G = g.G                                        # rover_gcs.py 의 cobs_pack/make_tunnel

HTML = ROOT / 'SPIKE_Rover_GCS.html'
SHOT = os.environ.get('SHOT_DIR')
SIZE = [int(v) for v in os.environ.get('SIZE', '1280x760').split('x')]
frames = [cv2.imencode('.jpg', tv.scene(i))[1].tobytes() for i in range(20)]


class Cam(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-Type', 'multipart/x-mixed-replace;boundary=roverframe')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        try:
            for i in range(3000):
                f = frames[i % len(frames)]
                self.wfile.write(b'\r\n--roverframe\r\nContent-Type: image/jpeg\r\nContent-Length: '
                                 + str(len(f)).encode() + b'\r\n\r\n' + f)
                self.wfile.flush(); time.sleep(0.1)
        except (BrokenPipeError, ConnectionResetError):
            pass


def check(cond, msg):
    print(('PASS ' if cond else 'FAIL ') + msg)
    if not cond:
        check.failed += 1
check.failed = 0

server = ThreadingHTTPServer(('127.0.0.1', 0), Cam)
threading.Thread(target=server.serve_forever, daemon=True).start()

with sync_playwright() as p:
    b = p.chromium.launch()
    page = b.new_page(viewport={'width': SIZE[0], 'height': SIZE[1]})
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.on('console', lambda m: m.type == 'error' and errors.append(m.text))
    page.goto(HTML.as_uri())
    page.wait_for_timeout(500)

    # ---------- 프로토콜: PC 버전과 바이트 단위 일치 ----------
    for data in (b'\x00', b'\x1e\x00\x00', bytes(range(256)), b'a' * 85, b'\x00\x01\x02' * 50):
        js = page.evaluate('d => Array.from(cobsPack(new Uint8Array(d)))', list(data))
        check(bytes(js) == G['cobs_pack'](data), f'cobsPack == python ({len(data)}B)')
        back = page.evaluate('d => Array.from(cobsUnpack(new Uint8Array(d)))', list(G['cobs_pack'](data)))
        check(bytes(back) == data, f'cobsUnpack roundtrip ({len(data)}B)')
    check(bytes(page.evaluate("Array.from(makeTunnel('Q'))")) == G['make_tunnel']('Q'), 'makeTunnel(Q) == python')

    # ---------- 모의 BLE 허브: 알림 → 파서 → 게이트 → 전송 ----------
    page.evaluate("""() => {
      const L = gcs.ble; window.sent = [];
      L.rx = { writeValueWithoutResponse: async (c) => { window.sent.push(Array.from(c)); } };
      L.server = { connected: true }; L.device = { gatt: { connected: true, disconnect(){} } };
      L.connected = true; L.label = 'SPIKE-MOCK'; L.connectedAt = now(); L.on.conn(true, 'SPIKE-MOCK');
    }""")
    def hub_send(text):
        payload = (text + '\n').encode()
        pkt = bytes([0x32]) + len(payload).to_bytes(2, 'little') + payload
        fr = G['cobs_pack'](pkt)
        for i in range(0, len(fr), 7):       # 알림이 잘게 나뉘어 와도 조립되는지
            page.evaluate('d => gcs.ble.onNotify(new Uint8Array(d))', list(fr[i:i + 7]))
    page.keyboard.down('w'); page.wait_for_timeout(200); page.keyboard.up('w')
    check(not any(bytes(s).find(b'T') >= 0 for s in page.evaluate('window.sent')), 'ACK 전에는 주행 명령 차단')
    hub_send('#T,12.5,1.0,-2.0,100,-100,10,20,150,40,88,0,5000,3')
    hub_send('#I,ack=Q')
    page.wait_for_timeout(150)
    st = page.evaluate("({alive: gcs.ble.programAlive(), ready: gcs.ble.commandReady, prog: document.getElementById('chipProg').textContent, yaw: document.getElementById('vYaw').textContent, dist: document.getElementById('vDist').textContent})")
    check(st['alive'] and st['ready'], '텔레메트리+ACK → 조종 준비')
    check(st['prog'] == '조종 준비 완료' and st['yaw'] == '12.5°' and st['dist'] == '150', f'계기 갱신 {st}')
    page.evaluate('window.sent = []')
    for _ in range(3):                                      # 텔레메트리 유지
        hub_send('#T,12.5,1.0,-2.0,100,-100,10,20,150,40,88,0,5000,3')
    page.keyboard.down('w'); page.wait_for_timeout(300)
    hub_send('#T,12.5,1.0,-2.0,100,-100,10,20,150,40,88,0,5000,3')
    page.keyboard.up('w'); page.wait_for_timeout(300)
    decoded = [G['cobs_unpack'](bytes(s)) for s in page.evaluate('window.sent')]
    texts = [d[3:].decode().strip() for d in decoded if d and d[0] == 0x32]
    check('T250,250' in texts, f'W 키 → T250,250 전송 ({texts[:4]})')
    check('T0,0' in texts, 'W 놓으면 T0,0')
    page.evaluate('window.sent = []')
    page.keyboard.press('Space'); page.wait_for_timeout(100)
    texts = [G['cobs_unpack'](bytes(s))[3:].decode().strip() for s in page.evaluate('window.sent')]
    check('E' in texts, 'Space → E(비상정지)')

    # ---------- 카메라 + 분석 ----------
    page.fill('#camUrl', f'http://127.0.0.1:{server.server_port}/stream')
    page.click('#btnCamConn')
    page.wait_for_function('gcs.camera.lastFrame > 0', timeout=8000)
    box = page.eval_on_selector('#screen', 'e => { const r = e.getBoundingClientRect(); return [r.x, r.y, r.width, r.height]; }')
    check(abs(box[2] - box[3]) < 1.5 and box[2] > 250, f'영상 창 정사각형 {box[2]:.0f}×{box[3]:.0f}')
    for sel in ('#camera', '#analysis', '#adi', '#chart', '#log', '#slSpeed', '#pad'):
        r = page.eval_on_selector(sel, 'e => { const r = e.getBoundingClientRect(); return [r.left, r.top, r.right, r.bottom]; }')
        check(r[0] >= 0 and r[1] >= 0 and r[2] <= SIZE[0] + 0.5 and r[3] <= SIZE[1] + 0.5 and r[2] > r[0], f'{sel} 한 화면 안')
    page.evaluate("gcs.camera.stopOnLoss.checked = true")

    def run_mode(key):
        page.evaluate(f"gcs.analysis.setMode('{key}')")
        page.wait_for_function("document.getElementById('lbPerf').textContent.length > 0 && gcs.camera.processed", timeout=8000)
        page.wait_for_timeout(1200)
        if SHOT:
            page.screenshot(path=f'{SHOT}/html_{key}.png')
        return page.evaluate("({s: document.getElementById('lbSummary').textContent, items: [...document.querySelectorAll('#resList li')].map(l => l.textContent), perf: document.getElementById('lbPerf').textContent})")

    r = run_mode('qr')
    check('SITE-A:ROCK-3' in page.evaluate('[...gcs.analysis.qrHistory.keys()]'), f"QR 인식 {r['s']} / {r['perf']}")
    page.evaluate("Object.values(gcs.analysis.colorChecks).forEach((c,i)=>c.checked = ['빨강','파랑'].includes(Object.keys(gcs.analysis.colorChecks)[i]))")
    r = run_mode('color')
    check(any(i.startswith('빨강: 1개') for i in r['items']) and any(i.startswith('파랑: 1개') for i in r['items']), f"색상 선택 {r['items']} / {r['perf']}")
    r = run_mode('shape')
    check(all(k in r['s'] for k in ('삼각형', '정사각형')), f"도형 {r['s']} / {r['perf']}")
    r = run_mode('motion')
    check('움직임' in r['s'], f"움직임 {r['s']} / {r['perf']}")
    r = run_mode('edge')
    check('트인 방향' in r['s'], f"윤곽 {r['s']} / {r['perf']}")
    # 영상 클릭으로 지정색 (파란 사각형: 원본 455,265 → 채움 모드 375,265 /480)
    page.evaluate("gcs.analysis.setMode('color')")
    page.click('#btnPick')
    page.wait_for_timeout(600)
    page.mouse.click(box[0] + box[2] * 375 / 480, box[1] + box[3] * 265 / 480)
    page.wait_for_function('gcs.analysis.custom', timeout=4000)
    check('파랑' in page.text_content('#txCustom'), '영상 클릭 지정색 = ' + page.text_content('#txCustom'))
    # 카메라 끊김 → 정지 게이트
    page.evaluate('gcs.camera.lastFrame = now() - 4; gcs.camera.tick()')
    check(not page.evaluate('gcs.camera.motionAllowed()') and '끊김' in page.text_content('#camMsg'), '영상 끊김 → 주행 차단')
    page.click('#btnCamStop')
    check(errors == [], 'JS 오류 없음 ' + str(errors[:3]))
    b.close()
server.shutdown()
print('FAILED' if check.failed else 'ALL PASS', check.failed)
sys.exit(1 if check.failed else 0)
