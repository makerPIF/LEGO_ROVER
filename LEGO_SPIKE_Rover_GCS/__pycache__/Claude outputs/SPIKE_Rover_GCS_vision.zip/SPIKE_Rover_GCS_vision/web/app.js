/* =============================================================================
 *  SPIKE Rover GCS — HTML 판 (rover_gcs.py + camera_panel.py + analysis_panel.py)
 *
 *  PC 버전과 같은 구조·기능을 브라우저 API로 옮긴 것입니다.
 *    bleak  → Web Bluetooth      pyserial → Web Serial
 *    QtNetwork MJPEG → fetch 스트림 + 같은 MJPEG 파서
 *    QThread + OpenCV → Web Worker + 순수 JS 영상처리 + jsQR
 *
 *  통신 구조 (PC 버전과 동일한 규약)
 *    GCS  --BLE TunnelMessage(0x32)-->  hub.config["module_tunnel"].callback
 *    GCS  <--BLE TunnelMessage(0x32)--  module_tunnel.send() (콘솔도 수신)
 *  명령:  T<좌>,<우> S E H0/H1 Y<각도> Z K<kp>,<ki>,<kd> V A<포트>,<속도> P I Q
 *  텔레메트리: #T,yaw,pitch,roll,lvel,rvel,lpos,rpos,dist,refl,batt,hold,ms,rx
 * ========================================================================== */
'use strict';

const $ = (id) => document.getElementById(id);
const now = () => performance.now() / 1000;
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const store = {
  get(k, d) { try { const v = localStorage.getItem('spikegcs.' + k); return v === null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem('spikegcs.' + k, JSON.stringify(v)); } catch { } },
};
const pad2 = (n) => String(n).padStart(2, '0');
function hms(d = new Date()) { return `${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`; }
function stamp(d = new Date()) { return `${d.getFullYear()}${pad2(d.getMonth() + 1)}${pad2(d.getDate())}_${pad2(d.getHours())}${pad2(d.getMinutes())}${pad2(d.getSeconds())}`; }
function wrap180(a) { while (a > 180) a -= 360; while (a < -180) a += 360; return a; }
const hex = (u8) => Array.from(u8, b => b.toString(16).padStart(2, '0')).join(' ');

/* 파일 저장: 가능하면 저장 대화상자(File System Access), 아니면 다운로드 */
async function saveBlob(blob, name, desc, mime, ext) {
  if (window.showSaveFilePicker) {
    try {
      const h = await window.showSaveFilePicker({ suggestedName: name, types: [{ description: desc, accept: { [mime]: [ext] } }] });
      const w = await h.createWritable(); await w.write(blob); await w.close();
      return h.name;
    } catch (e) {
      if (e && e.name === 'AbortError') return null;
    }
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  return name + ' (다운로드 폴더)';
}

// =============================================================================
//  1. LEGO SPIKE Prime BLE 프로토콜 (lego.github.io/spike-prime-docs)
// =============================================================================
const SPIKE_SERVICE = '0000fd02-0000-1000-8000-00805f9b34fb';
const SPIKE_RX_CHAR = '0000fd02-0001-1000-8000-00805f9b34fb';   // 허브로 쓰기
const SPIKE_TX_CHAR = '0000fd02-0002-1000-8000-00805f9b34fb';   // 허브에서 알림
const MSG_INFO_REQ = 0x00, MSG_INFO_RES = 0x01, MSG_PROGRAM_FLOW_REQ = 0x1E;
const MSG_PROGRAM_FLOW_NOTI = 0x20, MSG_CONSOLE_NOTI = 0x21, MSG_TUNNEL = 0x32;
const DELIMITER = 0x02, NO_DELIMITER = 0xFF, COBS_CODE_OFFSET = DELIMITER, MAX_BLOCK_SIZE = 84, COBS_XOR = 3;

function cobsEncode(data) {
  const buf = [];
  let codeIndex = 0, block = 0;
  const begin = () => { codeIndex = buf.length; buf.push(NO_DELIMITER); block = 1; };
  begin();
  for (const byte of data) {
    if (byte > DELIMITER) { buf.push(byte); block++; }
    if (byte <= DELIMITER || block > MAX_BLOCK_SIZE) {
      if (byte <= DELIMITER) buf[codeIndex] = byte * MAX_BLOCK_SIZE + block + COBS_CODE_OFFSET;
      begin();
    }
  }
  buf[codeIndex] = block + COBS_CODE_OFFSET;
  return buf;
}
function cobsDecode(data) {
  const out = [];
  const unescape = (code) => {
    if (code === 0xFF) return [null, MAX_BLOCK_SIZE + 1];
    let value = Math.floor((code - COBS_CODE_OFFSET) / MAX_BLOCK_SIZE);
    let blk = (code - COBS_CODE_OFFSET) % MAX_BLOCK_SIZE;
    if (blk === 0) { blk = MAX_BLOCK_SIZE; value -= 1; }
    return [value, blk];
  };
  if (!data.length) return out;
  let [value, block] = unescape(data[0]);
  for (let i = 1; i < data.length; i++) {
    const byte = data[i];
    block -= 1;
    if (block > 0) { out.push(byte); continue; }
    if (value !== null) out.push(value);
    [value, block] = unescape(byte);
  }
  return out;
}
function cobsPack(data) {
  const buf = cobsEncode(data).map(b => b ^ COBS_XOR);
  buf.push(DELIMITER);
  return new Uint8Array(buf);
}
function cobsUnpack(frame) {
  if (!frame.length) return new Uint8Array(0);
  const start = frame[0] === 0x01 ? 1 : 0;
  const end = frame[frame.length - 1] === DELIMITER ? frame.length - 1 : frame.length;
  if (end <= start) return new Uint8Array(0);
  const unx = []; for (let i = start; i < end; i++) unx.push(frame[i] ^ COBS_XOR);
  return new Uint8Array(cobsDecode(unx));
}
const enc = new TextEncoder();
function makeTunnel(text) {
  const payload = enc.encode(text + '\r\n');
  const m = new Uint8Array(3 + payload.length);
  m[0] = MSG_TUNNEL; m[1] = payload.length & 0xFF; m[2] = payload.length >> 8; m.set(payload, 3);
  return m;
}
const u16 = (a, i) => a[i] | (a[i + 1] << 8);

// =============================================================================
//  2. 링크 (BLE / Serial) — 둘 다 같은 이벤트를 낸다
// =============================================================================
class LinkBase {
  constructor(kind) {
    this.kind = kind;
    this.connected = false; this.safeMode = false;
    this.lastRx = 0; this.lastTelemetry = 0; this.commandReady = false;
    this.connectedAt = 0; this.fwInfo = ''; this._text = { console: '', tunnel: '' };
    this.tunnelRxCount = 0; this.label = ''; this.txCount = 0; this._lastDropWarn = 0;
    this.on = { line() { }, log() { }, conn() { }, raw() { }, tx() { }, devices() { } };
  }
  log(m, l = 'info') { this.on.log(m, l); }
  feedText(chunk, channel = 'console') {
    this.lastRx = now();
    let buf = this._text[channel] + chunk;
    while (true) {
      const m = buf.search(/[\r\n]/);
      if (m < 0) break;
      const line = buf.slice(0, m).trim();
      buf = buf.slice(m + 1);
      if (!line) continue;
      if (line.startsWith('#T,')) {
        const f = line.slice(3).split(',');
        if (f.length >= 12 && f.slice(0, 12).every(v => v.trim() !== '' && isFinite(Number(v)))) this.lastTelemetry = now();
      }
      if (line === '#I,ack=Q') this.commandReady = true;
      this.on.line(line);
    }
    this._text[channel] = buf.length > 4096 ? '' : buf;
  }
  programAlive() { return this.connected && this.lastTelemetry > 0 && (now() - this.lastTelemetry) < 3.0; }
  setSafeMode(on) {
    this.safeMode = !!on;
    this.log(on ? '안전 모드 ON — 허브로 아무것도 보내지 않습니다' : '안전 모드 OFF — 이제 명령이 전송됩니다', on ? 'warn' : 'info');
    this.on.conn(this.connected, this.label);
  }
  warnDrop(why) {
    const t = now();
    if (t - this._lastDropWarn < 2.0) return;
    this._lastDropWarn = t;
    this.log('전송 차단 — ' + why, 'warn');
  }
  canSend() { return this.connected && !this.safeMode; }
  send(line) {
    if (!this.connected) { this.warnDrop('허브가 연결되어 있지 않습니다'); return false; }
    if (this.safeMode) { this.warnDrop('안전 모드입니다. [안전 모드 해제]를 누르세요.'); return false; }
    if (line && !'QES'.includes(line[0].toUpperCase())) {
      if (!this.programAlive() || !this.commandReady) { this.warnDrop('허브 프로그램의 텔레메트리와 Q 응답을 먼저 확인하세요'); return false; }
    }
    if (this._sendImpl(line)) { this.txCount++; this.on.tx(this.txCount); return true; }
    return false;
  }
}

class BleLink extends LinkBase {
  constructor() {
    super('ble');
    this.maxPacket = 20; this.devices = []; this.forceRediscover = false; this.linkOnly = false;
    this.connecting = false; this.device = null; this.server = null; this.rx = null; this.txc = null;
    this._frame = []; this._prio = []; this._high = false; this._info = null; this.session = 0;
    this._lock = Promise.resolve();
    this._onNotifyBound = (ev) => { const v = ev.target.value; this.onNotify(new Uint8Array(v.buffer.slice(v.byteOffset, v.byteOffset + v.byteLength))); };
    this._onDiscBound = (ev) => this.onDisconnected(ev.target);
  }
  emitDevices() { this.on.devices(this.devices.map(d => [d.name || '(이름없음)', d.id, '-'])); }
  async loadKnown() {
    if (!navigator.bluetooth || !navigator.bluetooth.getDevices) return;
    try {
      const ds = await navigator.bluetooth.getDevices();
      for (const d of ds) if (!this.devices.find(x => x.id === d.id)) this.devices.push(d);
      if (ds.length) { this.emitDevices(); this.log(`이전에 허용한 BLE 기기 ${ds.length}개를 목록에 불러왔습니다.`); }
    } catch { }
  }
  // ------------------------------ 스캔 (브라우저 기기 선택 창) ------------------------------
  async scan(all) {
    if (!navigator.bluetooth) { this.log('이 브라우저는 Web Bluetooth를 지원하지 않습니다. Chrome 또는 Edge로 여세요.', 'err'); return; }
    this.log(all ? 'BLE 기기 선택 창(필터 없음)을 엽니다…' : 'BLE 기기 선택 창을 엽니다… (SPIKE 서비스 0xFD02)');
    try {
      const opts = all ? { acceptAllDevices: true, optionalServices: [SPIKE_SERVICE] }
        : { filters: [{ services: [SPIKE_SERVICE] }], optionalServices: [SPIKE_SERVICE] };
      const d = await navigator.bluetooth.requestDevice(opts);
      const old = this.devices.findIndex(x => x.id === d.id);
      if (old >= 0) this.devices.splice(old, 1);
      this.devices.unshift(d);
      this.emitDevices();
      this.log(`선택 완료: ${d.name || '(이름없음)'} — [연결]을 누르세요`);
    } catch (e) {
      if (e && e.name === 'NotFoundError')
        this.log('허브를 선택하지 않았습니다. 허브 오른쪽 위 블루투스 버튼을 눌러 파란불이 깜빡이게 한 뒤 다시 스캔하세요. ([모든 기기]로 필터 없이 볼 수도 있습니다)', 'warn');
      else this.log('스캔 실패: ' + (e && e.message || e), 'err');
    }
  }
  // ------------------------------ 연결 ------------------------------
  async connectTo(idx, safe = false, linkOnly = false) {
    if (this.connecting) { this.log('이미 연결을 시도하는 중입니다. 잠시 기다리세요.', 'warn'); return; }
    const dev = this.devices[idx];
    if (!dev) { this.log('주소를 찾을 수 없습니다. 다시 스캔하세요.', 'warn'); return; }
    this.connecting = true; this.linkOnly = linkOnly;
    try { await this._connectInner(dev, safe); } finally { this.connecting = false; }
  }
  async _connectInner(dev, safe) {
    if (this.server) { await this._disconnect(); await sleep(500); }
    const name = dev.name || dev.id;
    try {
      this.log(`① 연결 시도: ${name}`);
      dev.removeEventListener('gattserverdisconnected', this._onDiscBound);
      dev.addEventListener('gattserverdisconnected', this._onDiscBound);
      let server = null;
      for (let attempt = 1; attempt <= 3; attempt++) {
        try { server = await dev.gatt.connect(); break; }
        catch (e) { this.log(`   시도 ${attempt}/3 실패: ${e.message || e}`, 'warn'); if (attempt === 3) throw e; await sleep(800); }
      }
      this.device = dev; this.server = server; this.session++;
      this.maxPacket = 20; this._info = null; this._prio = []; this._high = false; this._frame = [];
      this._text = { console: '', tunnel: '' }; this.tunnelRxCount = 0;
      this.log(`② 연결됨 (패킷 ${this.maxPacket}B)`);
      if (this.linkOnly) {
        Object.assign(this, { connected: true, safeMode: true, label: name, connectedAt: now(), lastRx: 0, lastTelemetry: 0, commandReady: false });
        this.on.conn(true, name);
        this.log('◆ 링크 시험 모드 — 알림 등록도, 전송도 하지 않습니다. 15초 동안 연결이 유지되는지만 봅니다.', 'warn');
        for (let i = 0; i < 15; i++) { await sleep(1000); if (!this.connected) return; }
        this.log('✅ 15초 동안 링크 유지됨 — 순수 BLE 연결은 안정적입니다.', 'tx');
        return;
      }
      // 연결 직후 곧바로 알림을 켜면 허브의 무선 송신이 급격히 늘어난다.
      await sleep(1200);
      if (!server.connected) throw new Error('연결 직후 링크가 끊겼습니다 (허브 전원이 내려갔을 가능성)');
      try {
        const svc = await server.getPrimaryService(SPIKE_SERVICE);
        this.rx = await svc.getCharacteristic(SPIKE_RX_CHAR);
        this.txc = await svc.getCharacteristic(SPIKE_TX_CHAR);
        this.txc.removeEventListener('characteristicvaluechanged', this._onNotifyBound);
        this.txc.addEventListener('characteristicvaluechanged', this._onNotifyBound);
        await this.txc.startNotifications();
      } catch (e) {
        if (e && e.name === 'NotFoundError')
          throw new Error('SPIKE 특성을 찾지 못했습니다. 허브를 껐다 켜고, Windows 설정 > Bluetooth 에서 허브를 \'디바이스 제거\' 한 뒤 다시 연결하세요. (OS의 서비스 캐시 문제)');
        throw e;
      }
      this.log('③ 알림 등록 완료');
      await sleep(800);
      this._lock = Promise.resolve();
      Object.assign(this, { connected: true, safeMode: safe, label: name, connectedAt: now(), lastRx: 0, lastTelemetry: 0, commandReady: false });
      this.on.conn(true, name);
      if (safe) this.log('안전 모드: 허브로 아무것도 보내지 않습니다. 알림 등록·펌웨어·전원·PC Bluetooth 원인은 아직 구분되지 않았습니다.', 'warn');
      else await this._handshake();
    } catch (e) {
      this.log('연결 실패: ' + (e && e.message || e), 'err');
      const d = this.device; this.device = null;
      try { if (d && d.gatt.connected) d.gatt.disconnect(); else if (dev.gatt.connected) dev.gatt.disconnect(); } catch { }
      this.server = null; this.rx = null; this.txc = null; this.connected = false;
      this.on.conn(false, '');
    }
  }
  onDisconnected(dev) {
    if (dev !== this.device) return;
    this.session++; this.commandReady = false; this.lastTelemetry = 0;
    const held = this.connectedAt ? now() - this.connectedAt : 0, got = this.lastRx > 0;
    this.connected = false; this.device = null; this.server = null; this.rx = null; this.txc = null;
    this.on.conn(false, '');
    this.log(`BLE 연결이 끊어졌습니다 (유지 ${held.toFixed(1)}초, 허브 수신 ${got ? '있었음' : '없음'})`, 'warn');
    if (held < 20)
      this.log('→ 연결 직후 끊김. BLE 단절만으로 전원 종료를 판정할 수 없습니다.\n   판별 1: 허브를 USB 전원에 꽂고 같은 동작 → 안 꺼지면 배터리\n   판별 2: LEGO SPIKE App 으로 블루투스 연결 → 거기서도 꺼지면\n           GCS와 무관한 허브/배터리 문제입니다', 'err');
  }
  disconnect() { return this._disconnect(); }
  async _disconnect() {
    this.session++; this.commandReady = false; this.lastTelemetry = 0;
    const dev = this.device;
    try {
      if (dev && this.connected && !this.safeMode)
        await Promise.race([this._writeMsg(makeTunnel('E')), sleep(500).then(() => { throw new Error('시간 초과'); })]);
    } catch (e) { this.log('연결 해제 전 정지 전송 실패: ' + (e.message || e), 'warn'); }
    finally {
      if (dev) {
        this.device = null;
        try { if (dev.gatt.connected) dev.gatt.disconnect(); } catch { }
        this.server = null; this.rx = null; this.txc = null; this.connected = false;
        this.on.conn(false, '');
      }
    }
  }
  async _handshake() {
    let resolve; const got = new Promise(r => resolve = r);
    this._info = resolve;
    try {
      await this._writeMsg(new Uint8Array([MSG_INFO_REQ]));
      this.log('④ InfoRequest 전송 (주행 명령 없음)', 'tx');
      const ok = await Promise.race([got.then(() => true), sleep(4000).then(() => false)]);
      if (ok) this.log('⑤ InfoResponse 확인 — 허브 프로그램 텔레메트리 대기');
      else this.log('InfoResponse 시간 초과: 원시 HEX와 허브 표시를 확인하세요', 'warn');
    } catch (e) { this.log('InfoRequest 실패: ' + (e.message || e), 'warn'); }
  }
  setSafeMode(on) {
    if (this.linkOnly && !on) { this.log('링크 시험은 알림이 없습니다. 연결 해제 후 일반 연결하세요.', 'warn'); return; }
    super.setSafeMode(on);
    if (!on && this.connected) this._handshake();
  }
  // ------------------------------ 수신 ------------------------------
  onNotify(data) {
    this.lastRx = now();
    this.on.raw(data);
    for (const b of data) {
      if (b === 1) {
        if (this._high) this._frame = [];
        this._prio = []; this._high = true; continue;
      }
      const q = this._high ? this._prio : this._frame;
      if (b === DELIMITER) {
        if (q.length) {
          try { this.onMessage(cobsUnpack(q)); } catch (e) { this.log('프레임 해석 실패: ' + e.message, 'warn'); }
        }
        q.length = 0; this._high = false;
      } else {
        q.push(b);
        if (q.length > 8192) { this._frame = []; this._prio = []; this._high = false; this.log('수신 프레임 길이 초과: 재동기화', 'warn'); }
      }
    }
  }
  onMessage(msg) {
    if (!msg.length) return;
    const mid = msg[0];
    if (mid === MSG_INFO_RES && msg.length >= 17) {
      const rpc = `${msg[1]}.${msg[2]}.${u16(msg, 3)}`, fw = `${msg[5]}.${msg[6]}.${u16(msg, 7)}`;
      const reported = u16(msg, 9);
      this.maxPacket = Math.max(1, Math.min(reported || 20, 20));
      const maxMsg = u16(msg, 11);
      this.fwInfo = `RPC ${rpc} · FW ${fw} · 허브 최대패킷 ${reported} · 실제 전송단위 ${this.maxPacket} · maxMsg ${maxMsg}`;
      this.log('허브 정보: ' + this.fwInfo, 'rx');
      this.log('  InfoResponse 원문: ' + hex(msg.slice(0, 17)));
      if (this._info) { this._info(); this._info = null; }
    } else if (mid === 0x1F && msg.length >= 2) {
      this.log('프로그램 요청 ' + (msg[1] === 0 ? 'ACK' : '거부됨'), 'rx');
    } else if (mid === MSG_TUNNEL) {
      if (msg.length < 3) { this.log('RX TunnelMessage: 헤더가 너무 짧습니다', 'warn'); return; }
      const size = u16(msg, 1);
      if (msg.length !== size + 3) { this.log(`RX TunnelMessage 길이 오류: 선언 ${size}, 실제 ${msg.length - 3}`, 'warn'); return; }
      this.tunnelRxCount++;
      if (this.tunnelRxCount === 1) this.log('허브 → GCS 터널 수신 확인 (0x32)', 'rx');
      this.feedText(new TextDecoder().decode(msg.slice(3)), 'tunnel');
    } else if (mid === MSG_CONSOLE_NOTI) {
      let body = msg.slice(1);
      const z = body.indexOf(0); if (z >= 0) body = body.slice(0, z);
      this.feedText(new TextDecoder().decode(body));
    } else if (mid === MSG_PROGRAM_FLOW_NOTI && msg.length > 1) {
      this.commandReady = false; this.lastTelemetry = 0;
      this.log('프로그램 ' + (msg[1] ? '중지됨' : '시작됨'), 'rx');
    }
  }
  // ------------------------------ 송신 ------------------------------
  _sendImpl(line) {
    if (line === 'E') this.session++;          // 아직 실행되지 않은 이전 조종 명령 폐기
    this._sendLine(line, this.session, now());
    return true;
  }
  async _sendLine(line, session, queuedAt) {
    try {
      if (session !== undefined && session !== this.session) return;
      if (queuedAt !== undefined && now() - queuedAt > 0.3) return;
      if (this.safeMode) return;
      const written = await this._writeMsg(makeTunnel(line), session, queuedAt);
      if (line === 'Q' && written) this.log('Q BLE 쓰기 완료 — 허브 ACK 대기', 'tx');
    } catch (e) { this.log('전송 실패: ' + (e.message || e), 'err'); }
  }
  _writeMsg(msg, session, queuedAt) {
    if (!this.rx || !this.server || !this.server.connected) return Promise.reject(new Error('BLE 연결 없음'));
    const framed = cobsPack(msg), rx = this.rx;
    const run = async () => {
      if (session !== undefined && session !== this.session) return false;
      if (queuedAt !== undefined && now() - queuedAt > 0.3) return false;
      if (queuedAt !== undefined && this.safeMode) return false;
      if (rx !== this.rx || !this.server || !this.server.connected) throw new Error('BLE 세션 변경');
      for (let i = 0; i < framed.length; i += this.maxPacket) {
        const chunk = framed.slice(i, i + this.maxPacket);
        if (rx.writeValueWithoutResponse) await rx.writeValueWithoutResponse(chunk);
        else await rx.writeValue(chunk);
      }
      return true;
    };
    const p = this._lock.then(run, run);
    this._lock = p.catch(() => { });
    return p;
  }
  tunnelRaw(payload) {
    if (!this.connected || this.safeMode) return;
    const m = new Uint8Array(3 + payload.length); m[0] = MSG_TUNNEL; m[1] = payload.length & 255; m[2] = payload.length >> 8; m.set(payload, 3);
    this._writeMsg(m).catch(e => this.log('터널 전송 실패: ' + e.message, 'err'));
  }
  interrupt() {
    if (!this.connected || this.safeMode) return;
    (async () => {
      try {
        await this._writeMsg(new Uint8Array([MSG_PROGRAM_FLOW_REQ, 1, 0]));
        await sleep(300);
        for (const p of [[3], [3], [13, 10]]) {
          const m = new Uint8Array([MSG_TUNNEL, p.length, 0, ...p]);
          await this._writeMsg(m); await sleep(150);
        }
      } catch (e) { this.log('인터럽트 실패: ' + e.message, 'warn'); }
    })();
  }
  programFlow(stop, slot) {
    if (!this.connected) { this.log('허브가 연결되지 않았습니다', 'warn'); return; }
    if (this.safeMode) { this.warnDrop('안전 모드입니다. [안전 모드 해제]를 누르세요.'); return; }
    this._writeMsg(new Uint8Array([MSG_PROGRAM_FLOW_REQ, stop ? 1 : 0, slot]))
      .then(() => this.log(`슬롯 ${slot} ${stop ? '중지' : '시작'} 요청`, 'tx'))
      .catch(e => this.log('프로그램 제어 실패: ' + e.message, 'err'));
  }
}

class SerialLink extends LinkBase {
  constructor() {
    super('serial');
    this.ports = []; this.port = null; this.reader = null; this._stop = false; this._wlock = Promise.resolve();
  }
  static portLabel(p) {
    const i = p.getInfo ? p.getInfo() : {};
    const v = i.usbVendorId, d = i.usbProductId;
    return v ? `USB ${v.toString(16).padStart(4, '0')}:${(d || 0).toString(16).padStart(4, '0')}${v === 0x0694 ? ' (LEGO)' : ''}` : '시리얼 포트';
  }
  async listPorts() {
    if (!navigator.serial) return [];
    try { this.ports = await navigator.serial.getPorts(); } catch { this.ports = []; }
    return this.ports.map(p => [SerialLink.portLabel(p), SerialLink.portLabel(p)]);
  }
  async requestPort() {
    try { const p = await navigator.serial.requestPort(); if (!this.ports.includes(p)) this.ports.push(p); return true; }
    catch (e) { if (e.name !== 'NotFoundError') this.log('포트 선택 실패: ' + e.message, 'err'); return false; }
  }
  async connectTo(idx, safe = false) {
    if (this.connected || this.port) { this.log('이미 연결되어 있습니다. 먼저 [연결 해제]를 누르세요.', 'warn'); return; }
    const port = this.ports[idx];
    try { await port.open({ baudRate: 115200 }); }
    catch (e) {
      const msg = e.message || String(e);
      this.log('시리얼 열기 실패: ' + msg, 'err');
      if (/access|denied|already open|busy|액세스/i.test(msg))
        this.log('→ 다른 프로그램이 이 포트를 쓰고 있습니다. SPIKE App(트레이 포함), 아두이노 IDE 시리얼 모니터, 이 GCS의 다른 창을 모두 닫고 다시 시도하세요.', 'warn');
      return;
    }
    this.port = port;
    Object.assign(this, { connected: true, safeMode: safe, label: SerialLink.portLabel(port), connectedAt: now(), lastRx: 0, lastTelemetry: 0, commandReady: false });
    this._stop = false;
    this.on.conn(true, this.label);
    this.log('USB Serial 연결됨: ' + this.label);
    this._readLoop(port);
  }
  async _readLoop(port) {
    const dec = new TextDecoder();
    while (!this._stop && port.readable) {
      const reader = port.readable.getReader(); this.reader = reader;
      try {
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          if (value && value.length) { this.on.raw(value); this.feedText(dec.decode(value, { stream: true })); }
        }
      } catch { break; }
      finally { try { reader.releaseLock(); } catch { } }
    }
    if (this.port === port || this.port === null) {
      this.connected = false;
      this.on.conn(false, '');
      this.log('Serial 연결이 끊어졌습니다', 'warn');
    }
  }
  async disconnect() {
    if (this.connected && !this.safeMode) this._sendImpl('E');
    this.commandReady = false; this.lastTelemetry = 0; this._stop = true;
    const port = this.port;
    try { await this._wlock; } catch { }
    try { if (this.reader) await this.reader.cancel(); } catch { }
    try { if (port) await port.close(); } catch { }
    this.port = null; this.reader = null; this.connected = false;
  }
  _write(bytes) {
    const port = this.port;
    if (!port || !port.writable) return false;
    const run = async () => { const w = port.writable.getWriter(); try { await w.write(bytes); } finally { w.releaseLock(); } };
    const p = this._wlock.then(run, run);
    this._wlock = p.catch(e => this.log('전송 실패: ' + (e.message || e), 'err'));
    return true;
  }
  _sendImpl(line) { return this._write(enc.encode(line + '\r\n')); }
  tunnelRaw(payload) { if (!this.port) { this.log('USB Serial 연결이 아닙니다', 'warn'); return; } this._write(payload); }
  interrupt() {
    if (!this.port) { this.log('USB Serial 연결이 아닙니다', 'warn'); return; }
    (async () => { this._write(new Uint8Array([3])); await sleep(150); this._write(new Uint8Array([3])); await sleep(250); this._write(new Uint8Array([13, 10])); })();
    this.log('TX Ctrl-C ×2 + Enter (REPL 프롬프트 열기)', 'tx');
  }
  programFlow() { this.log('USB에서는 [REPL 조종]을 쓰거나 허브 버튼으로 실행하세요.', 'warn'); }
}

// =============================================================================
//  3. 계기 (캔버스)
// =============================================================================
const C = { LINE: '#1e2a3a', FG: '#dce6f2', DIM: '#7f93ab', ACC: '#3fb9ff', OK: '#3ddc84', MAG: '#c77dff' };
function fitCanvas(cv) {
  const dpr = window.devicePixelRatio || 1, w = cv.clientWidth, h = cv.clientHeight;
  if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
  const ctx = cv.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return [ctx, w, h];
}
const RAD = Math.PI / 180;

function drawADI(cv, pitch, roll) {
  const [p, w, h] = fitCanvas(cv); p.clearRect(0, 0, w, h);
  const cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - 8;
  if (r <= 4) return;
  p.save(); p.beginPath(); p.arc(cx, cy, r, 0, 2 * Math.PI); p.clip();
  p.save(); p.translate(cx, cy); p.rotate(-roll * RAD);
  const off = Math.max(-r, Math.min(r, pitch * (r / 40))); p.translate(0, off);
  const big = r * 3;
  p.fillStyle = '#2b6ea8'; p.fillRect(-big, -big, big * 2, big);
  p.fillStyle = '#7a5230'; p.fillRect(-big, 0, big * 2, big);
  p.strokeStyle = '#eaf3ff'; p.lineWidth = 2; p.beginPath(); p.moveTo(-big, 0); p.lineTo(big, 0); p.stroke();
  p.strokeStyle = 'rgba(255,255,255,0.75)'; p.fillStyle = 'rgba(255,255,255,0.75)'; p.lineWidth = 1; p.font = '9px monospace'; p.textBaseline = 'middle';
  for (const deg of [-30, -20, -10, 10, 20, 30]) {
    const y = -deg * (r / 40), half = r * (Math.abs(deg) % 20 === 0 ? 0.34 : 0.18);
    p.beginPath(); p.moveTo(-half, y); p.lineTo(half, y); p.stroke();
    if (Math.abs(deg) % 20 === 0) p.fillText(String(Math.abs(deg)), half + 3, y);
  }
  p.restore(); p.restore();
  p.strokeStyle = C.LINE; p.lineWidth = 5; p.beginPath(); p.arc(cx, cy, r, 0, 2 * Math.PI); p.stroke();
  p.strokeStyle = '#ffd24a'; p.lineWidth = 2.5; p.beginPath();
  p.moveTo(cx - r * 0.45, cy); p.lineTo(cx - r * 0.12, cy); p.moveTo(cx + r * 0.12, cy); p.lineTo(cx + r * 0.45, cy);
  p.moveTo(cx - r * 0.12, cy); p.lineTo(cx, cy + r * 0.12); p.lineTo(cx + r * 0.12, cy); p.stroke();
  p.fillStyle = '#ffd24a'; p.beginPath(); p.arc(cx, cy, 2.5, 0, 2 * Math.PI); p.fill();
  p.beginPath(); p.moveTo(cx, cy - r + 2); p.lineTo(cx - 5, cy - r + 11); p.lineTo(cx + 5, cy - r + 11); p.closePath(); p.fill(); p.stroke();
}

function drawHSI(cv, yaw, target) {
  const [p, w, h] = fitCanvas(cv); p.clearRect(0, 0, w, h);
  const cx = w / 2, cy = h / 2, r = Math.min(w, h) / 2 - 8;
  if (r <= 4) return;
  p.fillStyle = '#0a1018'; p.strokeStyle = C.LINE; p.lineWidth = 2;
  p.beginPath(); p.arc(cx, cy, r, 0, 2 * Math.PI); p.fill(); p.stroke();
  p.save(); p.translate(cx, cy); p.rotate(-yaw * RAD);
  for (let a = 0; a < 360; a += 15) {
    const major = a % 45 === 0, rad = (a - 90) * RAD, r1 = r * (major ? 0.74 : 0.85);
    p.strokeStyle = major ? C.ACC : '#3d5166'; p.lineWidth = major ? 1.6 : 1;
    p.beginPath(); p.moveTo(r1 * Math.cos(rad), r1 * Math.sin(rad)); p.lineTo(r * Math.cos(rad), r * Math.sin(rad)); p.stroke();
  }
  p.font = 'bold 11px monospace'; p.textAlign = 'center'; p.textBaseline = 'middle';
  for (const [a, t, col] of [[0, 'N', C.FG], [90, 'E', C.DIM], [180, 'S', C.DIM], [270, 'W', C.DIM]]) {
    const rad = (a - 90) * RAD, rr = r * 0.6; p.fillStyle = col; p.fillText(t, rr * Math.cos(rad), rr * Math.sin(rad));
  }
  p.restore();
  p.save(); p.translate(cx, cy); p.rotate(wrap180(target - yaw) * RAD);
  p.fillStyle = C.OK; p.beginPath(); p.moveTo(0, -r + 1); p.lineTo(-5, -r + 10); p.lineTo(5, -r + 10); p.closePath(); p.fill();
  p.restore();
  p.fillStyle = C.ACC; p.strokeStyle = '#0a1018'; p.lineWidth = 1; p.beginPath();
  p.moveTo(cx, cy - r * 0.55); p.lineTo(cx - r * 0.22, cy + r * 0.35); p.lineTo(cx, cy + r * 0.16); p.lineTo(cx + r * 0.22, cy + r * 0.35); p.closePath(); p.fill(); p.stroke();
}

class StripChart {
  constructor(cv, cap = 240) { this.cv = cv; this.cap = cap; this.series = [[], [], []]; this.scales = [1000, 1000, 180]; this.colors = [C.ACC, C.MAG, C.OK]; this.dirty = true; }
  push(a, b, c) { [a, b, c].forEach((v, i) => { const s = this.series[i]; s.push(v); if (s.length > this.cap) s.shift(); }); this.dirty = true; }
  clear() { this.series.forEach(s => s.length = 0); this.dirty = true; }
  draw() {
    const [p, w, h] = fitCanvas(this.cv);
    p.fillStyle = '#070b11'; p.fillRect(0, 0, w, h);
    p.strokeStyle = '#16202c'; p.lineWidth = 1;
    for (let i = 1; i < 4; i++) { const y = h * i / 4; p.beginPath(); p.moveTo(0, y); p.lineTo(w, y); p.stroke(); }
    this.series.forEach((s, k) => {
      if (s.length < 2) return;
      p.strokeStyle = this.colors[k]; p.lineWidth = 1.5; p.beginPath();
      s.forEach((v, i) => { const x = i / (s.length - 1) * w, vv = Math.max(-1, Math.min(1, v / this.scales[k])), y = h / 2 - vv * (h / 2 - 3); i ? p.lineTo(x, y) : p.moveTo(x, y); });
      p.stroke();
    });
    this.dirty = false;
  }
}

function drawBar(cv, value, maximum = 1000) {
  const [p, w, h] = fitCanvas(cv);
  p.fillStyle = '#0b111a'; p.fillRect(0, 0, w, h);
  p.strokeStyle = C.LINE; p.lineWidth = 1; p.strokeRect(0.5, 0.5, w - 1, h - 1);
  const frac = Math.max(-1, Math.min(1, value / maximum)), mid = w / 2;
  p.fillStyle = frac >= 0 ? C.ACC : C.MAG;
  if (frac >= 0) p.fillRect(mid, 1, frac * (mid - 1), h - 2); else p.fillRect(mid + frac * (mid - 1), 1, -frac * (mid - 1), h - 2);
  p.strokeStyle = C.DIM; p.beginPath(); p.moveTo(mid, 0); p.lineTo(mid, h); p.stroke();
}

// =============================================================================
//  4. ESP32-CAM MJPEG (camera_panel.py)
// =============================================================================
class MjpegParser {
  constructor(limit = 1024 * 1024) { this.limit = limit; this.buf = new Uint8Array(0); this.expected = null; }
  feed(data) {
    const nb = new Uint8Array(this.buf.length + data.length); nb.set(this.buf); nb.set(data, this.buf.length); this.buf = nb;
    const frames = [];
    while (true) {
      if (this.expected === null) {
        let end = -1;
        for (let i = 0; i + 3 < this.buf.length; i++)
          if (this.buf[i] === 13 && this.buf[i + 1] === 10 && this.buf[i + 2] === 13 && this.buf[i + 3] === 10) { end = i; break; }
        if (end < 0) { if (this.buf.length > 8192) throw new Error('MJPEG header too large or missing'); break; }
        const headers = new TextDecoder('latin1').decode(this.buf.subarray(0, end)).toLowerCase().split('\r\n');
        this.buf = this.buf.slice(end + 4);
        const len = headers.filter(hh => hh.startsWith('content-length:')).map(hh => hh.split(':')[1].trim());
        if (len.length !== 1) throw new Error('MJPEG Content-Length missing or duplicate');
        if (!/^\d+$/.test(len[0])) throw new Error('MJPEG Content-Length invalid');
        this.expected = parseInt(len[0], 10);
        if (!(this.expected >= 4 && this.expected <= this.limit)) throw new Error('MJPEG frame exceeds limit');
      }
      if (this.buf.length < this.expected) break;
      const f = this.buf.slice(0, this.expected);
      this.buf = this.buf.slice(this.expected); this.expected = null;
      if (!(f[0] === 0xFF && f[1] === 0xD8 && f[f.length - 2] === 0xFF && f[f.length - 1] === 0xD9)) throw new Error('Invalid JPEG frame');
      frames.push(f);
    }
    return frames;
  }
}

class CameraPanel {
  constructor() {
    this.on = { lost() { }, log() { }, frameReady() { }, clicked() { }, viewChanged() { } };
    this.ctrl = null; this.reading = false; this.requested = false;
    this.lastFrame = 0; this.attemptAt = 0; this.bitmap = null; this.jpeg = null;
    this.frames = 0; this.rateAt = now(); this.warned = false; this.parser = new MjpegParser();
    this.processing = false; this.processed = null; this.processedAt = 0; this.pickMode = false;
    this.shown = null; this.decoding = false; this.pendingJpeg = null; this.retry = null;
    this.canvas = $('camCanvas'); this.msg = $('camMsg'); this.status = $('camStatus');
    this.url = $('camUrl'); this.view = $('camView'); this.mirror = $('ckMirror'); this.stopOnLoss = $('ckStopLoss');
    this.url.value = store.get('cam.url', 'http://192.168.4.1:81/stream');
    this.view.selectedIndex = store.get('cam.view', 0);
    $('btnCamConn').onclick = () => this.start();
    $('btnCamStop').onclick = () => this.stop();
    this.view.onchange = () => this._viewChanged();
    this.mirror.onchange = () => this._viewChanged();
    $('btnSnap').onclick = () => this.snapshot();
    $('btnSnapView').onclick = () => this.snapshotView();
    $('btnWifi').onclick = () => this.wifiSettings();
    $('screen').addEventListener('pointerdown', (e) => this._click(e));
    new ResizeObserver(() => this.render()).observe($('screen'));
    setInterval(() => this.tick(), 250);
  }
  viewParams() { return { crop: this.view.selectedIndex === 0, mirror: this.mirror.checked }; }
  _viewChanged() { store.set('cam.view', this.view.selectedIndex); this.processed = null; this.on.viewChanged(); this.render(); }
  setProcessing(on) { this.processing = !!on; this.processed = null; this.render(); }
  setPickMode(on) { this.pickMode = !!on; $('screen').classList.toggle('pick', this.pickMode); }
  frameFresh() { return !!this.lastFrame && now() - this.lastFrame < 3.0; }
  motionAllowed() { return !this.requested || !this.stopOnLoss.checked || (this.lastFrame > 0 && now() - this.lastFrame < 3.0); }
  setText(t) {
    this.msg.textContent = t; this.msg.style.display = '';
    const [p, w, h] = fitCanvas(this.canvas); p.clearRect(0, 0, w, h); this.shown = null;
  }
  // ------------------------------------------------------------ 스트림
  start() {
    let url;
    try { url = new URL(this.url.value.trim()); } catch { url = null; }
    if (!url || url.protocol !== 'http:' || !url.hostname || url.username || url.password) {
      this.status.textContent = '카메라의 http://주소:81/stream 형식으로 입력하세요.'; return;
    }
    this.stop();
    this.activeUrl = url.href;
    store.set('cam.url', url.href);
    Object.assign(this, { requested: true, warned: false, lastFrame: 0, frames: 0, rateAt: now(), jpeg: null, processed: null });
    if (this.bitmap) { this.bitmap.close(); this.bitmap = null; }
    this.setText('카메라 연결 중…');
    this.url.disabled = true; $('btnCamConn').disabled = true;
    this.openStream();
  }
  openStream() {
    if (!this.requested || this.reading) return;
    this.attemptAt = now(); this.parser = new MjpegParser();
    const ctrl = new AbortController(); this.ctrl = ctrl; this.reading = true;
    this.status.textContent = '영상 연결 중… PC가 ROVER-CAM Wi-Fi에 연결되어 있어야 합니다.';
    (async () => {
      let reason = '';
      try {
        const resp = await fetch(this.activeUrl, { cache: 'no-store', signal: ctrl.signal, mode: 'cors' });
        if (resp.status !== 200) throw new Error('HTTP ' + resp.status);
        const kind = (resp.headers.get('content-type') || '').toLowerCase();
        if (!kind.includes('multipart/x-mixed-replace')) throw new Error('MJPEG 주소가 아닙니다. :81/stream을 확인하세요.');
        const reader = resp.body.getReader();
        while (true) {
          const { value, done } = await reader.read();
          if (done) { reason = '스트림 종료'; break; }
          if (ctrl !== this.ctrl || !this.requested) break;
          const frames = this.parser.feed(value);        // 최신 완성 프레임만 표시
          if (frames.length) { this.frames += frames.length; this._onJpeg(frames[frames.length - 1], ctrl); }
        }
      } catch (e) {
        if (e && e.name === 'AbortError') reason = '응답 없음/해제';
        else {
          reason = (e && e.message) || String(e);
          if (e instanceof TypeError) reason += ' — Wi-Fi(ROVER-CAM) 연결과 주소를 확인하세요';
          if (ctrl === this.ctrl) { this.status.textContent = reason; this.on.log('카메라: ' + reason, 'warn'); }
        }
      } finally {
        try { ctrl.abort(); } catch { }
        if (ctrl === this.ctrl) {
          this.ctrl = null; this.reading = false;
          if (this.requested) {
            this.status.textContent = '영상 연결 종료 · 2초 후 재연결: ' + reason;
            this.retry = setTimeout(() => this.openStream(), 2000);
          }
        }
      }
    })();
  }
  _onJpeg(jpeg, ctrl) {
    if (this.decoding) { this.pendingJpeg = [jpeg, ctrl]; return; }
    this.decoding = true;
    createImageBitmap(new Blob([jpeg], { type: 'image/jpeg' })).then((bm) => {
      if (ctrl !== this.ctrl || !this.requested) { bm.close(); return; }
      if (this.bitmap) this.bitmap.close();
      this.bitmap = bm; this.jpeg = jpeg; this.lastFrame = now(); this.warned = false;
      this.on.frameReady(bm);
      if (!this.processing || !this.processed) this.render();
    }).catch(() => {
      if (ctrl === this.ctrl) { this.status.textContent = 'JPEG 디코딩 실패'; this.on.log('카메라: JPEG 디코딩 실패', 'warn'); ctrl.abort(); }
    }).finally(() => {
      this.decoding = false;
      const p = this.pendingJpeg; this.pendingJpeg = null;
      if (p) this._onJpeg(p[0], p[1]);
    });
  }
  tick() {
    if (!this.requested) return;
    const t = now(), age = this.lastFrame ? t - this.lastFrame : Infinity;
    if (age >= 3) {
      this.setText('영상 수신 대기 / 끊김\nWi-Fi와 카메라 전원을 확인하세요.');
      this.processed = null;
      if (!this.warned && this.stopOnLoss.checked) { this.warned = true; this.on.lost(); }
      if (this.ctrl && t - this.attemptAt > 6) this.ctrl.abort();
    } else if (t - this.rateAt >= 1) {
      const fps = this.frames / (t - this.rateAt);
      this.status.textContent = `${this.bitmap.width}×${this.bitmap.height} · 수신 ${fps.toFixed(1)} FPS · 마지막 프레임 ${age.toFixed(1)}초 전`;
      this.frames = 0; this.rateAt = t;
    }
  }
  // ------------------------------------------------------------ 그리기
  showProcessed(cv) {
    if (!this.processing || !this.requested || !this.frameFresh()) return;
    this.processed = cv; this.processedAt = now(); this.render();
  }
  preparedSize(bm = this.bitmap) {
    if (this.view.selectedIndex === 0) { const s = Math.min(bm.width, bm.height); return [s, s]; }
    return [bm.width, bm.height];
  }
  drawPrepared(ctx, bm, dx, dy, dw, dh) {
    let sx = 0, sy = 0, sw = bm.width, sh = bm.height;
    if (this.view.selectedIndex === 0) { const s = Math.min(sw, sh); sx = (sw - s) / 2; sy = (sh - s) / 2; sw = sh = s; }
    ctx.save();
    if (this.mirror.checked) { ctx.translate(dx + dw, dy); ctx.scale(-1, 1); dx = 0; dy = 0; }
    ctx.drawImage(bm, sx, sy, sw, sh, dx, dy, dw, dh);
    ctx.restore();
  }
  render() {
    if (!this.bitmap || !this.frameFresh()) return;
    const [p, W, H] = fitCanvas(this.canvas);
    const useProc = this.processing && this.processed;
    const [iw, ih] = useProc ? [this.processed.width, this.processed.height] : this.preparedSize();
    const k = Math.min(W / iw, H / ih), dw = iw * k, dh = ih * k, dx = (W - dw) / 2, dy = (H - dh) / 2;
    p.clearRect(0, 0, W, H); p.imageSmoothingQuality = 'high';
    if (useProc) p.drawImage(this.processed, dx, dy, dw, dh);
    else this.drawPrepared(p, this.bitmap, dx, dy, dw, dh);
    this.shown = { x: dx, y: dy, w: dw, h: dh };
    this.msg.style.display = 'none';
  }
  _click(e) {
    const r = this.shown; if (!r) return;
    const b = this.canvas.getBoundingClientRect(), x = e.clientX - b.left, y = e.clientY - b.top;
    if (x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) this.on.clicked((x - r.x) / r.w, (y - r.y) / r.h);
  }
  currentViewCanvas() {
    if (this.processing && this.processed) return this.processed;
    if (!this.bitmap) return null;
    const [w, h] = this.preparedSize(), cv = document.createElement('canvas');
    cv.width = w; cv.height = h; this.drawPrepared(cv.getContext('2d'), this.bitmap, 0, 0, w, h);
    return cv;
  }
  // ------------------------------------------------------------ 저장
  async snapshot() {
    if (!this.jpeg || !this.lastFrame || now() - this.lastFrame >= 3) { this.status.textContent = '현재 수신 중인 영상이 없습니다.'; return; }
    const jpeg = this.jpeg;
    try {
      const path = await saveBlob(new Blob([jpeg], { type: 'image/jpeg' }), `rover_${stamp()}.jpg`, 'JPEG', 'image/jpeg', '.jpg');
      if (path) this.on.log('카메라 사진 저장: ' + path, 'info');
    } catch (e) { this.on.log('사진 저장 실패: ' + e.message, 'err'); }
  }
  async snapshotView() {
    const cv = this.frameFresh() ? this.currentViewCanvas() : null;
    if (!cv) { this.status.textContent = '현재 표시 중인 영상이 없습니다.'; return; }
    const blob = await new Promise(r => cv.toBlob(r, 'image/png'));
    try {
      const path = await saveBlob(blob, `rover_view_${stamp()}.png`, 'PNG', 'image/png', '.png');
      if (path) this.on.log('분석 화면 저장: ' + path, 'info');
    } catch (e) { this.on.log('분석 화면 저장 실패: ' + e.message, 'err'); }
  }
  wifiSettings() {
    if (/Windows/i.test(navigator.userAgent)) {
      const a = document.createElement('a'); a.href = 'ms-settings:network-wifi'; document.body.appendChild(a); a.click(); a.remove();
      this.status.textContent = 'Windows Wi-Fi 설정을 엽니다 — ROVER-CAM 선택 → 암호 rovercam123';
    } else this.status.textContent = '운영체제 Wi-Fi 메뉴에서 ROVER-CAM 선택 → 암호 rovercam123 입력';
  }
  stop() {
    const was = this.requested;
    this.requested = false;
    clearTimeout(this.retry);
    const old = this.ctrl; this.ctrl = null; this.reading = false;
    if (old) old.abort();
    this.lastFrame = 0; this.jpeg = null; this.processed = null;
    if (this.bitmap) { this.bitmap.close(); this.bitmap = null; }
    this.setText('카메라 미연결');
    this.status.textContent = '영상 해제 · BLE 로버 조종은 별도 연결입니다.';
    this.url.disabled = false; $('btnCamConn').disabled = false;
    if (was && this.stopOnLoss.checked) this.on.lost();
  }
}

// =============================================================================
//  5. 영상 분석 패널 (analysis_panel.py) — 분석은 Web Worker에서
// =============================================================================
const MODES = [
  ['raw', '원본', '분석 없이 원본 영상만 표시합니다.'],
  ['qr', '① QR 코드', 'QR 코드를 찾아 내용을 읽습니다. 여러 개 동시 인식.'],
  ['color', '② 색상 선택', '선택한 색만 골라 위치·크기를 표시합니다.'],
  ['shape', '③ 도형 인식', '삼각형·사각형·오각형·육각형·원을 구분합니다.'],
  ['motion', '④ 움직임 감지', '이전 프레임과 비교해 움직이는 물체를 찾습니다.'],
  ['edge', '⑤ 윤곽·장애물', '윤곽선 밀도로 좌/중/우 중 트인 방향을 추정합니다.'],
];
const MODE_NAMES = Object.fromEntries(MODES.map(m => [m[0], m[1]]));
const COLOR_DEFS = [['빨강', [255, 70, 70]], ['주황', [255, 150, 40]], ['노랑', [255, 225, 40]], ['초록', [70, 220, 90]], ['파랑', [60, 140, 255]], ['보라', [200, 90, 230]]];
function hsvColorName(h, s, v) {
  if (v < 50) return '검정'; if (s < 45) return v > 170 ? '흰색' : '회색';
  const R = [['빨강', [[0, 8], [170, 179]]], ['주황', [[9, 21]]], ['노랑', [[22, 34]]], ['초록', [[35, 85]]], ['파랑', [[90, 128]]], ['보라', [[129, 169]]]];
  for (const [n, rs] of R) for (const [lo, hi] of rs) if (h >= lo && h <= hi) return n;
  return '청록';
}
function horizontalWord(dx) { const pct = Math.round(Math.abs(dx) * 100); if (pct < 12) return '정면'; return (dx < 0 ? '◀ 왼쪽 ' : '오른쪽 ▶ ') + pct + '%'; }

function makeWorker(onmsg) {
  const src = $('worker-src').textContent;
  try {
    const w = new Worker(URL.createObjectURL(new Blob([src], { type: 'text/javascript' })));
    w.onmessage = (e) => onmsg(e.data);
    w.onerror = (e) => console.error('worker', e.message);
    return w;
  } catch (e) {
    // 워커를 만들 수 없는 환경: 같은 코드를 메인 스레드에서 실행
    console.warn('Worker 생성 실패, 메인 스레드에서 분석:', e);
    const shim = { onmessage: null, postMessage: (m) => setTimeout(() => onmsg(m), 0) };
    new Function('self', src)(shim);
    return { postMessage: (m) => setTimeout(() => shim.onmessage({ data: m }), 0), inline: true };
  }
}

class AnalysisPanel {
  constructor(camera) {
    this.camera = camera;
    this.on = { log() { } };
    this.mode = 'raw'; this.busy = false; this.pending = false; this.custom = null;
    this.qrHistory = new Map(); this.procCount = 0; this.procAt = now(); this.procFps = 0;
    this.lastError = ''; this._lastItems = null; this.seq = 0; this.selRow = -1;
    this.prepCanvas = document.createElement('canvas');
    this.procCanvas = document.createElement('canvas');
    // ---- 모드 버튼 ----
    this.modeButtons = {};
    for (const [key, name, tip] of MODES) {
      const b = document.createElement('button'); b.className = 'mode'; b.textContent = name; b.title = tip;
      b.onclick = () => this.setMode(key);
      $('modeGrid').appendChild(b); this.modeButtons[key] = b;
    }
    // ---- 색 체크 ----
    const saved = store.get('an.colors', ['빨강']);
    this.colorChecks = {};
    for (const [name, rgb] of COLOR_DEFS) {
      const lb = document.createElement('label'); lb.className = 'ck';
      lb.style.color = `rgb(${rgb})`; lb.style.fontWeight = '700';
      const ck = document.createElement('input'); ck.type = 'checkbox'; ck.checked = saved.includes(name);
      ck.onchange = () => store.set('an.colors', Object.entries(this.colorChecks).filter(([, c]) => c.checked).map(([n]) => n));
      lb.append(ck, name); $('colorChecks').appendChild(lb); this.colorChecks[name] = ck;
    }
    const sl = (id, key, def) => { const s = $(id); s.value = store.get('an.' + key, def); s.oninput = () => { store.set('an.' + key, +s.value); this.updateLabels(); }; return s; };
    this.slArea = sl('slArea', 'min_area', 4); this.slSmin = sl('slSmin', 's_min', 90); this.slVmin = sl('slVmin', 'v_min', 60);
    this.slTol = sl('slTol', 'hue_tol', 10); this.slShape = sl('slShape', 'shape_min', 10);
    this.slMotion = sl('slMotion', 'motion_sens', 50); this.slEdge = sl('slEdge', 'edge_sens', 60);
    $('ckIsolate').checked = store.get('an.isolate', true);
    $('ckIsolate').onchange = () => store.set('an.isolate', $('ckIsolate').checked);
    $('btnPick').onclick = () => this.setPick(!$('btnPick').classList.contains('on'));
    $('btnQrCopy').onclick = () => this.copyQr();
    $('btnQrCsv').onclick = () => this.saveQr();
    $('btnQrClear').onclick = () => this.clearQr();
    $('resList').addEventListener('click', (e) => {
      const li = e.target.closest('li'); if (!li) return;
      this.selRow = [...$('resList').children].indexOf(li);
      [...$('resList').children].forEach((x, i) => x.classList.toggle('sel', i === this.selRow));
    });
    this.updateLabels();
    // ---- 워커 ----
    this.worker = makeWorker((m) => m.type === 'done' ? this.onDone(m) : m.type === 'picked' ? this.onPicked(m.d) : null);
    camera.on.frameReady = () => this.onFrame();
    camera.on.clicked = (nx, ny) => this.onCameraClick(nx, ny);
    camera.on.viewChanged = () => { this.pending = false; };
    const savedMode = store.get('an.mode', 'raw');
    this.setMode(MODE_NAMES[savedMode] ? savedMode : 'raw');
  }
  updateLabels() {
    $('lbArea').textContent = `최소 크기 ${(this.slArea.value / 10).toFixed(1)}%`;
    $('lbSmin').textContent = `채도 하한 ${this.slSmin.value}`;
    $('lbVmin').textContent = `밝기 하한 ${this.slVmin.value}`;
    $('lbTol').textContent = `지정색 폭 ±${this.slTol.value}`;
    $('lbShape').textContent = `최소 크기 ${(this.slShape.value / 10).toFixed(1)}%`;
    $('lbMotion').textContent = `민감도 ${this.slMotion.value}`;
    $('lbEdge').textContent = `민감도 ${this.slEdge.value}`;
  }
  params() {
    return {
      ...this.camera.viewParams(), mode: this.mode,
      colors: Object.entries(this.colorChecks).filter(([, c]) => c.checked).map(([n]) => n),
      custom: $('ckCustom').checked ? this.custom : null,
      hue_tol: +this.slTol.value, s_min: +this.slSmin.value, v_min: +this.slVmin.value,
      min_area: this.slArea.value / 10, isolate: $('ckIsolate').checked,
      shape_min: this.slShape.value / 10, shape_color: $('ckShapeColor').checked,
      motion_sens: +this.slMotion.value, edge_sens: +this.slEdge.value,
    };
  }
  setMode(key) {
    this.mode = key;
    for (const [k, b] of Object.entries(this.modeButtons)) b.classList.toggle('on', k === key);
    document.querySelectorAll('.optpage').forEach(p => p.classList.toggle('on', p.dataset.page === key));
    $('lbDesc').textContent = MODES.find(m => m[0] === key)[2];
    store.set('an.mode', key);
    if (key !== 'color') this.setPick(false);
    this.pending = false;
    this.camera.setProcessing(key !== 'raw');
    this.setItems([]); this._lastItems = null; this.selRow = -1;
    if (key === 'raw') { $('lbSummary').textContent = '분석 꺼짐 (원본)'; $('lbTarget').textContent = '목표 방향: --'; $('lbPerf').textContent = ''; }
    else {
      $('lbSummary').textContent = this.camera.frameFresh() ? '분석 중…' : '영상 대기 중…';
      if (key === 'qr') this.refreshQrList();
    }
  }
  setItems(items) {
    const ul = $('resList'); ul.textContent = '';
    for (const t of items) { const li = document.createElement('li'); li.textContent = t; li.title = t; ul.appendChild(li); }
  }
  setPick(on) { $('btnPick').classList.toggle('on', on); this.camera.setPickMode(on); }
  onFrame() {
    if (this.mode === 'raw') return;
    if (this.busy) { this.pending = true; return; }       // 가장 최근 프레임만 대기
    this.submit();
  }
  submit() {
    const bm = this.camera.bitmap;
    if (!bm) return;
    const p = this.params(), [w, h] = this.camera.preparedSize(bm), cv = this.prepCanvas;
    if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
    const ctx = cv.getContext('2d', { willReadFrequently: true });
    this.camera.drawPrepared(ctx, bm, 0, 0, w, h);
    const id = ctx.getImageData(0, 0, w, h);
    this.busy = true;
    this.worker.postMessage({ type: 'frame', buffer: id.data.buffer, w, h, params: p, seq: ++this.seq }, this.worker.inline ? undefined : [id.data.buffer]);
  }
  onDone(m) {
    this.busy = false;
    const r = m.result;
    if (r.error) {
      if (r.error !== this.lastError) { this.lastError = r.error; this.on.log('영상 분석 오류: ' + r.error, 'warn'); }
    } else if (r.mode === this.mode) {
      this.compose(new Uint8ClampedArray(m.buffer), m.w, m.h, r);
      this.camera.showProcessed(this.procCanvas);
      this.showResult(r);
    }
    if (this.pending && this.mode !== 'raw') { this.pending = false; this.submit(); }
  }
  // BGR+라벨 → 표시 이미지 (vision_analysis.to_qimage)
  compose(px, w, h, r) {
    const cv = this.procCanvas;
    if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
    const p = cv.getContext('2d');
    p.putImageData(new ImageData(px, w, h), 0, 0);
    p.lineJoin = 'round';
    for (const d of r.draw || []) {
      p.strokeStyle = `rgb(${d.color})`; p.lineWidth = d.lw || 2; p.beginPath();
      if (d.t === 'poly') { d.pts.forEach((q, i) => i ? p.lineTo(q[0] + 0.5, q[1] + 0.5) : p.moveTo(q[0] + 0.5, q[1] + 0.5)); p.closePath(); }
      else if (d.t === 'rect') p.rect(d.x + 0.5, d.y + 0.5, d.w, d.h);
      else if (d.t === 'line') { p.moveTo(d.x1, d.y1 + 0.5); p.lineTo(d.x2, d.y2 + 0.5); }
      p.stroke();
    }
    const px2 = Math.max(11, Math.floor(w / 34));
    p.font = `bold ${px2}px 'Malgun Gothic','Pretendard','Noto Sans KR',sans-serif`;
    p.textBaseline = 'middle';
    const cx = w / 2, cy = h / 2;
    p.strokeStyle = 'rgba(255,255,255,0.47)'; p.lineWidth = 1; p.setLineDash([]);
    p.beginPath(); p.moveTo(cx - 12, cy); p.lineTo(cx + 12, cy); p.moveTo(cx, cy - 12); p.lineTo(cx, cy + 12); p.stroke();
    if (r.target) {
      const tx = cx + r.target[0] * w / 2, ty = cy + r.target[1] * h / 2;
      p.strokeStyle = 'rgba(255,210,60,0.86)'; p.lineWidth = 2; p.setLineDash([6, 4]);
      p.beginPath(); p.moveTo(cx, cy); p.lineTo(tx, ty); p.stroke(); p.setLineDash([]);
      p.fillStyle = 'rgb(255,210,60)'; p.beginPath(); p.arc(tx, ty, 4, 0, 2 * Math.PI); p.fill();
    }
    const th = px2 + 6;
    for (let [x, y, text, col] of r.labels || []) {
      const tw = p.measureText(text).width + 8;
      x = Math.min(Math.max(0, x), w - tw); y = Math.min(Math.max(th, y), h);
      p.fillStyle = 'rgba(0,0,0,0.67)'; p.beginPath(); p.roundRect(x, y - th, tw, th, 3); p.fill();
      p.fillStyle = `rgb(${col})`; p.fillText(text, x + 4, y - th / 2);
    }
    let hud = `${MODE_NAMES[r.mode] || r.mode} · ${r.summary || ''}`;
    const hh = px2 + 8;
    p.fillStyle = 'rgba(4,10,16,0.75)'; p.fillRect(0, 0, w, hh);
    p.fillStyle = '#7fe3ff';
    while (hud.length > 1 && p.measureText(hud).width > w - 12) hud = hud.slice(0, -2) + '…';
    p.fillText(hud, 6, hh / 2);
  }
  showResult(r) {
    this.procCount++;
    const t = now();
    if (t - this.procAt >= 1) { this.procFps = this.procCount / (t - this.procAt); this.procCount = 0; this.procAt = t; }
    $('lbPerf').textContent = `처리 ${Math.round(r.ms || 0)} ms · 분석 ${this.procFps.toFixed(1)} FPS`;
    $('lbSummary').textContent = r.summary || '';
    $('lbTarget').textContent = '목표 방향: ' + (r.target ? horizontalWord(r.target[0]) : '--');
    if (this.mode === 'qr') { this.updateQr(r.codes || []); return; }
    const items = r.items || [];
    if (JSON.stringify(items) !== JSON.stringify(this._lastItems)) { this._lastItems = items; this.setItems(items); }
  }
  // ---------------------------------------------------------------- QR 기록
  updateQr(codes) {
    const t = hms();
    for (const text of codes) {
      const rec = this.qrHistory.get(text);
      if (!rec) {
        this.qrHistory.set(text, [t, t, 1]);
        if ($('ckQrLog').checked) this.on.log('📷 QR 인식: ' + text, 'tx');
      } else { rec[1] = t; rec[2]++; }
    }
    if (codes.length) this.refreshQrList();
  }
  refreshQrList() {
    if (!this.qrHistory.size) { this.setItems(['아직 인식한 QR이 없습니다.']); return; }
    this.setItems([...this.qrHistory].map(([text, [first, , count]]) => `${first}  ×${String(count).padEnd(4)} ${text}`));
    const lis = $('resList').children;
    if (this.selRow >= 0 && this.selRow < lis.length) lis[this.selRow].classList.add('sel');
  }
  copyQr() {
    const keys = [...this.qrHistory.keys()];
    if (this.mode === 'qr' && this.selRow >= 0 && this.selRow < keys.length) {
      const k = keys[this.selRow];
      (navigator.clipboard ? navigator.clipboard.writeText(k) : Promise.reject()).then(
        () => this.on.log('QR 내용 복사: ' + k, 'info'),
        () => this.on.log('클립보드 복사 실패 — 브라우저 권한을 확인하세요', 'warn'));
    }
  }
  async saveQr() {
    if (!this.qrHistory.size) { this.on.log('저장할 QR 기록이 없습니다.', 'warn'); return; }
    const q = (s) => /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    const rows = [['내용', '처음 인식', '마지막 인식', '횟수'], ...[...this.qrHistory].map(([t, [a, b, c]]) => [t, a, b, String(c)])];
    const blob = new Blob(['﻿' + rows.map(r => r.map(q).join(',')).join('\r\n') + '\r\n'], { type: 'text/csv' });
    const path = await saveBlob(blob, `qr_log_${stamp()}.csv`, 'CSV', 'text/csv', '.csv');
    if (path) this.on.log('QR 기록 저장: ' + path, 'info');
  }
  clearQr() { this.qrHistory.clear(); this.selRow = -1; if (this.mode === 'qr') this.refreshQrList(); }
  // ---------------------------------------------------------------- 색 지정
  onCameraClick(nx, ny) {
    if (!$('btnPick').classList.contains('on')) return;
    if (this.mode !== 'color') this.setMode('color');
    this.worker.postMessage({ type: 'pick', nx, ny });
  }
  onPicked(d) {
    this.custom = d;
    const [r, g, b] = d.rgb, [h, s, v] = d.hsv;
    $('swCustom').style.background = `rgb(${r},${g},${b})`; $('swCustom').style.borderColor = '#dce6f2';
    $('ckCustom').disabled = false; $('ckCustom').checked = true;
    $('txCustom').textContent = `지정색 (${hsvColorName(h, s, v)})`;
    this.setPick(false);
    this.on.log(`지정색 선택: RGB(${r},${g},${b}) · HSV(${h},${s},${v})`, 'info');
  }
}

// =============================================================================
//  6. 메인 (RoverGCS)
// =============================================================================
class RoverGCS {
  constructor() {
    this.ble = new BleLink(); this.ser = new SerialLink(); this.link = this.ble;
    this.tm = { yaw: 0, pitch: 0, roll: 0, lvel: 0, rvel: 0, lpos: 0, rpos: 0, dist: -1, refl: -1, batt: -1, hold: 0, ms: 0 };
    this.drive = [0, 0]; this._lastSent = [0, 0]; this._lastSendT = 0; this.targetYaw = 0; this.holdOn = false;
    this.auxCommand = null; this.keys = new Set(); this.pad = [0, 0]; this.testUntil = 0;
    this.tmCount = 0; this.tmRate = 0; this._rateT = now(); this.recording = false; this.recRows = [];
    this.rawView = false; this.rxReport = ''; this.replMode = false; this.replPingSeen = false;
    this.uplinkHits = []; this.replReadySeen = false; this.tmRx = -1; this._probeT = 0; this._auxT = 0;
    this.devAddrs = [];
    this.buildUi();
    this.wire(this.ble); this.wire(this.ser);
    setInterval(() => this.tickDrive(), 50);
    setInterval(() => this.tickUi(), 100);
    setInterval(() => this.tickRate(), 1000);
    setInterval(() => this.tickReplTm(), 200);
    this.log('GCS 준비 완료. ① [스캔] → ② 허브 선택 → [연결] → ③ [프로그램 시작] → ④ WASD 로 조종', 'info');
    if (!navigator.bluetooth) this.log('이 브라우저는 Web Bluetooth를 지원하지 않습니다. Windows의 Chrome 또는 Edge로 이 파일을 여세요.', 'err');
    if (!window.isSecureContext) this.log('보안 컨텍스트가 아닙니다. 파일을 더블클릭해 file:// 로 열거나 localhost 에서 여세요 (BLE/Serial 제한).', 'warn');
    this.ble.loadKnown();
  }
  // ------------------------------------------------------------------ UI
  setChip(id, text, cls = '') { const c = $(id); c.textContent = text; c.className = 'chip' + (cls ? ' ' + cls : ''); }
  buildUi() {
    $('btnStop').onclick = () => this.estop();
    document.querySelectorAll('#tabbar button').forEach(b => b.onclick = () => {
      document.querySelectorAll('#tabbar button').forEach(x => x.classList.toggle('on', x === b));
      document.querySelectorAll('.tabpage').forEach(p => p.classList.toggle('on', p.id === b.dataset.tab));
    });
    $('cbTransport').onchange = () => this.onTransport($('cbTransport').selectedIndex);
    $('btnScan').onclick = () => this.doScan(false);
    $('btnScanAll').onclick = () => this.doScan(true);
    const lst = $('lstDev');
    lst.addEventListener('click', (e) => { const li = e.target.closest('li'); if (li) this.selectDev([...lst.children].indexOf(li)); });
    lst.addEventListener('dblclick', (e) => { const li = e.target.closest('li'); if (li) { this.selectDev([...lst.children].indexOf(li)); this.doConnect(false); } });
    $('btnConn').onclick = () => this.doConnect(false);
    $('btnDisc').onclick = () => this.doDisconnect();
    $('btnSafe').onclick = () => this.doConnect(true);
    $('btnLinkOnly').onclick = () => this.doLinkTest();
    $('ckRediscover').onchange = () => { this.ble.forceRediscover = $('ckRediscover').checked; };
    $('btnSafeOff').onclick = () => this.toggleSafe();
    $('btnRun').onclick = () => this.startProgram();
    $('btnHalt').onclick = () => this.link.programFlow(true, this.slot());
    $('btnQuery').onclick = () => { if (this.link.send('Q')) this.log('TX Q', 'tx'); };
    $('btnUplink').onclick = () => this.uplinkDiag();
    $('btnIntr').onclick = () => this.link.interrupt();
    $('btnReplPing').onclick = () => this.replPing();
    $('btnReplOn').onclick = () => this.replStart();
    $('btnReplOff').onclick = () => this.replStop();
    for (const id of ['cbLeft', 'cbRight', 'cbAux']) for (const c of 'ABCDEF') { const o = document.createElement('option'); o.textContent = c; $(id).appendChild(o); }
    $('cbLeft').selectedIndex = 0; $('cbRight').selectedIndex = 1; $('cbAux').selectedIndex = 2;
    $('btnApply').onclick = () => this.applyPorts();
    document.querySelectorAll('[data-aux]').forEach(b => b.onclick = () => this.sendAux(+b.dataset.aux));
    $('btnHold').onclick = () => this.toggleHold();
    $('btnZero').onclick = () => this.resetYaw();
    $('slYaw').oninput = () => this.onTargetYaw(+$('slYaw').value);
    $('btnGain').onclick = () => this.applyGain();
    $('btnRec').onclick = () => this.toggleRecord();
    $('btnCsv').onclick = () => this.saveCsv();
    // 방향 패드: 누르는 동안만 주행
    document.querySelectorAll('[data-pad]').forEach(b => {
      const [f, s] = b.dataset.pad.split(',').map(Number);
      b.addEventListener('pointerdown', (e) => { b.setPointerCapture(e.pointerId); this.setPad(f, s); });
      const up = () => this.setPad(0, 0);
      b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up); b.addEventListener('lostpointercapture', up);
    });
    $('padStop').onclick = () => this.estop();
    $('slSpeed').oninput = () => { $('lbSpeed').textContent = `속도 ${$('slSpeed').value}`; };
    $('slTurn').oninput = () => { $('lbTurn').textContent = `선회 ${$('slTurn').value}%`; };
    $('btnMotorTest').onclick = () => this.motorTest();
    $('edCmd').addEventListener('keydown', (e) => { if (e.key === 'Enter') this.sendManual(); });
    $('btnSend').onclick = () => this.sendManual();
    $('ckRaw').onchange = () => this.onRawToggle($('ckRaw').checked);
    // 영상 · 분석
    this.camera = new CameraPanel();
    this.camera.on.log = (m, l) => this.log(m, l);
    this.camera.on.lost = () => this.onCameraLost();
    this.analysis = new AnalysisPanel(this.camera);
    this.analysis.on.log = (m, l) => this.log(m, l);
    // 계기
    this.chart = new StripChart($('chart'));
    // 키보드 · 포커스
    window.addEventListener('keydown', (e) => this.onKey(e, true));
    window.addEventListener('keyup', (e) => this.onKey(e, false));
    window.addEventListener('blur', () => this.onAppState(false));
    document.addEventListener('visibilitychange', () => { if (document.hidden) this.onAppState(false); });
    // 버튼·체크박스·슬라이더가 키보드 포커스를 가져가지 않게 (Space/방향키는 조종 전용)
    document.addEventListener('mousedown', (e) => { if (e.target.closest('button')) e.preventDefault(); });
    const blurNonText = (e) => { const t = e.target; if (t && !isTextField(t) && t.blur) t.blur(); };
    document.addEventListener('change', blurNonText);
    document.addEventListener('pointerup', (e) => { if (e.target && e.target.type === 'range') e.target.blur(); });
    window.addEventListener('beforeunload', () => { this.camera.stop(); this.doDisconnect(); });
  }
  wire(link) {
    link.on.line = (l) => this.onLine(l);
    link.on.log = (m, l) => this.log(m, l);
    link.on.conn = (ok, label) => this.onConn(ok, label, link);
    link.on.raw = (d) => this.onRaw(d);
    link.on.tx = (n) => this.onTx(n);
    link.on.devices = (d) => this.onDevices(d);
  }
  slot() { return Math.max(0, Math.min(19, parseInt($('spSlot').value || '0', 10) || 0)); }
  // ---------------------------------------------------------------- 로그
  log(msg, level = 'info') {
    const col = { info: '#7f93ab', tx: '#5ad1a0', rx: '#7fb4ff', warn: '#ffc46b', err: '#ff7c7c' }[level] || '#7f93ab';
    const box = $('log'), ts = hms();
    const stick = box.scrollTop + box.clientHeight >= box.scrollHeight - 4;
    for (const line of String(msg).split('\n')) {
      const d = document.createElement('div');
      const a = document.createElement('span'); a.style.color = '#44566a'; a.textContent = `[${ts}] `;
      const b = document.createElement('span'); b.style.color = col; b.textContent = line;
      d.append(a, b); box.appendChild(d);
    }
    while (box.childElementCount > 2000) box.firstChild.remove();
    if (stick || true) box.scrollTop = box.scrollHeight;
  }
  onRawToggle(on) { this.rawView = on; this.log(`원시 데이터 표시 ${on ? 'ON' : 'OFF'}`, 'info'); }
  onRaw(data) {
    if (!this.rawView) return;
    const txt = Array.from(data, b => (b >= 32 && b < 127) ? String.fromCharCode(b) : (b === 10 ? '\\n' : b === 13 ? '\\r' : '·')).join('');
    this.log(`RAW(${data.length}) ${txt}`, 'rx');
    this.log('      ' + hex(data), 'info');
  }
  // ------------------------------------------------------------ 연결 제어
  selectDev(i) { const lis = $('lstDev').children; [...lis].forEach((x, k) => x.classList.toggle('sel', k === i)); this.devRow = i; }
  setDevList(rows) {
    const ul = $('lstDev'); ul.textContent = '';
    for (const r of rows) { const li = document.createElement('li'); li.textContent = r; li.title = r; ul.appendChild(li); }
    this.devRow = rows.length ? 0 : -1; if (rows.length) this.selectDev(0);
  }
  async onTransport(idx) {
    this.doDisconnect();
    this.link = idx === 0 ? this.ble : this.ser;
    this.setDevList([]);
    if (idx === 1) {
      if (!navigator.serial) { this.log('이 브라우저는 Web Serial을 지원하지 않습니다 (Chrome/Edge 필요)', 'err'); return; }
      const ports = await this.ser.listPorts();
      this.setDevList(ports.map(([dev, desc]) => `${dev}  —  ${desc}`));
      this.log('USB 포트 목록을 불러왔습니다. [스캔]으로 포트를 추가하고 하나를 고른 뒤 [연결]', 'info');
    } else {
      this.ble.emitDevices();
      this.log('Bluetooth 모드. [스캔]을 누르세요.', 'info');
    }
  }
  async doScan(all) {
    if (this.link === this.ser) {
      if (!navigator.serial) { this.log('이 브라우저는 Web Serial을 지원하지 않습니다', 'err'); return; }
      await this.ser.requestPort();
      const ports = await this.ser.listPorts();
      this.setDevList(ports.map(([dev, desc]) => `${dev}  —  ${desc}`));
      return;
    }
    await this.ble.scan(all);
  }
  onDevices(devs) {
    if (this.link !== this.ble) return;
    this.setDevList(devs.map(([name, addr, rssi]) => `${name}   [${addr.slice(0, 10)}…]   ${rssi} dBm`));
  }
  doLinkTest() {
    if (this.link !== this.ble) { this.log('링크 시험은 Bluetooth 모드에서만 의미가 있습니다. 상단 콤보를 [Bluetooth (BLE)]로 바꾸세요.', 'warn'); return; }
    if (this.ble.connected) { this.log('먼저 [연결 해제]를 누르세요.', 'warn'); return; }
    this.log('링크 시험: 연결만 하고 15초간 유지되는지 봅니다. 여기서 끊기면 BLE 연결 단계·펌웨어·전원을 함께 확인하세요.', 'warn');
    this.doConnect(true, true);
  }
  doConnect(safe, linkOnly = false) {
    if (this.link.connected) { this.log('이미 연결되어 있습니다. 먼저 [연결 해제]를 누르세요.', 'warn'); return; }
    const row = this.devRow ?? -1;
    if (row < 0 || row >= $('lstDev').children.length) { this.log('목록에서 기기를 먼저 선택하세요', 'warn'); return; }
    if (this.link === this.ble) this.ble.connectTo(row, safe, linkOnly);
    else this.ser.connectTo(row, safe);
  }
  doDisconnect() {
    try { this.ble.disconnect(); } catch { }
    try { this.ser.disconnect(); } catch { }
  }
  startProgram() {
    this.log('프로그램 시작 요청 — 슬롯 번호와 응답 ACK/거부를 확인하세요.', 'info');
    this.link.programFlow(false, this.slot());
  }
  onTx(n) { this.setChip('chipTx', `TX ${n}`); }
  toggleSafe() {
    this.keys.clear(); this.pad = [0, 0]; this.drive = [0, 0]; this.auxCommand = null; this.testUntil = 0;
    this.link.setSafeMode(!this.link.safeMode);
  }
  onConn(ok, label, link) {
    if (link && link !== this.link) return;
    this.auxCommand = null; this.keys.clear(); this.pad = [0, 0]; this.drive = [0, 0];
    this.testUntil = 0; this._lastSent = [0, 0]; this.tmRx = -1; this.replMode = false;
    const b = $('btnSafeOff');
    if (ok) {
      const kind = this.link === this.ble ? 'BLE' : 'USB';
      if (this.link.safeMode) this.setChip('chipLink', `${kind} · 안전모드(전송차단)`, 'amber');
      else this.setChip('chipLink', `${kind} · ${String(label).slice(0, 17)}`, 'good');
      b.disabled = false;
      b.textContent = this.link.safeMode ? '안전 모드 해제 — 전송 켜기' : '안전 모드 켜기 (전송 차단)';
      b.className = this.link.safeMode ? 'primary' : '';
    } else {
      this.setChip('chipLink', '미연결'); this.setChip('chipProg', '프로그램 ?');
      b.disabled = true; b.className = '';
    }
  }
  // ------------------------------------------------------------ 텔레메트리
  onLine(line) {
    if (line.startsWith('#T,')) {
      const parts = line.slice(3).split(',');
      if (parts.length >= 12) {
        const nums = parts.slice(0, 12).map(Number);
        if (nums.some(v => !isFinite(v)) || parts.slice(0, 12).some(v => v.trim() === '')) { this.log('RX(형식오류) ' + line, 'warn'); return; }
        const [y, p, r, lv, rv, lp, rp, dist, refl, batt, hold, ms] = nums;
        Object.assign(this.tm, { yaw: y, pitch: p, roll: r, lvel: Math.trunc(lv), rvel: Math.trunc(rv), lpos: Math.trunc(lp), rpos: Math.trunc(rp), dist: Math.trunc(dist), refl: Math.trunc(refl), batt: Math.trunc(batt), hold: Math.trunc(hold), ms: Math.trunc(ms) });
        if (parts.length >= 13 && isFinite(Number(parts[12])) && parts[12].trim() !== '') this.tmRx = Math.trunc(Number(parts[12]));
        this.tmCount++;
        this.chart.push(this.tm.lvel, this.tm.rvel, wrap180(this.targetYaw - this.tm.yaw));
        if (this.recording) this.recRows.push(parts.slice(0, 12).join(','));
        if ($('ckVerbose').checked) this.log('RX ' + line, 'rx');
      }
    } else if (line.startsWith('#S,')) {
      this.rxReport = line.slice(3);
      this.log('◆ 허브 수신 계측: ' + line.slice(3), 'tx');
      const m = line.match(/rx=(\d+)/); if (m) this.setChip('chipHubrx', `허브RX ${m[1]}`, 'good');
    } else if (line.startsWith('#I,repl-ready')) {
      this.replReadySeen = true; this.log('◆ REPL 셋업 완료 응답 수신 — 조종 가능합니다', 'tx');
    } else if (line.startsWith('#I,battery,')) this.log('🔋 허브 배터리: ' + line.slice(11), 'warn');
    else if (line.startsWith('#I,')) this.log('허브: ' + line.slice(3), 'rx');
    else if (line.startsWith('#E,')) this.log('허브 경고: ' + line.slice(3), 'warn');
    else {
      for (const tag of ['UPLINK-A', 'UPLINK-B', 'UPLINK-C', 'UPLINK-D'])
        if (line.includes(tag) && !this.uplinkHits.includes(tag)) { this.uplinkHits.push(tag); this.log('◆ 업링크 도달 확인: ' + tag, 'tx'); return; }
      if (line.includes('PONG-REPL')) { this.replPingSeen = true; this.log('◆ REPL 응답: ' + line, 'tx'); return; }
      if (this.replMode) {
        const st = line.trim().replace(/^[>. ]+/, '');
        if (!st || ['d(', 'tm(', 'import ', 'from ', 'motor_pair.pair', 'd=lambda', 'tm=lambda'].some(s => st.startsWith(s))) return;
      }
      this.log('RX ' + line, 'rx');
    }
  }
  // -------------------------------------------------------------- 주기 작업
  onCameraLost() { this.estop(); this.log('영상 수신 대기/끊김: 로버 정지 요청. 영상 회복 후 다시 조종하세요.', 'warn'); }
  tickDrive() {
    if (!this.camera.motionAllowed()) { this.keys.clear(); this.pad = [0, 0]; this.drive = [0, 0]; this.auxCommand = null; this.testUntil = 0; return; }
    const L = this.link;
    if (!L.connected || L.safeMode) {
      if (this.keys.size || this.pad[0] || this.pad[1])
        L.warnDrop(L.safeMode ? '안전 모드입니다. [안전 모드 해제]를 누르세요.' : '허브가 연결되어 있지 않습니다');
      return;
    }
    const t = now();
    if (!L.programAlive() || !L.commandReady) {
      if (this.keys.size || this.pad[0] || this.pad[1]) L.warnDrop('허브 프로그램 응답 대기: 새 허브 코드 실행 후 업링크 진단하세요');
      this.auxCommand = null; this.keys.clear(); this.pad = [0, 0]; this.drive = [0, 0]; this.testUntil = 0;
      if (L.programAlive() && t - this._probeT > 1) { this._probeT = t; L.send('Q'); }
      return;
    }
    if (this.auxCommand && t - this._auxT > 0.25) { this._auxT = t; const [pid, v] = this.auxCommand; L.send(`A${pid},${v}`); }
    if (!(t < this.testUntil)) this.updateManual();
    const changed = this.drive[0] !== this._lastSent[0] || this.drive[1] !== this._lastSent[1];
    const moving = this.drive[0] !== 0 || this.drive[1] !== 0;
    if (this.replMode) {
      if (changed || (moving && t - this._lastSendT > 0.4)) { L.send(`d(${this.drive[0]},${this.drive[1]})`); this._lastSent = [...this.drive]; this._lastSendT = t; }
      return;
    }
    const keep = (t - this._lastSendT > 0.25) && (moving || L.programAlive());
    if (changed || keep) { L.send(`T${this.drive[0]},${this.drive[1]}`); this._lastSent = [...this.drive]; this._lastSendT = t; }
  }
  updateManual() {
    const spd = +$('slSpeed').value, trn = $('slTurn').value / 100;
    let f = 0, s = 0;
    if (this.keys.has('w')) f += 1; if (this.keys.has('s')) f -= 1;
    if (this.keys.has('a')) s -= 1; if (this.keys.has('d')) s += 1;
    f += this.pad[0]; s += this.pad[1];
    f = Math.max(-1, Math.min(1, f)); s = Math.max(-1, Math.min(1, s));
    this.drive = (f === 0 && s === 0) ? [0, 0] : [Math.trunc(spd * f + spd * trn * s), Math.trunc(spd * f - spd * trn * s)];
  }
  tickUi() {
    const tm = this.tm;
    drawADI($('adi'), tm.pitch, tm.roll);
    drawHSI($('hsi'), tm.yaw, this.targetYaw);
    $('vYaw').textContent = `${tm.yaw.toFixed(1)}°`; $('vPit').textContent = `${tm.pitch.toFixed(1)}°`; $('vRol').textContent = `${tm.roll.toFixed(1)}°`;
    $('vDist').textContent = tm.dist < 0 ? '--' : tm.dist; $('vRefl').textContent = tm.refl < 0 ? '--' : tm.refl;
    $('vBatt').textContent = tm.batt < 0 ? '--' : `${tm.batt}%`; $('vMs').textContent = (tm.ms / 1000).toFixed(1);
    $('vLpos').textContent = tm.lpos; $('vRpos').textContent = tm.rpos;
    $('lbL').textContent = `좌 ${String(tm.lvel).padStart(5)}`; $('lbR').textContent = `우 ${String(tm.rvel).padStart(5)}`;
    drawBar($('barL'), tm.lvel); drawBar($('barR'), tm.rvel);
    this.chart.draw();
    if (this.tmRx >= 0) this.setChip('chipHubrx', `허브RX ${this.tmRx}`, this.tmRx > 0 ? 'good' : 'bad');
    const alive = this.link.programAlive();
    this.setChip('chipProg', alive ? (this.link.commandReady ? '조종 준비 완료' : '프로그램 수신 · Q 응답 대기') : '텔레메트리 없음',
      alive ? 'good' : (this.link.connected ? 'amber' : ''));
  }
  tickReplTm() { if (this.replMode && this.link.connected && !this.link.safeMode) this.link.send('tm()'); }
  tickRate() {
    const t = now(), dt = t - this._rateT;
    this.tmRate = dt > 0 ? this.tmCount / dt : 0; this.tmCount = 0; this._rateT = t;
    this.setChip('chipRate', `${this.tmRate.toFixed(0)} Hz`, this.tmRate > 3 ? 'good' : '');
  }
  // ------------------------------------------------------------ 동작 핸들러
  setPad(f, s) { this.pad = [f, s]; }
  uplinkDiag() {
    if (!this.link.canSend()) { this.log('일반 연결 후 진단하세요. 안전 모드는 전송을 차단합니다.', 'warn'); return; }
    const link = this.link;
    link.commandReady = false;
    this.log(`진단 시작: 텔레메트리=${link.programAlive() ? '있음' : '없음'}, 터널 수신=${link.tunnelRxCount || 0}건`, 'info');
    if (link.send('Q')) { this.log('Q 전송 요청 — hub_rover.py tunnel-v2 응답을 기다립니다.', 'info'); setTimeout(() => this.uplinkResult(link), 2500); }
  }
  uplinkResult(link) {
    if (link !== this.link || !link.connected) return;
    if (link.commandReady) this.log('업링크 성공: 허브가 Q를 해석하고 ACK를 응답했습니다.', 'tx');
    else if (!link.programAlive()) this.log('진단: Q 응답과 텔레메트리 없음. 새 hub_rover.py를 다운로드한 슬롯을 실행하세요. [원시 데이터]를 켜고 [프로그램 시작] 후 오류를 확인하세요.', 'err');
    else this.log('진단: 텔레메트리는 있으나 Q ACK 없음. 허브 #S의 mode=tunnel 여부와 module_tunnel_unavailable/callback 오류를 확인하세요.', 'err');
  }
  replPing() { this.log('REPL 대신 hub_rover.py를 실행하고 [업링크 진단]을 사용하세요.', 'warn'); }
  replStart() { this.replPing(); }
  replStop() { this.replMode = false; }
  sendAux(v) {
    if (v && !this.camera.motionAllowed()) return;
    const pid = $('cbAux').selectedIndex;
    if (this.link.send(`A${pid},${v}`)) this.auxCommand = v ? [pid, v] : null;
  }
  applyPorts() {
    const l = $('cbLeft').selectedIndex, r = $('cbRight').selectedIndex;
    if (l === r) { this.log('좌우 모터는 서로 다른 포트여야 합니다.', 'err'); return; }
    this.drive = [0, 0]; this.keys.clear(); this.pad = [0, 0];
    const a = this.link.send(`P${l},${r}`);
    const b = this.link.send(`I${+$('ckInvL').checked},${+$('ckInvR').checked}`);
    if (a && b) this.log('구동부 설정 전송 완료 — [상태 조회]로 확인하세요', 'tx');
  }
  applyGain() {
    const k = (id) => Math.round((parseFloat($(id).value) || 0) * 1000);
    if (this.link.send(`K${k('spKp')},${k('spKi')},${k('spKd')}`)) this.log('PID 게인 전송', 'tx');
  }
  setHoldButton() { const b = $('btnHold'); b.textContent = `자세유지 ${this.holdOn ? 'ON' : 'OFF'}`; b.className = this.holdOn ? 'ok' : ''; }
  toggleHold() {
    this.holdOn = !this.holdOn; this.setHoldButton();
    if (!this.link.send(this.holdOn ? 'H1' : 'H0')) { this.holdOn = !this.holdOn; this.setHoldButton(); return; }
    if (this.holdOn) { this.targetYaw = this.tm.yaw; $('slYaw').value = Math.trunc(this.targetYaw); $('lbYawT').textContent = `목표 ${Math.trunc(this.targetYaw)}°`; }
    this.log(`자세유지 ${this.holdOn ? 'ON' : 'OFF'}`, 'tx');
  }
  onTargetYaw(v) { this.targetYaw = v; $('lbYawT').textContent = `목표 ${v}°`; this.link.send(`Y${v}`); }
  resetYaw() {
    if (!this.link.send('Z')) return;
    this.targetYaw = 0; $('slYaw').value = 0; $('lbYawT').textContent = '목표 0°';
    this.log('기준각 리셋', 'tx');
  }
  motorTest() {
    if (!this.link.connected) { this.log('허브가 연결되지 않았습니다', 'err'); return; }
    if (this.link.safeMode) { this.log('안전 모드라 모터 테스트를 보낼 수 없습니다. [안전 모드 해제]를 누르세요.', 'err'); return; }
    if (!this.link.programAlive()) this.log('경고: 텔레메트리가 없습니다. 프로그램이 실행 중인지 확인하세요.', 'warn');
    this.log('모터 테스트: 300 deg/s 전진 0.5초', 'tx');
    this.drive = [300, 300]; this.testUntil = now() + 0.5;
    setTimeout(() => { this.drive = [0, 0]; }, 520);
  }
  estop() {
    this.auxCommand = null; this.holdOn = false; this.setHoldButton();
    this.drive = [0, 0]; this.keys.clear(); this.pad = [0, 0]; this.testUntil = 0;
    this.link.send('E');
    this.setChip('chipMode', 'E-STOP', 'bad');
    this.log('*** 비상정지 ***', 'err');
    clearTimeout(this._modeT); this._modeT = setTimeout(() => this.setChip('chipMode', 'MANUAL'), 1200);
  }
  sendManual() {
    const txt = $('edCmd').value.trim();
    if (!this.camera.motionAllowed() && !['E', 'S', 'Q'].includes(txt)) { this.log('영상 수신 대기 중: 조종 명령 차단', 'warn'); return; }
    if (!txt) return;
    if (this.link.send(txt)) this.log('TX ' + txt, 'tx');
    $('edCmd').value = ''; $('edCmd').blur();
  }
  toggleRecord() {
    this.recording = !this.recording;
    $('btnRec').textContent = this.recording ? '⏹ 기록 중지' : '⭕ 기록 시작';
    if (this.recording) { this.recRows = []; this.log('텔레메트리 기록 시작', 'info'); }
    else this.log(`기록 종료 (${this.recRows.length}행)`, 'info');
  }
  async saveCsv() {
    if (!this.recRows.length) { this.log('기록된 데이터가 없습니다', 'warn'); return; }
    const head = 'yaw,pitch,roll,lvel,rvel,lpos,rpos,dist,refl,batt,hold,ms';
    const blob = new Blob([head + '\n' + this.recRows.join('\n') + '\n'], { type: 'text/csv' });
    const path = await saveBlob(blob, `rover_telemetry_${Math.floor(Date.now() / 1000)}.csv`, 'CSV', 'text/csv', '.csv');
    if (path) this.log('저장 완료: ' + path, 'info');
  }
  // ------------------------------------------------------------------ 키보드
  onKey(e, down) {
    if (isTextField(document.activeElement)) return;
    const map = { KeyW: 'w', KeyA: 'a', KeyS: 's', KeyD: 'd', ArrowUp: 'w', ArrowLeft: 'a', ArrowDown: 's', ArrowRight: 'd' };
    const handled = ['Space', 'KeyQ', 'KeyE', 'KeyG', ...Object.keys(map)];
    if (!handled.includes(e.code) || e.ctrlKey || e.altKey || e.metaKey) return;
    e.preventDefault();
    if (e.repeat) return;
    if (down) {
      if (e.code === 'Space') return this.estop();
      if (e.code === 'KeyG') return this.toggleHold();
      if (e.code === 'KeyQ') return this.sendAux(-500);
      if (e.code === 'KeyE') return this.sendAux(500);
      this.keys.add(map[e.code]);
    } else {
      if (e.code === 'KeyQ' || e.code === 'KeyE') return this.sendAux(0);
      if (map[e.code]) this.keys.delete(map[e.code]);
    }
  }
  onAppState(active) {
    if (active) return;
    if (this.auxCommand) this.sendAux(0);
    this.keys.clear(); this.pad = [0, 0];
    this.estop();
  }
}
function isTextField(t) {
  if (!t) return false;
  if (t.tagName === 'TEXTAREA') return true;
  if (t.tagName === 'INPUT' && ['text', 'number', 'search', 'url'].includes(t.type)) return true;
  return false;
}

// =============================================================================
//  7. 한 화면 레이아웃: 열 경계 끌기 + 영상 열 자동 맞춤
// =============================================================================
function setupLayout(gcs) {
  const root = document.documentElement.style;
  const px = (v) => parseFloat(getComputedStyle(document.documentElement).getPropertyValue(v));
  let userSplit = false;
  const MIN = { c1: 250, cam: 300, c3: 270, c4: 270 };
  function balance() {
    if (userSplit) return;
    const main = $('main'), cam = $('camera'), sq = $('square');
    const total = main.clientWidth - 18;
    const base = [250, 280, 270];
    const want = sq.clientHeight + (cam.clientWidth - sq.clientWidth);
    const rest = total - base[0] - base[1] - base[2];
    if (rest > want) {
      const extra = rest - want;
      root.setProperty('--c1', (base[0] + Math.floor(extra * 0.2)) + 'px');
      root.setProperty('--c3', (base[1] + Math.floor(extra * 0.4)) + 'px');
      root.setProperty('--c4', (base[2] + extra - Math.floor(extra * 0.2) - Math.floor(extra * 0.4)) + 'px');
    } else {
      root.setProperty('--c1', base[0] + 'px'); root.setProperty('--c3', base[1] + 'px'); root.setProperty('--c4', base[2] + 'px');
    }
  }
  function initRows() {
    const h = $('col4').clientHeight - 12;
    root.setProperty('--r1', Math.max(180, Math.round(h * 3 / 11)) + 'px');
    root.setProperty('--r2', Math.max(220, Math.round(h * 4 / 11)) + 'px');
  }
  document.querySelectorAll('.gutter').forEach(g => {
    g.addEventListener('pointerdown', (e) => {
      e.preventDefault(); g.setPointerCapture(e.pointerId);
      const k = g.dataset.g, x0 = e.clientX, y0 = e.clientY;
      const s = { c1: px('--c1'), c3: px('--c3'), c4: px('--c4'), r1: px('--r1'), r2: px('--r2') };
      const camW = $('camera').parentElement.clientWidth;
      const move = (ev) => {
        const dx = ev.clientX - x0, dy = ev.clientY - y0;
        if (k === '1') root.setProperty('--c1', Math.max(MIN.c1, Math.min(s.c1 + dx, s.c1 + camW - MIN.cam)) + 'px');
        if (k === '2') root.setProperty('--c3', Math.max(MIN.c3, Math.min(s.c3 - dx, s.c3 + camW - MIN.cam)) + 'px');
        if (k === '3') { const d = Math.max(MIN.c3 - s.c3, Math.min(dx, s.c4 - MIN.c4)); root.setProperty('--c3', (s.c3 + d) + 'px'); root.setProperty('--c4', (s.c4 - d) + 'px'); }
        if (k === 'r1') root.setProperty('--r1', Math.max(150, s.r1 + dy) + 'px');
        if (k === 'r2') root.setProperty('--r2', Math.max(180, s.r2 + dy) + 'px');
        if (k !== 'r1' && k !== 'r2') userSplit = true;
      };
      const up = () => { g.removeEventListener('pointermove', move); g.removeEventListener('pointerup', up); };
      g.addEventListener('pointermove', move); g.addEventListener('pointerup', up);
    });
  });
  initRows(); balance();
  let rt = null;
  window.addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(() => { initRows(); balance(); }, 50); });
  requestAnimationFrame(() => { balance(); gcs.tickUi(); });
}

window.gcs = new RoverGCS();
setupLayout(window.gcs);
