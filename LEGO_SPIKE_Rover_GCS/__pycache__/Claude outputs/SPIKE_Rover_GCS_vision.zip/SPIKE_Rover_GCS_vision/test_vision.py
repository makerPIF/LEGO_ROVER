"""영상 분석 알고리즘 + GCS 한 화면 통합 테스트 (장비 불필요)
Run: python test_vision.py            (화면 없이 실행: QT_QPA_PLATFORM=offscreen)
"""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import sys
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import numpy as np
import cv2
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QEventLoop, QTimer


def wait(ms):
    # QTest.qWait는 GIL을 잡고 있어 분석 스레드를 굶긴다 → 이벤트 루프로 대기
    loop = QEventLoop(); QTimer.singleShot(ms, loop.quit); loop.exec()

import vision_analysis as va

app = QApplication.instance() or QApplication([])
P = dict(va.DEFAULT_PARAMS)


def qr_patch(text, size):
    q = cv2.QRCodeEncoder.create().encode(text)
    q = cv2.resize(q, (size, size), interpolation=cv2.INTER_NEAREST)
    q = cv2.copyMakeBorder(q, 12, 12, 12, 12, cv2.BORDER_CONSTANT, value=255)
    return cv2.cvtColor(q, cv2.COLOR_GRAY2BGR)


def scene(t=0):
    """640×480 탐사 장면: QR 표지 + 색 도형 + 움직이는 공."""
    img = np.full((480, 640, 3), (70, 80, 90), np.uint8)
    q = qr_patch("SITE-A:ROCK-3", 120)
    img[40:40 + q.shape[0], 250:250 + q.shape[1]] = q
    cv2.fillPoly(img, [np.array([[110, 300], [210, 300], [160, 210]])], (40, 40, 230))
    cv2.rectangle(img, (410, 220), (500, 310), (230, 110, 20), -1)
    cv2.circle(img, (300, 390), 48, (20, 210, 250), -1)
    cv2.circle(img, (140 + int(t * 12) % 360, 440), 18, (240, 240, 240), -1)
    return img


class AlgorithmTests(unittest.TestCase):
    def test_qr_multi(self):
        img = np.full((480, 480, 3), 120, np.uint8)
        a, b = qr_patch("MARKER-1", 110), qr_patch("MARKER-2", 110)
        img[40:40 + a.shape[0], 30:30 + a.shape[1]] = a
        img[260:260 + b.shape[0], 300:300 + b.shape[1]] = b
        _o, _l, r = va.analyze(img, dict(P, mode="qr"))
        self.assertEqual(sorted(r["codes"]), ["MARKER-1", "MARKER-2"])

    def test_qr_from_jpeg_scene_crop(self):
        ok, jpg = cv2.imencode(".jpg", scene(), [cv2.IMWRITE_JPEG_QUALITY, 70])
        img = va.prepare(jpg.tobytes(), crop=True)
        self.assertEqual(img.shape[:2], (480, 480))
        _o, _l, r = va.analyze(img, dict(P, mode="qr"))
        self.assertIn("SITE-A:ROCK-3", r["codes"])

    def test_selected_colors_only(self):
        img = va.prepare(cv2.imencode(".jpg", scene())[1].tobytes(), crop=False)
        _o, _l, r = va.analyze(img, dict(P, mode="color", colors=["빨강"]))
        self.assertTrue(r["items"][0].startswith("빨강: 1개"))
        self.assertLess(r["target"][0], 0)                 # 빨간 삼각형은 왼쪽
        _o, _l, r = va.analyze(img, dict(P, mode="color", colors=["파랑", "노랑"]))
        self.assertEqual(len(r["items"]), 2)
        self.assertTrue(all("1개" in i for i in r["items"]))
        _o, _l, r = va.analyze(img, dict(P, mode="color", colors=["초록"]))
        self.assertIn("없음", r["items"][0])

    def test_custom_picked_color(self):
        img = scene()
        hsv = cv2.cvtColor(np.uint8([[[230, 110, 20]]]), cv2.COLOR_BGR2HSV)[0, 0]
        custom = dict(hsv=tuple(int(v) for v in hsv), rgb=(20, 110, 230))
        _o, _l, r = va.analyze(img, dict(P, mode="color", colors=[], custom=custom))
        self.assertTrue(r["items"][0].startswith("지정색: 1개"))

    def test_shapes(self):
        _o, _l, r = va.analyze(scene(), dict(P, mode="shape"))
        for kind in ("삼각형", "정사각형", "원"):
            self.assertIn(kind, r["counts"])

    def test_motion(self):
        m = va.MotionDetector()
        va.analyze(scene(0), dict(P, mode="motion"), motion=m)
        _o, _l, r = va.analyze(scene(5), dict(P, mode="motion"), motion=m)
        self.assertGreater(r["motion"], 0.1)
        _o, _l, r = va.analyze(scene(5), dict(P, mode="motion"), motion=m)
        self.assertEqual(r["motion"], 0.0)

    def test_edge_open_direction(self):
        img = np.full((480, 480, 3), 120, np.uint8)
        for x in range(0, 150, 8):
            cv2.line(img, (x, 170), (x + 20, 480), (255, 255, 255), 2)
        _o, _l, r = va.analyze(img, dict(P, mode="edge"))
        self.assertNotEqual(r["open"], "좌")

    def test_korean_overlay_image(self):
        o, l, r = va.analyze(scene(), dict(P, mode="color", colors=["빨강"]))
        q = va.to_qimage(o, l, "color", r)
        self.assertEqual((q.width(), q.height()), (640, 480))


class OneScreenGuiTest(unittest.TestCase):
    def test_full_gcs_layout_and_modes(self):
        frames = [cv2.imencode(".jpg", scene(i))[1].tobytes() for i in range(20)]

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *a): pass

            def do_GET(self):
                self.send_response(200)
                self.send_header("Content-Type", "multipart/x-mixed-replace;boundary=roverframe")
                self.end_headers()
                try:
                    for i in range(400):
                        f = frames[i % len(frames)]
                        self.wfile.write(b"\r\n--roverframe\r\nContent-Type: image/jpeg\r\nContent-Length: "
                                         + str(len(f)).encode() + b"\r\n\r\n" + f)
                        self.wfile.flush()
                        time.sleep(0.1)
                except (BrokenPipeError, ConnectionResetError):
                    pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        from rover_gcs import RoverGCS
        win = RoverGCS()
        saved = win.camera.settings.value("url")
        win.resize(*[int(v) for v in os.environ.get("GCS_SIZE", "1280x760").split("x")]); win.show()
        win.camera.url.setText(f"http://127.0.0.1:{server.server_port}/stream")
        win.camera.start()
        for _ in range(50):
            wait(100)
            if win.camera.last_frame:
                break
        self.assertTrue(win.camera.last_frame)
        # 영상 창은 정사각형
        sc = win.camera.screen
        self.assertEqual(sc.width(), sc.height())
        # 모든 분석 창이 한 화면(창 안)에 보임
        for w in (win.camera, win.analysis, win.adi, win.chart, win.txt_log, win.sl_speed):
            self.assertTrue(w.isVisible())
            tl = w.mapTo(win, w.rect().topLeft()); br = w.mapTo(win, w.rect().bottomRight())
            self.assertTrue(win.rect().contains(tl) and win.rect().contains(br), w)
        out = os.environ.get("GCS_SHOT_DIR")
        for key in ("qr", "color", "shape", "motion", "edge"):
            win.analysis.set_mode(key)
            for _ in range(30):
                wait(100)
                if not win.camera.processed.isNull() and win.analysis.lb_perf.text():
                    break
            self.assertFalse(win.camera.processed.isNull(), key)
            if key == "qr":
                self.assertIn("SITE-A:ROCK-3", win.analysis.qr_history)
            if out:
                wait(300)
                win.grab().save(os.path.join(out, f"gcs_{key}.png"))
        # 영상 클릭으로 색 지정 (가운데 정사각 채움 기준: 파란 사각형 위치)
        win.analysis.set_mode("color")
        win.analysis.btn_pick.setChecked(True)
        win.analysis.on_camera_click((455 - 80) / 480, 265 / 480)
        for _ in range(20):
            wait(100)
            if win.analysis.custom:
                break
        self.assertIsNotNone(win.analysis.custom)
        self.assertEqual(va.hsv_color_name(*win.analysis.custom["hsv"]), "파랑")
        win.analysis.set_mode("raw")
        win.camera.settings.setValue("url", saved or "http://192.168.4.1:81/stream")
        win.close()
        server.shutdown()


if __name__ == "__main__":
    unittest.main(verbosity=2)
